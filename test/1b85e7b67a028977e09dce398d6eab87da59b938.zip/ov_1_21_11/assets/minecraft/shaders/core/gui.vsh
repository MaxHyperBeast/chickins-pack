#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;

// Chickins: the Tab's strip. With nobody listed (TabFeature unlists everyone) the client fills a strip 24 pixels wide
// down the middle of the Tab's header, and a row under it, in half black (26.2 PlayerTabOverlay: Integer.MIN_VALUE).
// The pack's plate covers it, but not the gap between the offline bar's plaque and the plate, so it's dropped here:
// gui.fsh discards a colour with no alpha. Nothing else the GUI fills is that colour and that narrow on the screen's
// middle (the chat box is that colour, but the screen's width). Written out here, with no include, as vanilla's gui
// shaders are built at startup too, before packs.
const float CTX_TAB_STRIP_REACH = 14.0;   // GUI pixels from the middle: the strip's 12, and a scaled width's rounding

bool ctx_tab_strip(vec4 color, vec4 clip) {
    return all(lessThan(abs(color - vec4(0.0, 0.0, 0.0, 128.0 / 255.0)), vec4(0.002)))
        && abs(clip.x / clip.w / ProjMat[0][0]) <= CTX_TAB_STRIP_REACH;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = ctx_tab_strip(Color, gl_Position) ? vec4(0.0) : Color;
}

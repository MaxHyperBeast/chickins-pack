#ifndef CHICKINS_FLASH_GLSL
#define CHICKINS_FLASH_GLSL

// The beat of a button that wants pressing (PlotButton.setFlashing): flash, flash, a pause. Its pad's plate
// (chickins_lucky.glsl) and its label's letters (<fx:merge>, chickins_text_frag.glsl) both take it from the game's clock,
// so they fade together at every frame and the server sends nothing meanwhile. In ticks; a beat must divide 24000, where
// the game's clock starts again.
#define CTX_FLASH_BEAT 40.0     // a round: 2 seconds
#define CTX_FLASH_LENGTH 8.0    // one flash, up and back down
#define CTX_FLASH_GAP 4.0       // between the two

// How lit a flash is at tick t, from 0 to 1
float ctx_flash(float t) {
    float at = mod(t, CTX_FLASH_BEAT);
    float second = at - (CTX_FLASH_LENGTH + CTX_FLASH_GAP);
    float p = (second >= 0.0 ? second : at) / CTX_FLASH_LENGTH;
    if (p >= 1.0) return 0.0;
    float up = sin(3.14159265 * p);
    return up * up;
}

#endif

#ifndef CHICKINS_LUCKY_GLSL
#define CHICKINS_LUCKY_GLSL

// Include chickins_flash.glsl first: every release includes this file, and they don't share a directive to do it here.

// Lucky Blocks from Exotic up, coloured for every pixel like their text effects, by each release's item shader.
// The generator's LuckyBlockArt writes them, and this does what its Flow and Shading do: keep the two the same.
//   - The item tints each face (253, 240 + face, 240 + effect): face is its direction (0 down, 1 up, 2 north, 3 south,
//     4 west, 5 east), effect the rarity less 8 (0 Exotic, 1 Divine, 2 Celestial, 3 Radiant, 4 Astral, 5 Eternal,
//     6 Eclipse, 7 Godly). Without this shader the tint is almost white.
//   - Its texture is the face's design, 16 x 16: each texel's blue channel says in its lowest two bits what it is
//     (0 the panel, 1 the border, 2 the "?"'s shadow, 3 the white "?" and rivets).
//   - The vertex stage passes on where on the face the pixel is (texels, 0 to 16, continuous): the game writes a
//     face's corners at its uv's (min, min), (min, max), (max, max), (max, min).
// The panel's colour comes from where the pixel is on the cube, continuously, so it carries on over every edge and
// is a smooth gradient however close you look; the border and the shadow are shades of the colour under them, and
// stay the design's pixels. Time is the game's clock in ticks (GameTime x 24000, passed on by the vertex stage, so the
// fragment stage needs no uniforms of its own); every loop divides 24000.
// Vertex stage: info = ctx_lucky_info(Color, GameTime) (flat), uv = ctx_lucky_corner(CTX_VERTEX_ID), and light the
// vertex as if untinted. Fragment stage: the texture's colour is ctx_lucky_color(info, uv, texCoord0, Sampler0).
//
// The openings' glows and shines (the generator's OpeningArt) come through here too: every texel is the colour
// CTX_OPENING_MARK with its strength in its alpha, and the item's tint is the glow's colour. Item displays shade by the
// way a face looks, so a quad turned to the camera would go grey from most sides; these aren't lit at all. Anything
// but a Lucky Block passes its tint on in info.yzw (flat), and ctx_opening_glow says whether a texel is one of these.
// The mark is a colour nothing else may use: any item's texel within 1 of it is drawn unlit too (ResourcePackTest).
//
// A flashing button's plate comes through the Lucky Blocks' path too: its faces are tinted (253, 240, 240 + CTX_LUCKY_FLASH)
// (the generator's ButtonArt), and its texture just gets lit up by the beat (chickins_flash.glsl).

#define CTX_LUCKY_MARK 253
#define CTX_LUCKY_FLASH 8
#define CTX_OPENING_MARK ivec3(255, 248, 255)

// A vertex's number in its own draw (chickins_text.glsl has the same: change both together). From 26.2 the game packs a
// frame's draws into one vertex buffer (StagedVertexBuffer), each starting where the one before ended, rounded to its own
// vertex size, and the game's number counts from the buffer's start, so a quad's corner (& 3) came out wrong by whatever
// was drawn before it that frame, changing from frame to frame. The draw's first vertex comes off: CTX_BASE_VERTEX, which
// 26.2's and 26.3's vertex shaders define where the device has it. 1.21.11 and 26.1 don't share a buffer between draws.
#ifndef CTX_VERTEX_ID
#ifdef VULKAN
#define CTX_BUFFER_VERTEX gl_VertexIndex
#else
#define CTX_BUFFER_VERTEX gl_VertexID
#endif
#ifdef CTX_BASE_VERTEX
#define CTX_VERTEX_ID (CTX_BUFFER_VERTEX - CTX_BASE_VERTEX)
#else
#define CTX_VERTEX_ID CTX_BUFFER_VERTEX
#endif
#endif

// What a vertex passes on, flat: (face, effect, tick, 0) for a Lucky Block's, (-1, its tint) for anything else
vec4 ctx_lucky_info(vec4 color, float gameTime) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if (c.r == CTX_LUCKY_MARK && c.g >= 240 && c.g <= 245 && c.b >= 240 && c.b <= 240 + CTX_LUCKY_FLASH) {
        return vec4(float(c.g - 240), float(c.b - 240), gameTime * 24000.0, 0.0);
    }
    return vec4(-1.0, color.rgb);
}

// Whether a texel of a vertex with this info is an opening's glow: draw it as vec4(info.yzw, texel.a), unlit
bool ctx_opening_glow(vec4 info, vec4 texel) {
    return info.x < 0.0 && all(lessThanEqual(abs(ivec3(round(texel.rgb * 255.0)) - CTX_OPENING_MARK), ivec3(1)));
}

// Where a face's corner is on it, in texels
vec2 ctx_lucky_corner(int vertexId) {
    int corner = vertexId & 3;
    return vec2(corner >= 2 ? 16.0 : 0.0, (corner == 1 || corner == 2) ? 16.0 : 0.0);
}

vec3 ctx_lucky_hex(int c) {
    return vec3(float((c >> 16) & 255), float((c >> 8) & 255), float(c & 255)) / 255.0;
}

// The model point of face position uv (as LuckyBlockArt.point)
vec3 ctx_lucky_point(int face, vec2 uv) {
    if (face == 0) return vec3(uv.x, 0.0, 16.0 - uv.y);
    if (face == 1) return vec3(uv.x, 16.0, uv.y);
    if (face == 2) return vec3(16.0 - uv.x, 16.0 - uv.y, 0.0);
    if (face == 3) return vec3(uv.x, 16.0 - uv.y, 16.0);
    if (face == 4) return vec3(0.0, 16.0 - uv.y, uv.x);
    return vec3(16.0, 16.0 - uv.y, 16.0 - uv.x);
}

// Along the straight line across the cube, and down from the top (LuckyBlockArt.across)
vec2 ctx_lucky_across(int face, vec2 uv) {
    vec3 p = ctx_lucky_point(face, uv);
    return vec2((32.0 - p.x - p.z) / sqrt(2.0), 16.0 - p.y);
}

// Round the cube, and down from the top (LuckyBlockArt.around and ring)
vec2 ctx_lucky_around(int face, vec2 uv) {
    if (face == 3) return uv;
    if (face == 5) return vec2(16.0 + uv.x, uv.y);
    if (face == 2) return vec2(32.0 + uv.x, uv.y);
    if (face == 4) return vec2(48.0 + uv.x, uv.y);
    bool top = face == 1;
    vec2 d = vec2(uv.x, top ? uv.y : 16.0 - uv.y) - 8.0;
    float r = max(1e-6, max(abs(d.x), abs(d.y)));
    vec2 k = d / r;
    float s;
    if (k.y >= abs(k.x)) {
        s = 8.0 + 8.0 * k.x;
    } else if (k.x >= abs(k.y)) {
        s = 24.0 - 8.0 * k.y;
    } else if (-k.y >= abs(k.x)) {
        s = 40.0 - 8.0 * k.x;
    } else {
        s = 56.0 + 8.0 * k.y;
    }
    return vec2(s, top ? r - 8.0 : 24.0 - r);
}

vec3 ctx_lucky_cycle3(float p, int a, int b, int c) {
    float q = fract(p) * 3.0;
    return q < 1.0 ? mix(ctx_lucky_hex(a), ctx_lucky_hex(b), q)
         : q < 2.0 ? mix(ctx_lucky_hex(b), ctx_lucky_hex(c), q - 1.0)
         : mix(ctx_lucky_hex(c), ctx_lucky_hex(a), q - 2.0);
}

vec3 ctx_lucky_hsv(float h, float s, float v) {
    vec3 k = clamp(abs(fract(h + vec3(0.0, 2.0, 1.0) / 3.0) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

vec3 ctx_lucky_to_hsv(vec3 c) {
    float top = max(c.r, max(c.g, c.b));
    float d = top - min(c.r, min(c.g, c.b));
    float h = 0.0;
    if (d > 0.0) {
        if (top == c.r) h = mod((c.g - c.b) / d, 6.0);
        else if (top == c.g) h = (c.b - c.r) / d + 2.0;
        else h = (c.r - c.g) / d + 4.0;
    }
    return vec3(fract(h / 6.0), top == 0.0 ? 0.0 : d / top, top);
}

float ctx_lucky_luminance(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

// LuckyBlockArt.hash: 0 to 1 from a lattice point, in 32-bit integers
float ctx_lucky_hash(int u, int v, int period) {
    uint h = uint(((u % period) + period) % period) * 374761393u + uint(v) * 668265263u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    return float((h ^ (h >> 16u)) & 0xFFFFFFu) / 16777216.0;
}

float ctx_lucky_hash3(int x, int y, int z, int period) {
    int mx = ((x % period) + period) % period;
    int my = ((y % period) + period) % period;
    int mz = ((z % period) + period) % period;
    return ctx_lucky_hash(mx + period * mz, my, period * period);
}

vec2 ctx_lucky_smooth(vec2 f) {
    return f * f * (3.0 - 2.0 * f);
}

// LuckyBlockArt.noise: value noise repeating every period cells along u
float ctx_lucky_noise(vec2 p, int period) {
    ivec2 i = ivec2(floor(p));
    vec2 f = ctx_lucky_smooth(p - vec2(i));
    float top = mix(ctx_lucky_hash(i.x, i.y, period), ctx_lucky_hash(i.x + 1, i.y, period), f.x);
    float bottom = mix(ctx_lucky_hash(i.x, i.y + 1, period), ctx_lucky_hash(i.x + 1, i.y + 1, period), f.x);
    return mix(top, bottom, f.y);
}

// LuckyBlockArt.noise3: value noise in 3D repeating every period cells along each axis
float ctx_lucky_noise3(vec3 p, int period) {
    ivec3 i = ivec3(floor(p));
    vec3 f = p - vec3(i);
    f = f * f * (3.0 - 2.0 * f);
    float layer[2];
    for (int k = 0; k < 2; k++) {
        float near = mix(ctx_lucky_hash3(i.x, i.y, i.z + k, period), ctx_lucky_hash3(i.x + 1, i.y, i.z + k, period), f.x);
        float far = mix(ctx_lucky_hash3(i.x, i.y + 1, i.z + k, period), ctx_lucky_hash3(i.x + 1, i.y + 1, i.z + k, period), f.x);
        layer[k] = mix(near, far, f.y);
    }
    return mix(layer[0], layer[1], f.z);
}

// The panel's colour at face position uv and tick t (LuckyBlockArt.ALL's flows)
vec3 ctx_lucky_panel(int fx, int face, vec2 uv, float t) {
    if (fx == 0) {   // Exotic: candy stripes round the cube
        vec2 a = ctx_lucky_around(face, uv) * 0.75;
        return mod(floor((a.x + a.y - t * 0.3) / 3.0), 2.0) < 0.5 ? ctx_lucky_hex(0xff5cdd) : ctx_lucky_hex(0xff8de7);
    }
    if (fx == 4) {   // Astral: clouds drifting through the cube
        vec3 p = ctx_lucky_point(face, uv) * (3.0 / 16.0);
        float drift = t * 4.0 / 200.0;
        float n = ctx_lucky_noise3(p + vec3(drift, 0.0, drift), 4);
        vec3 c = mix(ctx_lucky_hex(0x5b45d6), ctx_lucky_hex(0x8a6cff), smoothstep(0.15, 0.4, n));
        c = mix(c, ctx_lucky_hex(0xc77dff), smoothstep(0.4, 0.62, n));
        return mix(c, ctx_lucky_hex(0xff8ad8), smoothstep(0.62, 0.85, n));
    }
    vec2 a = ctx_lucky_across(face, uv);
    float s = a.x;
    float h = a.y;
    if (fx == 1) return ctx_lucky_cycle3(s / 16.0 - 2.0 * t / 48.0 + h * 0.015, 0x52cfe3, 0x71fff1, 0x3790c4);   // Divine
    if (fx == 2) return ctx_lucky_cycle3(s / 16.0 - t / 40.0 + h * 0.015, 0xaab6dc, 0xc0ceec, 0x98a0cf);         // Celestial
    if (fx == 3) return ctx_lucky_cycle3(s / 16.0 - 2.0 * t / 48.0 + h * 0.015, 0xf2c43c, 0xffe854, 0xd39224);   // Radiant
    if (fx == 5) {   // Eternal: curtains of light, a violet edge now and then towards the bottom
        float w = 0.5 + 0.5 * sin(2.0 * 3.14159265 * (s / 16.0 - t * 3.0 / 96.0) + h * 0.5 * 0.45);
        vec3 c = mix(ctx_lucky_hex(0x0fa59d), ctx_lucky_hex(0x39e38a), w);
        float edge = smoothstep(0.55, 0.9, ctx_lucky_noise(vec2(s * 5.0 / 32.0 - t * 5.0 / 96.0, 0.0), 5));
        return mix(c, ctx_lucky_hex(0x8f7dff), 0.75 * edge * clamp(h * 0.5 / 7.0, 0.0, 1.0));
    }
    if (fx == 6) return ctx_lucky_cycle3(s / 16.0 - 2.0 * t / 48.0 + h * 0.015, 0x52307a, 0x9a62d8, 0x3a2259);   // Eclipse
    return ctx_lucky_hsv(s * 2.0 * 0.022 + h * 0.5 * 0.8 * 0.022 - t / 80.0, 0.72, 1.0);                        // Godly
}

float ctx_lucky_from_blue(float h) {
    return abs(fract(h - 240.0 / 360.0 + 0.5) - 0.5) * 360.0;
}

// LuckyBlockArt.Shade.of: turn the hue towards blue by turn + perDegree x its distance from blue (degrees), the
// saturation x saturate, and find the value that makes the luminance x luminance
vec3 ctx_lucky_shade(vec3 panel, vec4 shade, bool rainbow) {
    vec3 hsv = ctx_lucky_to_hsv(panel);
    float degrees = rainbow ? 0.0 : shade.x + shade.y * ctx_lucky_from_blue(hsv.x);
    float d = fract(240.0 / 360.0 - hsv.x + 0.5) - 0.5;
    float hue = hsv.x + sign(d) * min(abs(d), degrees / 360.0);
    float saturation = min(1.0, hsv.y * shade.z);
    float target = ctx_lucky_luminance(panel) * shade.w;
    float low = 0.0;
    float high = 1.0;
    for (int i = 0; i < 16; i++) {
        float value = (low + high) * 0.5;
        if (ctx_lucky_luminance(ctx_lucky_hsv(hue, saturation, value)) < target) low = value;
        else high = value;
    }
    return ctx_lucky_hsv(hue, saturation, (low + high) * 0.5);
}

// LuckyBlockArt.Shade.from: the shade that turns the user's example panel into its border or its shadow
vec4 ctx_lucky_shade_from(int panel, int shade) {
    vec3 p = ctx_lucky_to_hsv(ctx_lucky_hex(panel));
    vec3 q = ctx_lucky_to_hsv(ctx_lucky_hex(shade));
    float turned = abs(fract(p.x - q.x + 0.5) - 0.5) * 360.0;
    return vec4(0.0, turned / ctx_lucky_from_blue(p.x), q.y / p.y,
                ctx_lucky_luminance(ctx_lucky_hex(shade)) / ctx_lucky_luminance(ctx_lucky_hex(panel)));
}

// A border (shadow false) or a shadow of panel colour c, shaded as LuckyBlockArt.ALL's Shading: VIVID for Exotic,
// Eternal and Godly (Godly's keeps its hue), SOFT for the rest
vec3 ctx_lucky_shaded(int fx, vec3 c, bool shadow) {
    bool vivid = fx == 0 || fx == 5 || fx == 7;
    vec4 shade = vivid
        ? (shadow ? vec4(27.0, 0.0, 1.65, 0.587) : vec4(17.0, 0.0, 1.65, 0.706))
        : (shadow ? ctx_lucky_shade_from(0xfad739, 0xe0690b) : ctx_lucky_shade_from(0xfad739, 0xf09424));
    return ctx_lucky_shade(c, shade, fx == 7);
}

// A flashing plate's colour at a flash's height (the generator's ButtonArt.lit, for its preview: keep the two the same):
// paler, the hue turned towards yellow as highlights are, so its bevel still shows
vec3 ctx_flash_lit(vec3 c) {
    vec3 hsv = ctx_lucky_to_hsv(c);
    float d = fract(60.0 / 360.0 - hsv.x + 0.5) - 0.5;
    return ctx_lucky_hsv(hsv.x + sign(d) * min(abs(d), 9.0 / 360.0), max(hsv.y - 0.42, 0.0), min(hsv.z + 0.045, 1.0));
}

// A Lucky Block pixel: info is what its vertices passed on (ctx_lucky_info), uv where it is on the face, texCoord its
// texture coordinate in atlas. The colour before the light, as the texture's would be.
vec4 ctx_lucky_color(vec4 info, vec2 uv, vec2 texCoord, sampler2D atlas) {
    int face = int(info.x + 0.5);
    int fx = int(info.y + 0.5);
    if (fx == CTX_LUCKY_FLASH) {
        vec4 plate = texture(atlas, texCoord);
        return vec4(mix(plate.rgb, ctx_flash_lit(plate.rgb), ctx_flash(info.z)), plate.a);
    }
    ivec4 texel = ivec4(round(texelFetch(atlas, ivec2(texCoord * vec2(textureSize(atlas, 0))), 0) * 255.0));
    int kind = texel.b & 3;
    if (kind == 3) return vec4(1.0);
    vec3 c = ctx_lucky_panel(fx, face, clamp(uv, 0.0, 16.0), info.z);
    if (kind == 0) return vec4(c, 1.0);
    return vec4(ctx_lucky_shaded(fx, c, kind == 2), 1.0);
}

#endif

#ifndef CHICKINS_TEXT_FRAG_GLSL
#define CHICKINS_TEXT_FRAG_GLSL

// Fragment half of the text effects (see chickins_text.glsl, included first, as is chickins_flash.glsl: every release
// includes this file, and they don't share a directive to do it here).

// Where a fragment sits in its glyph. The glyph's size in the atlas comes from how fast the atlas coordinate moves
// against the quad-local one (the texture coordinates stay the glyph's when the vertex stage moves or grows a quad),
// and its size in the world or on screen from how fast the position does, less the room the vertex stage grew it by.
// So it works on Minecraft's packed font atlas and for text at any size.
struct CtxFrag {
    float k;       // letter index along the text
    float kind;    // CTX_LETTER, CTX_SHADOW, CTX_SHADOW_PLAIN, CTX_GLOW_QUAD or CTX_HIDDEN
    bool shadow;   // a drop-shadow copy (a glow pass's is the glow's canvas)
    float t;       // ticks
    float gw;      // glyph width in glyph pixels
    vec2 gc;       // position in the glyph in glyph pixels from its top left, continuous (outside it in the room round it)
    float X;       // position along the whole text, roughly (k * 6 + column), 0 in the middle of a pixel
    float y;       // row, 0 in the middle of the top pixel
    vec2 o;        // the glyph's top-left texel in the atlas
    float ts;      // atlas texels per glyph pixel
};

CtxFrag ctx_frag(vec4 info, vec2 uv, vec4 local, vec3 pos, sampler2D atlas) {
    vec2 lp = local.xy;
    vec2 lx = vec2(dFdx(lp.x), dFdy(lp.x));
    vec2 ly = vec2(dFdx(lp.y), dFdy(lp.y));
    vec2 tuv = uv * vec2(textureSize(atlas, 0));
    float wt = length(vec2(dFdx(tuv.x), dFdy(tuv.x))) / max(length(lx), 1e-6);
    float ht = length(vec2(dFdx(tuv.y), dFdy(tuv.y))) / max(length(ly), 1e-6);
    CtxFrag f;
    f.k = info.y;
    f.kind = floor(info.z + 0.5);
    f.shadow = f.kind != CTX_LETTER;
    f.t = info.w;
    f.ts = max(ht / 8.0, 1e-3);
    f.o = floor(tuv - lp * vec2(wt, ht) + 0.5);
    f.gw = max(floor(wt / f.ts + 0.5), 1.0);
    // the quad's sides in position units: pos = corner + right * lp.x + down * lp.y, solved from the derivatives
    vec3 px = dFdx(pos);
    vec3 py = dFdy(pos);
    float det = lx.x * ly.y - ly.x * lx.y;
    vec2 size = vec2(length(ly.y * px - ly.x * py), length(lx.x * py - lx.y * px)) / max(abs(det), 1e-12);
    vec2 s = max((size - 2.0 * local.z) / vec2(f.gw, 8.0), 1e-6);   // position units per glyph pixel
    // the letter's top left from the quad's: past the room, and a drop shadow lies a glyph pixel right of and below it
    vec2 letter = vec2(local.z + local.w) - (f.shadow ? s.y : 0.0);
    f.gc = (lp * size - letter) / s;
    f.X = f.k * 6.0 + f.gc.x - 0.5;
    f.y = f.gc.y - 0.5;
    return f;
}

// 1 if glyph pixel p is filled; 0 outside the glyph, so its neighbours in the atlas never leak in
float ctx_px(CtxFrag f, vec2 p, sampler2D atlas) {
    if (p.x < 0.0 || p.y < 0.0 || p.x >= f.gw || p.y >= 8.0) return 0.0;
#ifdef IS_GRAYSCALE
    return texelFetch(atlas, ivec2(f.o + (p + 0.5) * f.ts), 0).r;
#else
    return texelFetch(atlas, ivec2(f.o + (p + 0.5) * f.ts), 0).a;
#endif
}

// The glyph's shape blurred at glyph position p (ctx_cover summed over its filled pixels): a glow that hugs the
// letter's shape and fades smoothly, with no creases
float ctx_glyph_cover(CtxFrag f, vec2 p, sampler2D atlas) {
    float cover = 0.0;
    vec2 base = floor(p);
    for (int dy = -4; dy <= 4; dy++) {
        for (int dx = -4; dx <= 4; dx++) {
            vec2 t = base + vec2(float(dx), float(dy));
            if (ctx_px(f, t, atlas) > 0.5) {
                cover += ctx_cover(t, p);
            }
        }
    }
    return cover;
}

float ctx_hash(float n) {
    return fract(sin(n) * 43758.5453123);
}

float ctx_hash2(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float ctx_noise(float x) {
    float i = floor(x);
    float f = fract(x);
    return mix(ctx_hash(i), ctx_hash(i + 1.0), f * f * (3.0 - 2.0 * f));
}

float ctx_noise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(ctx_hash2(i), ctx_hash2(i + vec2(1.0, 0.0)), f.x),
               mix(ctx_hash2(i + vec2(0.0, 1.0)), ctx_hash2(i + vec2(1.0)), f.x), f.y);
}

// Phase of a pattern drifting right along the text at speed glyph pixels a tick, one cycle every len pixels
float ctx_flow(CtxFrag f, float len, float speed) {
    return (f.X - f.t * speed) / len;
}

// A looping gradient a → b → c → a over each whole phase
vec3 ctx_cycle3(float p, vec3 a, vec3 b, vec3 c) {
    float q = fract(p) * 3.0;
    return q < 1.0 ? mix(a, b, q) : q < 2.0 ? mix(b, c, q - 1.0) : mix(c, a, q - 2.0);
}

// One effect's pixel. color carries the vertex colour (white on a glow and a glowing effect's shadow) with the world
// light. Colours come from continuous positions, so they flow smoothly instead of stepping a glyph pixel or a letter at
// a time.
vec4 ctx_effect(int fx, vec4 color, CtxFrag f, sampler2D atlas) {
    if (f.kind == CTX_HIDDEN) return vec4(0.0);
    if (f.kind == CTX_SHADOW) return color;
    if (f.kind == CTX_SHADOW_PLAIN) return vec4(ctx_glow_dark(fx, f.X, f.t) * color.rgb, color.a);
    if (f.kind == CTX_GLOW_QUAD) {
        // the quad has room round the letter for its glow, at any size up to CTX_PULL units a glyph pixel. Glows lie
        // under everything else of the text (the glow pass comes first), so nothing here keeps them off anything.
        vec2 p = f.gc;
        if (p.x < -CTX_GLOW || p.y < -CTX_GLOW || p.x > f.gw + CTX_GLOW || p.y > 8.0 + CTX_GLOW) {
            return vec4(0.0);
        }
        vec4 g = ctx_glow(fx, f.X, f.y, f.t);
        return vec4(g.rgb * color.rgb, g.a * color.a * ctx_glow_strength(ctx_glyph_cover(f, p, atlas)));
    }
    float y = f.y;
    vec3 col;
    if (fx == CTX_GOLDEN) {
        col = ctx_cycle3(ctx_flow(f, 24.0, 0.9) + y * 0.04, ctx_hex(0xffd23f), ctx_hex(0xfff3a0), ctx_hex(0xe0a010));
    } else if (fx == CTX_DIAMOND) {
        col = ctx_cycle3(ctx_flow(f, 28.0, 1.05) + y * 0.04, ctx_hex(0x5ce1e6), ctx_hex(0xe6ffff), ctx_hex(0x2fb3d6));
    } else if (fx == CTX_COMMON) {
        float w = 0.5 + 0.5 * sin(ctx_flow(f, 30.0, 1.6) * 2.0 * CTX_PI);   // a soft light band drifting right
        col = mix(ctx_hex(0xabbac9), ctx_hex(0xc3d1db), w * w * w);
    } else if (fx == CTX_UNCOMMON) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0x6cd63c), ctx_hex(0xadf558), ctx_hex(0x51c930));
    } else if (fx == CTX_RARE) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0x2a9ae0), ctx_hex(0x44e2ff), ctx_hex(0x1f7cd3));
    } else if (fx == CTX_SUPER_RARE) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0x4a6cf0), ctx_hex(0x63a7ff), ctx_hex(0x3d4ee3));
    } else if (fx == CTX_EPIC) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0xa855e8), ctx_hex(0xe272ff), ctx_hex(0x8c48db));
    } else if (fx == CTX_LEGENDARY) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0xf0a23c), ctx_hex(0xffdd54), ctx_hex(0xe38430));
    } else if (fx == CTX_MYTHIC) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0xe64848), ctx_hex(0xff8864), ctx_hex(0xc72e52));
    } else if (fx == CTX_EXOTIC) {
        float band = mod(floor((f.X + y - f.t * 0.3) / 3.0), 2.0);   // candy stripes sliding right
        col = min((band < 0.5 ? ctx_hex(0xff5cdd) : ctx_hex(0xffbdf1)) * mix(1.05, 0.88, clamp(y / 7.0, 0.0, 1.0)), 1.0);
    } else if (fx == CTX_DIVINE) {
        col = ctx_cycle3(ctx_flow(f, 32.0, 1.4) + y * 0.03, ctx_hex(0x52cfe3), ctx_hex(0x71fff1), ctx_hex(0x3790c4));
    } else if (fx == CTX_CELESTIAL) {
        col = ctx_cycle3(ctx_flow(f, 32.0, 0.84) + y * 0.03, ctx_hex(0xaab6dc), ctx_hex(0xd6e7fb), ctx_hex(0x98a0cf));
    } else if (fx == CTX_RADIANT) {
        col = ctx_cycle3(ctx_flow(f, 32.0, 1.4) + y * 0.03, ctx_hex(0xf2c43c), ctx_hex(0xffe854), ctx_hex(0xd39224));
    } else if (fx == CTX_ASTRAL) {
        // clouds of colour drifting through the letters, blending into each other
        float n = ctx_noise2(vec2(f.X * 0.16 - f.t * 0.04, y * 0.3 + f.t * 0.02));
        col = mix(ctx_hex(0x5b45d6), ctx_hex(0x8a6cff), smoothstep(0.15, 0.4, n));
        col = mix(col, ctx_hex(0xc77dff), smoothstep(0.4, 0.62, n));
        col = mix(col, ctx_hex(0xff8ad8), smoothstep(0.62, 0.85, n));
    } else if (fx == CTX_ETERNAL) {
        // curtains of light flowing along the word, a violet edge now and then
        float a = 0.5 + 0.5 * sin(f.X * 0.13 - f.t * 0.21 + y * 0.45);
        col = mix(ctx_hex(0x0fa59d), ctx_hex(0x39e38a), a);
        col = mix(col, ctx_hex(0x8f7dff), smoothstep(0.55, 0.9, ctx_noise(f.X * 0.08 - f.t * 0.06)) * clamp(y / 7.0, 0.0, 1.0));
    } else if (fx == CTX_ECLIPSE) {
        col = ctx_cycle3(ctx_flow(f, 36.0, 1.6) + y * 0.03, ctx_hex(0x52307a), ctx_hex(0x9a62d8), ctx_hex(0x3a2259));
    } else if (fx == CTX_MERGE) {
        col = mix(ctx_hex(0xffd541), ctx_hex(0xfff0b3), ctx_flash(f.t));   // with its pad's plate, about as bright
    } else if (fx == CTX_MERGE_LINE) {
        col = mix(ctx_hex(0xf2d6a2), ctx_hex(0xfff0d0), ctx_flash(f.t));   // the line under the title, as bright as it
    } else {
        col = ctx_hsv(ctx_godly_hue(f.X + y * 0.8, f.t), 0.72, 1.0);   // Godly
    }
    return vec4(col * color.rgb, color.a);
}

// How many pixels the parkour flag's column drops in frame (0 to 7): from the third column, up to 1 near the pole and
// up to 2 further out, a wave running away from it. IconArt.flutter draws the same frames (icons-flutter.png): change
// them together.
float ctx_flutter(float column, float frame) {
    float reach = column <= 2.0 ? 0.0 : column <= 4.0 ? 1.0 : 2.0;
    return floor(reach * (0.5 - 0.5 * cos(2.0 * CTX_PI * ((column - 2.0) / 7.0 - frame / 8.0))) + 0.5);
}

// A pixel of the fluttering parkour icon (CTX_FLUTTER) or its shadow: its glyph is 9 pixels square, the flag in rows 1
// to 5 of the columns from the third with room under them, and each of those columns shows the flag ctx_flutter
// pixels lower, a frame every 3 ticks. The glyph's place in the atlas comes from the derivatives, as in ctx_frag.
vec4 ctx_flutter_px(vec4 tint, vec4 info, vec2 uv, vec4 local, sampler2D atlas) {
    vec2 lp = local.xy;
    vec2 tuv = uv * vec2(textureSize(atlas, 0));
    float wt = length(vec2(dFdx(tuv.x), dFdy(tuv.x))) / max(length(vec2(dFdx(lp.x), dFdy(lp.x))), 1e-6);
    float ht = length(vec2(dFdx(tuv.y), dFdy(tuv.y))) / max(length(vec2(dFdx(lp.y), dFdy(lp.y))), 1e-6);
    vec2 o = floor(tuv - lp * vec2(wt, ht) + 0.5);   // the glyph's top-left texel
    float ts = max(ht / 9.0, 1e-3);                  // atlas texels per glyph pixel
    vec2 p = clamp(floor((tuv - o) / ts), vec2(0.0), vec2(max(floor(wt / ts + 0.5), 1.0) - 1.0, 8.0));
    if (p.x >= 2.0) {
        float dy = ctx_flutter(p.x, mod(floor(info.w / 3.0), 8.0));
        if (p.y - dy >= 1.0 && p.y - dy <= 5.0) {
            p.y -= dy;
        } else if (p.y >= 1.0 && p.y <= 5.0) {
            return vec4(0.0);   // where the flag was before it dropped
        }
    }
#ifdef IS_GRAYSCALE
    return texelFetch(atlas, ivec2(o + (p + 0.5) * ts), 0).rrrr * tint;
#else
    return texelFetch(atlas, ivec2(o + (p + 0.5) * ts), 0) * tint;
#endif
}

// A text pixel: tint is the vertex colour times ColorModulator, texColor the glyph texel at uv in atlas, info and
// local what ctx_vertex and ctx_project returned, pos the vertex position passed on. Ordinary text comes back as
// vanilla draws it.
vec4 ctx_fragment(vec4 tint, vec4 texColor, vec4 info, vec2 uv, vec4 local, vec3 pos, sampler2D atlas) {
    vec4 color = texColor * tint;
    if (info.x < 0.0) return info.x < CTX_FLUTTERING + 0.5 ? ctx_flutter_px(tint, info, uv, local, atlas) : color;
    int fx = int(info.x + 0.5);
    CtxFrag f = ctx_frag(info, uv, local, pos, atlas);
    // A grown quad's texture sample is the glyph stretched over the whole quad, so it's no use there: a glow takes its
    // light and strength from the vertex alone (a wobbling letter's quad only moves, so it keeps its sample).
    if (f.kind == CTX_GLOW_QUAD) color = tint;
    return ctx_effect(fx, color, f, atlas);
}

#endif

#ifndef CHICKINS_GLOW_ITEM_GLSL
#define CHICKINS_GLOW_ITEM_GLSL

// The glow round a world label's text effect, drawn by an item display just behind the label (see CTX_GLOW_IN_ITEMS
// in chickins_text.glsl, included first). The item is the pack's chickins:glow/<rarity>: a flat quad where the label's
// first line is, whose texture is that line at a texel a font pixel. A letter's pixel is (its row × 16 + its column
// in the glyph, letter index, 77, 3): barely there, so the game's own item shader drops it; everything else is clear.
// The item's tint says which effect: R 244, G 128 + 4 × effect, B 77. The glow is the text shader's (ctx_glow, the
// wobble, the falloff), on the same clock and at the letters' own text positions, so it follows them.

#define CTX_ITEM_MARK 77
#define CTX_ITEM_REACH 5   // texels searched round a pixel: the glow's reach plus the wobble's

// The effect an item vertex's tint asks for, or -1 for an ordinary item
int ctx_item_effect(vec4 color) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if (c.r == 244 && c.b == CTX_ITEM_MARK && c.g >= 128 && c.g <= 255 && (c.g & 3) == 0) {
        return (c.g - 128) >> 2;
    }
    return -1;
}

// The glow at texture coordinate uv of a glow item's texture in atlas: (colour, strength)
vec4 ctx_item_glow(int fx, vec2 uv, sampler2D atlas, float t) {
    vec2 p = uv * vec2(textureSize(atlas, 0));   // in texels, which are the label's font pixels
    ivec2 base = ivec2(floor(p));
    float wobble = ctx_wobble(fx);
    // where p is along the text for the letters round it, as their own pixels count it (CtxFrag's X and y), weighted
    // by each pixel's share of the blur (ctx_cover): a letter's colours carry on into its glow, and blend into the
    // next letter's. The weights' sum is the letters' shape blurred, the glow's strength.
    vec3 at = vec3(0.0);
    for (int dy = -CTX_ITEM_REACH; dy <= CTX_ITEM_REACH; dy++) {
        for (int dx = -CTX_ITEM_REACH; dx <= CTX_ITEM_REACH; dx++) {
            ivec2 texel = base + ivec2(dx, dy);
            ivec4 m = ivec4(round(texelFetch(atlas, texel, 0) * 255.0));
            if (m.b != CTX_ITEM_MARK || m.a != 3) {
                continue;
            }
            float letter = float(m.g);
            vec2 inGlyph = vec2(float(m.r & 15), float(m.r >> 4));
            vec2 low = vec2(texel) + vec2(0.0, wobble > 0.0 ? sin(t * wobble - letter * 0.5) * CTX_WOBBLE : 0.0);
            vec2 g = p - (low - inGlyph) - 0.5;   // from the glyph's top left
            at += vec3(letter * 6.0 + g.x, g.y, 1.0) * ctx_cover(low, p);
        }
    }
    if (at.z <= 1e-5) {
        return vec4(0.0);
    }
    vec4 glow = ctx_glow(fx, at.x / at.z, at.y / at.z, t);
    float a = glow.a * ctx_glow_strength(at.z);
    // the text draws a bold letter twice, each copy with its glow; their halos lie on top of each other
    return vec4(glow.rgb, 1.0 - (1.0 - a) * (1.0 - a));
}

#endif

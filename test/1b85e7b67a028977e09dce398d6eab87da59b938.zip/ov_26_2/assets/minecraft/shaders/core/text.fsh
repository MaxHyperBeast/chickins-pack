#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:chickins_text.glsl>
#moj_import <minecraft:chickins_flash.glsl>
#moj_import <minecraft:chickins_text_frag.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 ctxInfo;
in vec4 ctxLocal;
in vec3 ctxPos;

out vec4 fragColor;

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = ctx_fragment(vertexColor, texColor, ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);
#else
    vec4 color = ctx_fragment(vertexColor * ColorModulator, texColor, ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);
#endif
    if (color.a < ctx_cutoff(ctxInfo)) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}

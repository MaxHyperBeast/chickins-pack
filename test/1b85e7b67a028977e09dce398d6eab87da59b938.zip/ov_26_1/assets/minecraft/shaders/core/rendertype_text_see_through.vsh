#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chickins_text.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

out vec4 vertexColor;
out vec2 texCoord0;
flat out vec4 ctxInfo;
out vec4 ctxLocal;
out vec3 ctxPos;

void main() {
    vec3 position = Position;
    vec4 color = Color;
    ctxInfo = ctx_vertex(color, position, ModelViewMat, ProjMat, GameTime, CTX_VERTEX_ID, ctxLocal);
    gl_Position = ctx_project(ProjMat * ModelViewMat * vec4(position, 1.0), ctxInfo, position, ModelViewMat, ProjMat);
    ctxPos = position;

    vertexColor = color;
    texCoord0 = UV0;
}

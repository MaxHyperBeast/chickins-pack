#version 330
// Chickins: a greyscale glyph (IS_GRAYSCALE, a TrueType font's) is drawn as vanilla draws it, with nothing of the pack's
// included or called, and a program that isn't the GUI's leaves the GUI's code out (CTX_WORLD_TEXT): text.vsh says why
#ifndef IS_GRAYSCALE
#define CTX_TEXT
#ifndef IS_GUI
#define CTX_WORLD_TEXT
#endif
#endif
// See-through text (a label over a nest, the tutorial's line on the floor, a name tag) is in none of the new rarities'
// effects but the Rainbow modifier's, so its program leaves the rest of them out: CTX_SEE_THROUGH_TEXT
#ifdef CTX_TEXT
#ifdef IS_SEE_THROUGH
#define CTX_SEE_THROUGH_TEXT
#endif
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#ifdef CTX_TEXT
#moj_import <minecraft:chickins_text.glsl>
#moj_import <minecraft:chickins_flash.glsl>
#moj_import <minecraft:chickins_text_frag.glsl>
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
#ifdef CTX_TEXT
flat in vec4 ctxInfo;
in vec4 ctxLocal;
in vec3 ctxPos;
#endif

out vec4 fragColor;

void main() {
#ifdef CTX_TEXT
    vec4 texColor = texture(Sampler0, texCoord0);

#ifdef IS_SEE_THROUGH
    vec4 color = ctx_fragment(vertexColor, texColor, ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);
#else
    vec4 color = ctx_fragment(vertexColor * ColorModulator, texColor, ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);
#endif
    if (color.a < ctx_cutoff(ctxInfo)) {
        discard;
    }
#else
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }
#endif

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}

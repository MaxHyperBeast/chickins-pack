#version 330
#extension GL_ARB_separate_shader_objects : require
// Chickins: a greyscale glyph (IS_GRAYSCALE, a TrueType font's) is drawn as vanilla draws it, with nothing of the pack's
// included or called, and a program that isn't the GUI's leaves the GUI's code out (CTX_WORLD_TEXT): text.vsh says why
#ifndef IS_GRAYSCALE
#define CTX_TEXT
#ifndef IS_GUI
#define CTX_WORLD_TEXT
#endif
#endif
// See-through text (a label over a nest, the tutorial's line on the floor, a name tag) is in none of the new rarities'
// effects but the Rainbow modifier's, so its program leaves the rest of them out: CTX_SEE_THROUGH_TEXT
#ifdef CTX_TEXT
#ifdef IS_SEE_THROUGH
#define CTX_SEE_THROUGH_TEXT
#endif
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifdef CTX_TEXT
#include <minecraft:chickins_text.glsl>
#include <minecraft:chickins_flash.glsl>
#include <minecraft:chickins_text_frag.glsl>
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
#ifdef CTX_TEXT
layout(location = 4) flat in vec4 ctxInfo;
layout(location = 5) in vec4 ctxLocal;
layout(location = 6) in vec3 ctxPos;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef CTX_TEXT
    vec4 texColor = texture(Sampler0, texCoord0);

    vec4 color = ctx_fragment(vertexColor * ColorModulator, texColor, ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);

    if (color.a < ctx_cutoff(ctxInfo)) {
        discard;
    }
    #else
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}

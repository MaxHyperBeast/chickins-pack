#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;

// Chickins: the Tab's strip. With nobody listed (TabFeature unlists everyone) the client fills a strip 24 pixels wide
// down the middle of the Tab's header, and a row under it, in half black (26.2 PlayerTabOverlay: Integer.MIN_VALUE).
// The pack's plate covers it, but not the gap between the offline bar's plaque and the plate, so it's dropped here:
// gui.fsh discards a colour with no alpha. Nothing else the GUI fills is that colour and that narrow on the screen's
// middle (the chat box is that colour, but the screen's width). Written out here, with no include, as vanilla's gui
// shaders are built at startup too, before packs.
const float CTX_TAB_STRIP_REACH = 14.0;   // GUI pixels from the middle: the strip's 12, and a scaled width's rounding

bool ctx_tab_strip(vec4 color, vec4 clip) {
    return all(lessThan(abs(color - vec4(0.0, 0.0, 0.0, 128.0 / 255.0)), vec4(0.002)))
        && abs(clip.x / clip.w / ProjMat[0][0]) <= CTX_TAB_STRIP_REACH;
}

// Chickins: a claim card's click strip (lol.chickins.fit FitCard): one text box of the card's hidden buttons, which
// the client outlines in white once a click in it focuses it (26.2 FocusableTextWidget: GuiGraphicsExtractor.outline,
// four fills). The card is drawn over its own button and the outline round the whole strip would show, so its sides
// are dropped: a vertex of opaque white on the strip's corners or a pixel in from them, which is where all four fills'
// corners are. The strip is the card's body, centred, CTX_FIT_SMALL_BOX or CTX_FIT_GIFT_BOX wide and CTX_FIT_STRIP_H
// high, from where the client starts a body CTX_FIT_CARD_BODY high (26.2 HeaderAndFooterLayout: 63 down, or as low as
// it fits). FitCard has the same numbers (ResourcePackTest).
const float CTX_FIT_SMALL_BOX = 156.0;
const float CTX_FIT_GIFT_BOX = 140.0;
const float CTX_FIT_STRIP_H = 188.0;
const float CTX_FIT_CARD_BODY = 198.0;
const float CTX_FIT_BODY_TOP = 63.0;
const float CTX_FIT_FOOTER = 5.0;

// Whether at is one of a side's two pixel lines' edges: from, from + 1, from + size - 1 or from + size.
bool ctx_fit_edge(float at, float from, float size) {
    float d = at - from;
    return abs(d) < 0.01 || abs(d - 1.0) < 0.01 || abs(d - size + 1.0) < 0.01 || abs(d - size) < 0.01;
}

bool ctx_fit_strip(vec4 color, vec4 clip) {
    if (any(lessThan(color, vec4(0.998)))) return false;
    // the GUI's size, as the client lays the screen out (rounded up), and where the vertex is on it
    float width = ceil(2.0 / ProjMat[0][0] - 0.001);
    float height = ceil(2.0 / abs(ProjMat[1][1]) - 0.001);
    vec2 at = (clip.xy / clip.w - ProjMat[3].xy) / vec2(ProjMat[0][0], ProjMat[1][1]);
    float top = min(CTX_FIT_BODY_TOP, height - CTX_FIT_FOOTER - CTX_FIT_CARD_BODY);
    return ctx_fit_edge(at.y, top, CTX_FIT_STRIP_H)
        && (ctx_fit_edge(at.x, floor((width - CTX_FIT_SMALL_BOX) / 2.0), CTX_FIT_SMALL_BOX)
            || ctx_fit_edge(at.x, floor((width - CTX_FIT_GIFT_BOX) / 2.0), CTX_FIT_GIFT_BOX));
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = ctx_tab_strip(Color, gl_Position) || ctx_fit_strip(Color, gl_Position) ? vec4(0.0) : Color;
}

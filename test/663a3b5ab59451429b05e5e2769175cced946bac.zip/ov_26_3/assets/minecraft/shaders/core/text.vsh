#version 330
#extension GL_ARB_separate_shader_objects : require
// Chickins: the game builds this shader several ways, some of them for greyscale glyphs (IS_GRAYSCALE), and those are
// vanilla's, with nothing of the pack's included or called. A greyscale glyph is a TrueType font's, which only a
// player's own font pack has: the game's fonts and the pack's are bitmaps, and those and the Unicode fallback are all
// coloured. 1.21.11 and 26.1 never hooked the shader that draws them (rendertype_text_intensity), nothing the pack
// draws is one, and they were a third of what a driver builds of the pack's text shaders while the pack loads.
// And a program that isn't the GUI's (no IS_GUI: the GUI's text has programs of its own from 26.2, GUI_TEXT) never draws
// a popup, a card in the screen's corner or a fitted menu, so it leaves all their code out: CTX_WORLD_TEXT, which
// chickins_text.glsl says more about.
#ifndef IS_GRAYSCALE
#define CTX_TEXT
#ifndef IS_GUI
#define CTX_WORLD_TEXT
#endif
#endif
// See-through text (a label over a nest, the tutorial's line on the floor, a name tag) is in none of the new rarities'
// effects but the Rainbow modifier's, so its program leaves the rest of them out: CTX_SEE_THROUGH_TEXT
#ifdef CTX_TEXT
#ifdef IS_SEE_THROUGH
#define CTX_SEE_THROUGH_TEXT
#endif
#endif

#ifdef CTX_TEXT
// the draw's base vertex, which comes off CTX_VERTEX_ID (chickins_text.glsl), declared as item.vsh says why
#ifdef RENDERPEARL_INSTANCE_INDEX_INCLUDES_BASE_INSTANCE
#extension GL_EXT_spirv_intrinsics : require
spirv_decorate (capabilities = [4427], 11, 4424) in int ctxBaseVertex;
#define CTX_BASE_VERTEX ctxBaseVertex
#else
// no base vertex on this device: a glyph's corner comes from its texture coordinates (item.vsh says more)
#define CTX_NO_CORNERS
#endif
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#ifdef CTX_TEXT
#include <minecraft:globals.glsl>
#include <minecraft:chickins_text.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef CTX_TEXT
layout(location = 4) flat out vec4 ctxInfo;
layout(location = 5) out vec4 ctxLocal;
layout(location = 6) out vec3 ctxPos;
#endif

void main() {
    vec4 color = Color;
#ifdef CTX_TEXT
    vec3 position = Position;
#ifdef CTX_NO_CORNERS
    ctxInfo = ctx_vertex(color, position, ModelViewMat, ProjMat, GameTime, ctx_uv_corner(UV0), ctxLocal);
#else
    ctxInfo = ctx_vertex(color, position, ModelViewMat, ProjMat, GameTime, CTX_VERTEX_ID, ctxLocal);
#endif
    gl_Position = ctx_project(ProjMat * ModelViewMat * vec4(position, 1.0), ctxInfo, position, ModelViewMat, ProjMat);
    ctxPos = position;
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color * sample_lightmap(Sampler2, UV2);
#ifdef CTX_TEXT
    gl_Position.z += ctx_screen_text_depth(UV2, Position, ProjMat);   // a Chickin Surfers screen's text
#endif
#else
    vertexColor = color;
#endif
    texCoord0 = UV0;
}

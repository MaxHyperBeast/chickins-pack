#version 330

#moj_import <minecraft:dynamictransforms.glsl>
// Chickins: see-through text is the world's (a label over a nest, the tutorial's line on the floor, a name tag), never
// the GUI's, and none of it is in a new rarity's effect, so this shader is built without the GUI's code and without
// those effects, which together are over half of it (chickins_text.glsl says what CTX_WORLD_TEXT and
// CTX_SEE_THROUGH_TEXT leave out)
#define CTX_WORLD_TEXT
#define CTX_SEE_THROUGH_TEXT
#moj_import <minecraft:chickins_text.glsl>
#moj_import <minecraft:chickins_flash.glsl>
#moj_import <minecraft:chickins_text_frag.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 ctxInfo;
in vec4 ctxLocal;
in vec3 ctxPos;

out vec4 fragColor;

void main() {
    vec4 color = ctx_fragment(vertexColor, texture(Sampler0, texCoord0), ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);
    if (color.a < ctx_cutoff(ctxInfo)) {
        discard;
    }
    fragColor = color * ColorModulator;
}

#version 330
// Chickins: the draw's base vertex, which comes off CTX_VERTEX_ID (chickins_lucky.glsl). On OpenGL the device's own
// compiler builds this, with the extension where the device has it. 26.2's Vulkan backend requires draw parameters but
// builds this file with shaderc, which only declares gl_BaseVertexARB from 440, so there this declares the SPIR-V
// built-in itself (capability DrawParameters, BuiltIn BaseVertex). text.vsh has the same.
#ifdef VULKAN
#extension GL_EXT_spirv_intrinsics : require
spirv_decorate (capabilities = [4427], 11, 4424) in int ctxBaseVertex;
#define CTX_BASE_VERTEX ctxBaseVertex
#else
#extension GL_ARB_shader_draw_parameters : enable
#ifdef GL_ARB_shader_draw_parameters
#define CTX_BASE_VERTEX gl_BaseVertexARB
#endif
#endif

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chickins_flash.glsl>
#moj_import <minecraft:chickins_lucky.glsl>
#moj_import <minecraft:chickins_surfers.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;
flat out vec4 ctxLucky;
out vec2 ctxLuckyUv;
out vec4 ctxScreen;

void main() {
    vec4 ctxAt = vec4(Position, 1.0);
    vec3 ctxNormal = Normal;
    vec3 ctxFogAt = Position;
    ctxScreen = vec4(0.0);
    float ctxDepth = 0.0;
    bool ctxSurfers = ctx_surfers_piece(Color);
    if (ctxSurfers) {
        ctx_surfers_vertex(Color, Position, CTX_VERTEX_ID, GameTime, vec3(CameraBlockPos) - CameraOffset, ProjMat, ctxAt, ctxNormal, ctxFogAt, ctxScreen, ctxDepth);   // chickins_surfers.glsl
    }
    gl_Position = ProjMat * (ctx_surfers_own(Color) ? ctx_surfers_own_view(ctxAt) : ModelViewMat * ctxAt);
    gl_Position.z += ctxDepth;

    sphericalVertexDistance = fog_spherical_distance(ctxFogAt);
    cylindricalVertexDistance = fog_cylindrical_distance(ctxFogAt);

    ctxLucky = ctx_lucky_info(ctxSurfers ? vec4(1.0) : Color, GameTime);
    ctxLuckyUv = ctx_lucky_corner(CTX_VERTEX_ID);
    // a Lucky Block's tint only says which one it is; a Rainbow egg's goes round the rainbow
    vec4 tint = ctxLucky.x >= 0.0 || ctxSurfers ? vec4(1.0) : ctx_rainbow_tint(Color, GameTime, CTX_VERTEX_ID);
    vertexColor = (ctx_surfers_unlit(Color) ? tint : minecraft_mix_light(Light0_Direction, Light1_Direction, ctxNormal, tint));
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
}

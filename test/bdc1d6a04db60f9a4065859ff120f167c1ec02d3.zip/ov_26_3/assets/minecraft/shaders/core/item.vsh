#version 330
#extension GL_ARB_separate_shader_objects : require
// Chickins: the draw's base vertex, which comes off CTX_VERTEX_ID (chickins_lucky.glsl), where 26.3 says the device has
// draw parameters. shaderc only declares gl_BaseVertexARB from 440, so this declares the SPIR-V built-in itself
// (capability DrawParameters, BuiltIn BaseVertex); an OpenGL device gets it back as gl_BaseVertexARB in GLSL 330
// (GlPipelineRecompiler). text.vsh has the same.
#ifdef RENDERPEARL_INSTANCE_INDEX_INCLUDES_BASE_INSTANCE
#extension GL_EXT_spirv_intrinsics : require
spirv_decorate (capabilities = [4427], 11, 4424) in int ctxBaseVertex;
#define CTX_BASE_VERTEX ctxBaseVertex
#endif

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:chickins_flash.glsl>
#include <minecraft:chickins_lucky.glsl>
#include <minecraft:chickins_surfers.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif
layout(location = 7) flat out vec4 ctxLucky;
layout(location = 8) out vec2 ctxLuckyUv;
layout(location = 9) out vec4 ctxScreen;

void main() {
    vec4 ctxAt = vec4(Position, 1.0);
    vec3 ctxNormal = Normal;
    vec3 ctxFogAt = Position;
    ctxScreen = vec4(0.0);
    float ctxDepth = 0.0;
    bool ctxSurfers = ctx_surfers_piece(Color);
    if (ctxSurfers) {
        ctx_surfers_vertex(Color, Position, CTX_VERTEX_ID, GameTime, vec3(CameraBlockPos) - CameraOffset, ProjMat, ctxAt, ctxNormal, ctxFogAt, ctxScreen, ctxDepth);   // chickins_surfers.glsl
    }
    gl_Position = ProjMat * (ctx_surfers_own(Color) ? ctx_surfers_own_view(ctxAt) : ModelViewMat * ctxAt);
    gl_Position.z += ctxDepth;

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(ctxFogAt);
    cylindricalVertexDistance = fog_cylindrical_distance(ctxFogAt);
    #endif
    ctxLucky = ctx_lucky_info(ctxSurfers ? vec4(1.0) : Color, GameTime);
    ctxLuckyUv = ctx_lucky_at(ctxLucky, CTX_VERTEX_ID);
    // a Lucky Block's tint only says which one it is, and a Rainbow egg's which face of it
    vec4 tint = ctxLucky.x >= 0.0 || ctxSurfers ? vec4(1.0) : Color;
    vertexColor = (ctx_surfers_unlit(Color) ? tint : minecraft_mix_light(Light0_Direction, Light1_Direction, ctxNormal, tint));
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}

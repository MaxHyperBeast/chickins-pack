#ifndef CHICKINS_TEXT_FRAG_GLSL
#define CHICKINS_TEXT_FRAG_GLSL

// Fragment half of the text effects (see chickins_text.glsl, included first, as is chickins_flash.glsl: every release
// includes this file, and they don't share a directive to do it here).

// Where a fragment sits in its glyph. The glyph's size in the atlas comes from how fast the atlas coordinate moves
// against the quad-local one (the texture coordinates stay the glyph's when the vertex stage moves or grows a quad),
// and its size in the world or on screen from how fast the position does, less the room the vertex stage grew it by.
// So it works on Minecraft's packed font atlas and for text at any size.
struct CtxFrag {
    float k;       // letter index along the text
    float kind;    // CTX_LETTER, CTX_SHADOW, CTX_SHADOW_PLAIN, CTX_GLOW_QUAD or CTX_HIDDEN
    bool shadow;   // a drop-shadow copy (a glow pass's is the glow's canvas)
    float t;       // ticks
    float gw;      // glyph width in glyph pixels
    vec2 gc;       // position in the glyph in glyph pixels from its top left, continuous (outside it in the room round it)
    float X;       // position along the whole text, roughly (k * 6 + column), 0 in the middle of a pixel
    float y;       // row, 0 in the middle of the top pixel
    vec2 o;        // the glyph's top-left texel in the atlas
    float ts;      // atlas texels per glyph pixel
};

// The quad's sides in position units, along the text and down: pos = corner + right * lp.x + down * lp.y, solved from
// the derivatives
vec2 ctx_quad_size(vec2 lp, vec3 pos) {
    vec2 lx = vec2(dFdx(lp.x), dFdy(lp.x));
    vec2 ly = vec2(dFdx(lp.y), dFdy(lp.y));
    vec3 px = dFdx(pos);
    vec3 py = dFdy(pos);
    float det = lx.x * ly.y - ly.x * lx.y;
    return vec2(length(ly.y * px - ly.x * py), length(lx.x * py - lx.y * px)) / max(abs(det), 1e-12);
}

CtxFrag ctx_frag(vec4 info, vec2 uv, vec4 local, vec3 pos, sampler2D atlas) {
    vec2 lp = local.xy;
    vec2 lx = vec2(dFdx(lp.x), dFdy(lp.x));
    vec2 ly = vec2(dFdx(lp.y), dFdy(lp.y));
    vec2 tuv = uv * vec2(textureSize(atlas, 0));
    float wt = length(vec2(dFdx(tuv.x), dFdy(tuv.x))) / max(length(lx), 1e-6);
    float ht = length(vec2(dFdx(tuv.y), dFdy(tuv.y))) / max(length(ly), 1e-6);
    CtxFrag f;
    f.k = info.y;
    f.kind = floor(info.z + 0.5);
    f.shadow = f.kind != CTX_LETTER;
    f.t = info.w;
    f.ts = max(ht / 8.0, 1e-3);
    f.o = floor(tuv - lp * vec2(wt, ht) + 0.5);
    f.gw = max(floor(wt / f.ts + 0.5), 1.0);
    vec2 size = ctx_quad_size(lp, pos);
    vec2 s = max((size - 2.0 * local.z) / vec2(f.gw, 8.0), 1e-6);   // position units per glyph pixel
    // the letter's top left from the quad's: past the room, and a drop shadow lies a glyph pixel right of and below it
    vec2 letter = vec2(local.z + local.w) - (f.shadow ? s.y : 0.0);
    f.gc = (lp * size - letter) / s;
    f.X = f.k * 6.0 + f.gc.x - 0.5;
    f.y = f.gc.y - 0.5;
    return f;
}

// 1 if glyph pixel p is filled; 0 outside the glyph, so its neighbours in the atlas never leak in
float ctx_px(CtxFrag f, vec2 p, sampler2D atlas) {
    if (p.x < 0.0 || p.y < 0.0 || p.x >= f.gw || p.y >= 8.0) return 0.0;
#ifdef IS_GRAYSCALE
    return texelFetch(atlas, ivec2(f.o + (p + 0.5) * f.ts), 0).r;
#else
    return texelFetch(atlas, ivec2(f.o + (p + 0.5) * f.ts), 0).a;
#endif
}

// The glyph's shape blurred at glyph position p (ctx_cover summed over its filled pixels): a glow that hugs the
// letter's shape and fades smoothly, with no creases
float ctx_glyph_cover(CtxFrag f, vec2 p, sampler2D atlas) {
    float cover = 0.0;
    vec2 base = floor(p);
    for (int dy = -4; dy <= 4; dy++) {
        for (int dx = -4; dx <= 4; dx++) {
            vec2 t = base + vec2(float(dx), float(dy));
            if (ctx_px(f, t, atlas) > 0.5) {
                cover += ctx_cover(t, p);
            }
        }
    }
    return cover;
}

float ctx_hash(float n) {
    return fract(sin(n) * 43758.5453123);
}

float ctx_hash2(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float ctx_noise(float x) {
    float i = floor(x);
    float f = fract(x);
    return mix(ctx_hash(i), ctx_hash(i + 1.0), f * f * (3.0 - 2.0 * f));
}

float ctx_noise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(ctx_hash2(i), ctx_hash2(i + vec2(1.0, 0.0)), f.x),
               mix(ctx_hash2(i + vec2(0.0, 1.0)), ctx_hash2(i + vec2(1.0)), f.x), f.y);
}

// Phase of a pattern drifting right along the text at speed glyph pixels a tick, one cycle every len pixels
float ctx_flow(CtxFrag f, float len, float speed) {
    return (f.X - f.t * speed) / len;
}

// A looping gradient a → b → c → a over each whole phase
vec3 ctx_cycle3(float p, vec3 a, vec3 b, vec3 c) {
    float q = fract(p) * 3.0;
    return q < 1.0 ? mix(a, b, q) : q < 2.0 ? mix(b, c, q - 1.0) : mix(c, a, q - 2.0);
}

// The new rarities' names (lucky-blocks.yml), each the colours and the motion of its block (chickins_lucky.glsl's
// ctx_painted), along the letters: X along the text, y down the row (0 the top pixel's middle), t ticks
vec3 ctx_rarity(int fx, float X, float y, float t) {
    vec3 col;
    if (fx == CTX_BRILLIANT) {   // pale crystal, a white sheen sweeping across
        col = ctx_cycle3((X - t * 0.6) / 32.0 + y * 0.03, ctx_hex(0x5ac4e8), ctx_hex(0xa8e8f8), ctx_hex(0x8ae4f8));
        float k = mod(X + y - t * 1.2, 48.0) - 24.0;
        col = mix(col, vec3(1.0), clamp(exp(-k * k / 10.0) + 0.5 * exp(-(k + 5.0) * (k + 5.0) / 3.0), 0.0, 1.0) * 0.9);
    } else if (fx == CTX_ENCHANTED) {   // an enchanted item's glint, two layers sliding over lilac
        col = mix(ctx_hex(0x7a58e8), ctx_hex(0x9a70f0), clamp(y / 7.0, 0.0, 1.0));
        float g1 = pow(0.5 + 0.5 * sin(6.2831853 * (X / 18.0 - t / 40.0)), 5.0);
        float g2 = pow(0.5 + 0.5 * sin(6.2831853 * ((X * 0.7 + y * 2.0) / 26.0 + t / 60.0)), 7.0);
        float g = clamp(g1 * 0.85 + g2 * 0.65, 0.0, 1.0);
        col = mix(col, ctx_hex(0xe0c0ff), g);
        col = mix(col, ctx_hex(0xfff4ff), g * g * g * 0.6);
    } else if (fx == CTX_MERCURIAL) {   // liquid chrome: bands of light and dark flowing
        float q = fract((X + y * 1.5) / 40.0 - t / 120.0 + 0.12 * sin(X * 0.2 - t * 0.05) + 0.1 * ctx_noise2(vec2(X * 0.1, t * 0.01)));
        col = q < 0.45 ? mix(ctx_hex(0x5a6274), ctx_hex(0xc0c8d8), q / 0.45)
            : q < 0.5 ? mix(ctx_hex(0xc0c8d8), vec3(1.0), smoothstep(0.45, 0.5, q))
            : mix(ctx_hex(0xe4eaf4), ctx_hex(0x7c8698), (q - 0.5) / 0.5);
    } else if (fx == CTX_TOXIC) {   // glowing green sludge, bubbles rising through it
        col = mix(ctx_hex(0x4ea82e), ctx_hex(0x7acc34), 0.5 + 0.5 * sin(X * 0.15 - t * 0.05));
        for (int i = -1; i <= 1; i++) {
            float cell = floor(X / 9.0) + float(i);
            float a = fract(t / 48.0 + ctx_hash(cell * 7.1));
            vec2 at = vec2((cell + 0.5 + 0.5 * (ctx_hash(cell * 3.3) - 0.5)) * 9.0, 9.0 - a * 13.0);
            float d = length(vec2(X, y) - at);
            col = mix(col, ctx_hex(0xd8ff7a), smoothstep(1.8, 1.0, d) * 0.85);
            col = mix(col, ctx_hex(0xf0ffc0), smoothstep(0.9, 0.3, length(vec2(X, y) - at + 0.5)) * 0.8);
        }
    } else if (fx == CTX_SILKEN) {   // emerald satin in soft folds, the sheen running along them
        float T = 6.2831853 * t / 160.0;
        float fold = sin(X / 5.2 + 1.6 * sin(y / 2.2 + T) + 0.8 * sin(X / 14.0 - T));
        col = mix(ctx_hex(0x1e9a62), ctx_hex(0x3acb88), 0.5 + 0.5 * fold);
        col = mix(col, ctx_hex(0xd8ffec), pow(max(0.0, fold), 8.0) * 0.85);
    } else if (fx == CTX_THUNDEROUS) {   // storm clouds drifting, the word flashing, a bolt through it
        col = mix(ctx_hex(0x6a7898), ctx_hex(0x9aaed8), smoothstep(0.3, 0.75, ctx_noise2(vec2(X * 0.12 - t * 0.03, y * 0.3))));
        float lit = ctx_thunder_lit(t);
        float cycle = floor(t / 30.0);
        float bolt = abs(X - (ctx_hash(cycle * 1.7) * 48.0 + 4.0 + 1.6 * sin(y * 1.7 + cycle)));
        col = mix(col, ctx_hex(0xdce4ff), lit * 0.55);
        col = mix(col, vec3(1.0), smoothstep(1.4, 0.4, bolt) * lit);
    } else if (fx == CTX_SHIMMERING) {   // sunlight through water: a net of bright lines wavering over aqua
        float r1 = 1.0 - abs(2.0 * ctx_noise2(vec2(X * 0.2 + t / 60.0, y * 0.3)) - 1.0);
        float r2 = 1.0 - abs(2.0 * ctx_noise2(vec2(X * 0.16 - t / 80.0, y * 0.25 + t / 80.0)) - 1.0);
        float light = pow(max(r1, r2) * 0.75 + min(r1, r2) * 0.3, 6.0);
        col = mix(ctx_hex(0x2ab0c6), ctx_hex(0x1a86a6), clamp(y / 7.0, 0.0, 1.0));
        col = mix(col, ctx_hex(0x7ae8ec), clamp(light * 1.4, 0.0, 1.0));
        col = mix(col, ctx_hex(0xe0fff8), clamp((light - 0.55) * 2.2, 0.0, 1.0));
    } else if (fx == CTX_WOBBLY) {   // cherry jelly, its highlight sloshing about as it jiggles
        float T = mod(t, 60.0);
        float jig = exp(-T / 14.0) * sin(T * 0.75) + 0.25 * sin(6.2831853 * t / 30.0);
        col = mix(ctx_hex(0xf0406e), ctx_hex(0xc01850), clamp(y / 7.0 * 0.6 + 0.15 * sin(X / 8.0 + jig), 0.0, 1.0));
        float spec = exp(-pow(y - 1.5 + 0.8 * jig, 2.0) / 1.2) * (0.5 + 0.5 * sin(X * 0.25 - t * 0.1 + jig * 2.0));
        col = mix(col, ctx_hex(0xffd6e2), spec * 0.75);
    } else if (fx == CTX_PHANTOM) {   // violet mist curling through, the word dimming and glowing like a ghost
        float n = ctx_noise2(vec2(X * 0.12 + t * 0.02, y * 0.25 - t * 0.03));
        float mist = smoothstep(0.45, 0.8, ctx_noise2(vec2(X * 0.2 - t * 0.04 + n * 1.5, y * 0.35 - t * 0.05)) * 0.6 + n * 0.5);
        float breathe = 0.5 + 0.5 * sin(6.2831853 * t / 80.0);
        col = mix(ctx_hex(0x6a4ab8), ctx_hex(0x8a6adc), clamp(y / 7.0 * 0.5 + n * 0.4, 0.0, 1.0));
        col = mix(col, ctx_hex(0xc8b0ff), mist * (0.45 + 0.35 * breathe));
        col = mix(col, ctx_hex(0x3a2a70), 0.25 * (1.0 - breathe));
    } else if (fx == CTX_LUMINOUS) {   // a lava lamp: coral to rose, blobs of cream and gold wax rising and sinking
        col = mix(ctx_hex(0xd8506e), ctx_hex(0xf79a62), clamp((8.0 - y) / 8.0, 0.0, 1.0));
        float field = 0.0;
        for (int i = -1; i <= 1; i++) {
            float cell = floor(X / 14.0) + float(i);
            float period = 96.0 + 32.0 * floor(ctx_hash(cell * 5.3) * 3.0);
            float a = fract(t / period + ctx_hash(cell * 2.9));
            vec2 at = vec2((cell + 0.5) * 14.0 + 3.0 * sin(6.2831853 * (a + ctx_hash(cell))), 3.5 + 6.0 * sin(6.2831853 * a));
            vec2 d = (vec2(X, y) - at) * vec2(0.6, 1.0);
            field += 4.0 / (dot(d, d) + 0.3);
        }
        vec3 wax = mix(mix(ctx_hex(0xffd0c0), ctx_hex(0xffe6a8), smoothstep(1.15, 2.4, field)), ctx_hex(0xfff4d8), smoothstep(2.4, 4.0, field));
        col = mix(col, wax, smoothstep(0.9, 1.15, field));
    } else if (fx == CTX_UNDYING) {   // a heartbeat lighting it, two beats at a time
        float beat = ctx_heartbeat(t);
        col = mix(ctx_hex(0xa0102a), ctx_hex(0xe8304a), 0.5 + 0.5 * sin(X * 0.1 - t * 0.05));
        col = mix(col, ctx_hex(0xff6a7a), clamp(beat, 0.0, 1.0) * 0.8);
    } else if (fx == CTX_MOLTEN) {   // lava surging along, red to gold, crusts of rock drifting on it
        float w = 0.5 + 0.5 * sin(6.2831853 * t / 40.0 - X / 8.0 + y * 0.4);
        col = mix(mix(ctx_hex(0xc8300c), ctx_hex(0xf07018), w), ctx_hex(0xffc848), w * w * w * 0.8);
        col = mix(col, ctx_hex(0x4a2a22), smoothstep(0.62, 0.78, ctx_noise2(vec2(X * 0.25, y * 0.4 + t * 0.02))) * 0.45);
    } else if (fx == CTX_FROZEN) {   // clear ice, frost creeping in and out, a cold sheen gliding over it
        col = mix(ctx_hex(0x7ac4f0), ctx_hex(0xbce6fa), clamp(y / 7.0, 0.0, 1.0));
        float frost = smoothstep(0.55, 0.8, ctx_noise2(vec2(X * 0.3, y * 0.4))) * (0.6 + 0.4 * sin(6.2831853 * t / 160.0));
        col = mix(col, ctx_hex(0xf2faff), clamp(frost, 0.0, 1.0));
        float k = mod(X + y - t * 0.5, 40.0) - 20.0;
        col = mix(col, vec3(1.0), exp(-k * k / 6.0) * 0.7);
    } else if (fx == CTX_BLAZING) {   // flames licking up the letters, deep red at their feet to white-hot at their tips
        float heat = ctx_noise2(vec2(X * 0.3, y * 0.35 + t * 0.15)) * 0.8 + (7.0 - y) / 7.0 * 0.75 - 0.15;
        float k = clamp(heat * 4.0 + 0.2, 0.0, 3.999);
        float i = floor(k);
        vec3 a = i < 1.0 ? ctx_hex(0xb8240e) : i < 2.0 ? ctx_hex(0xe83a1a) : i < 3.0 ? ctx_hex(0xff8a1a) : ctx_hex(0xffd84a);
        vec3 b = i < 1.0 ? ctx_hex(0xe83a1a) : i < 2.0 ? ctx_hex(0xff8a1a) : i < 3.0 ? ctx_hex(0xffd84a) : ctx_hex(0xfff4b0);
        float f = k - i;
        col = mix(a, b, f * f * (3.0 - 2.0 * f));
    } else if (fx == CTX_SOLAR) {   // a sunburst's rays turning across the letters, golden where they meet
        float ray = 0.5 + 0.5 * cos(6.2831853 * (X / 10.0 + (y - 3.5) * 0.15 - t / 80.0));
        col = mix(ctx_hex(0xf06a20), ctx_hex(0xffb850), smoothstep(0.35, 0.65, ray));
        col = mix(col, ctx_hex(0xffe890), ray * ray * ray * ray * 0.6);
    } else if (fx == CTX_LUNAR) {   // the moon's phases: its lit side moving along the word, cratered
        float k = smoothstep(-0.12, 0.12, cos(6.2831853 * (X / 80.0 - t / 400.0)));
        float crater = smoothstep(0.6, 0.7, ctx_noise2(vec2(X * 0.4, y * 0.5)));
        col = mix(mix(ctx_hex(0x6a74a8), ctx_hex(0x4a5488), crater), mix(ctx_hex(0xe4e8f4), ctx_hex(0xa8b0c8), crater), k);
    } else if (fx == CTX_MAJESTIC) {   // ivory and gold, a shaft of golden light sweeping across
        col = mix(ctx_hex(0xf2e6c4), ctx_hex(0xe0c88a), smoothstep(0.55, 0.8, ctx_noise2(vec2(X * 0.25, y * 0.4))) * 0.8);
        float shaft = pow(0.5 + 0.5 * sin(6.2831853 * ((X + y * 0.9) / 32.0 - t / 120.0)), 6.0);
        col = mix(col, ctx_hex(0xf0b83a), shaft * 0.8);
        col = mix(col, ctx_hex(0xfff0c0), shaft * shaft * shaft * 0.45);
    } else if (fx == CTX_CASCADING) {   // a waterfall pouring down the letters in streaks, foaming at their feet
        float w = ctx_noise2(vec2(X * 0.6, y * 0.3 - t * 0.15)) * 0.7 + ctx_noise2(vec2(X * 1.2, y * 0.6 - t * 0.3)) * 0.3;
        col = mix(ctx_hex(0x2a70c0), ctx_hex(0x6ac0f0), smoothstep(0.25, 0.75, w));
        col = mix(col, ctx_hex(0xe8f6ff), smoothstep(0.68, 0.85, w) * 0.85);
        col = mix(col, vec3(1.0), smoothstep(5.0, 7.5, y + ctx_noise2(vec2(X * 0.5, t * 0.2)) * 1.5) * 0.8);
    } else if (fx == CTX_GALACTIC) {   // violet arms glowing pink drifting along, stars twinkling in them
        col = mix(ctx_hex(0x5a3ac8), ctx_hex(0xb07af0), 0.5 + 0.5 * sin(X * 0.12 - t * 0.03 + y * 0.2));
        float arm = 0.5 + 0.5 * cos(6.2831853 * (X / 20.0 - t / 240.0) + y * 0.3);
        col = mix(col, ctx_hex(0xf070c8), arm * arm * arm * 0.7);
        vec2 cell = floor(vec2(X, y) / 4.0);
        if (ctx_hash2(cell) > 0.75) {
            float d = length(vec2(X, y) - (cell + 0.3 + 0.4 * vec2(ctx_hash2(cell + 7.0), ctx_hash2(cell + 13.0))) * 4.0);
            col = mix(col, ctx_hex(0xfff0f8), smoothstep(0.9, 0.2, d) * (0.5 + 0.5 * sin(6.2831853 * (t / 60.0 + ctx_hash2(cell + 3.0)))));
        }
    } else if (fx == CTX_GLITCHED) {   // a screen's cyan rolling down it; now and then it tears into red and white slices
        col = mix(ctx_hex(0x3ae8ff), ctx_hex(0x1ea8c8), (0.5 + 0.5 * sin(6.2831853 * (y / 5.0 - t / 40.0))) * 0.5);
        float T = mod(t, 60.0);
        if (T >= 42.0 && T < 52.0) {
            float r = ctx_hash2(vec2(floor(y / 1.6), floor(t / 2.0) + floor(X / 3.0) * 17.0));
            col = r > 0.75 ? ctx_hex(0xff4a6a) : r > 0.6 ? vec3(1.0) : col;
        } else {
            col = mix(col, ctx_hex(0xff4a6a), smoothstep(0.92, 0.98, ctx_noise2(vec2(X * 0.5, t * 0.3))) * 0.6);
        }
    } else if (fx == CTX_SHADOWY) {   // the Shadow rarity: pale letters with black smoke curling up them
        float w = ctx_noise2(vec2(X * 0.1, y * 0.15 + t * 0.02));
        float n = ctx_noise2(vec2(X * 0.18 + w * 2.0, y * 0.3 + t * 0.04));
        col = mix(ctx_hex(0xd0d0e4), ctx_hex(0x5a5a70), smoothstep(0.5, 0.78, n) * 0.85);
        col = mix(col, ctx_hex(0xf0f0ff), 0.2 * (0.5 + 0.5 * sin(6.2831853 * t / 60.0)));
    } else if (fx == CTX_INKY) {   // ink curling through pale water in thin wisps
        float w = ctx_noise2(vec2(X * 0.08, y * 0.12 + t / 300.0));
        float n = ctx_noise2(vec2(X * 0.22 + w * 2.6, y * 0.35 + t * 0.02 + w * 2.0));
        float wisp = 1.0 - abs(2.0 * n - 1.0);
        col = mix(ctx_hex(0xc8d0e6), ctx_hex(0x8a94c0), smoothstep(0.5, 0.72, w) * 0.7);
        col = mix(col, ctx_hex(0x3a4280), smoothstep(0.78, 0.92, wisp) * 0.8);
        col = mix(col, ctx_hex(0x141838), smoothstep(0.9, 0.98, wisp) * 0.6);
    } else if (fx == CTX_ELECTRIC) {   // pink plasma, bright tendrils crackling through it, flickering
        col = mix(ctx_hex(0xd040c0), ctx_hex(0xf070d8), 0.5 + 0.5 * sin(X * 0.2 - t * 0.3));
        float r = 1.0 - abs(2.0 * ctx_noise2(vec2(X * 0.4 - t * 0.25, y * 0.5 + t * 0.1)) - 1.0);
        col = mix(col, ctx_hex(0xffe8fa), smoothstep(0.85, 0.97, r));
        col *= 0.88 + 0.12 * sin(6.2831853 * t / 8.0);
    } else if (fx == CTX_TRANSCENDENT) {   // a soft pastel rainbow flowing across, slower than Godly's
        col = ctx_hsv(ctx_transcendent_hue(X + y * 0.8, t), 0.4, 1.0);
    } else if (fx == CTX_RAINBOW) {   // the Rainbow modifier: every hue flowing right along the letters, a little slant down them
        col = ctx_hsv(ctx_rainbow_hue(X, y, t), 0.62, 1.0);
    } else {   // Supreme: rivers of molten gold through black stone, surging brighter
        float warp = ctx_noise2(vec2(X * 0.08, y * 0.12 + t / 300.0));
        float n = ctx_noise2(vec2(X * 0.18 + warp * 2.5, y * 0.3 - t / 150.0));
        float ridge = 1.0 - abs(2.0 * n - 1.0);
        vec3 gold = mix(ctx_hex(0xc8962c), ctx_hex(0xffe27a), 0.5 + 0.5 * sin(6.2831853 * (t / 60.0 - X / 20.0)));
        col = mix(ctx_hex(0x2a2830), gold, 0.35 + 0.65 * smoothstep(0.25, 0.5, ridge));
    }
    return col;
}

// One effect's pixel. color carries the vertex colour (white on a glow and a glowing effect's shadow) with the world
// light. Colours come from continuous positions, so they flow smoothly instead of stepping a glyph pixel or a letter at
// a time.
vec4 ctx_effect(int fx, vec4 color, CtxFrag f, sampler2D atlas) {
    if (f.kind == CTX_HIDDEN) return vec4(0.0);
    if (f.kind == CTX_SHADOW) return color;
    if (f.kind == CTX_SHADOW_PLAIN) return vec4(ctx_glow_dark(fx, f.X, f.t) * color.rgb, color.a);
    if (f.kind == CTX_GLOW_QUAD) {
        // the quad has room round the letter for its glow, at any size up to CTX_PULL units a glyph pixel. Glows lie
        // under everything else of the text (the glow pass comes first), so nothing here keeps them off anything.
        vec2 p = f.gc;
        if (p.x < -CTX_GLOW || p.y < -CTX_GLOW || p.x > f.gw + CTX_GLOW || p.y > 8.0 + CTX_GLOW) {
            return vec4(0.0);
        }
        vec4 g = ctx_glow(fx, f.X, f.y, f.t);
        return vec4(g.rgb * color.rgb, g.a * color.a * ctx_glow_strength(ctx_glyph_cover(f, p, atlas)));
    }
    float y = f.y;
    vec3 col;
    if (fx == CTX_GOLDEN) {
        col = ctx_cycle3(ctx_flow(f, 24.0, 0.9) + y * 0.04, ctx_hex(0xffd23f), ctx_hex(0xfff3a0), ctx_hex(0xe0a010));
    } else if (fx == CTX_DIAMOND) {
        col = ctx_cycle3(ctx_flow(f, 28.0, 1.05) + y * 0.04, ctx_hex(0x5ce1e6), ctx_hex(0xe6ffff), ctx_hex(0x2fb3d6));
    } else if (fx == CTX_COMMON) {
        float w = 0.5 + 0.5 * sin(ctx_flow(f, 30.0, 1.6) * 2.0 * CTX_PI);   // a soft light band drifting right
        col = mix(ctx_hex(0xabbac9), ctx_hex(0xc3d1db), w * w * w);
    } else if (fx == CTX_UNCOMMON) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0x6cd63c), ctx_hex(0xadf558), ctx_hex(0x51c930));
    } else if (fx == CTX_RARE) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0x2a9ae0), ctx_hex(0x44e2ff), ctx_hex(0x1f7cd3));
    } else if (fx == CTX_SUPER_RARE) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0x4a6cf0), ctx_hex(0x63a7ff), ctx_hex(0x3d4ee3));
    } else if (fx == CTX_EPIC) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0xa855e8), ctx_hex(0xe272ff), ctx_hex(0x8c48db));
    } else if (fx == CTX_LEGENDARY) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0xf0a23c), ctx_hex(0xffdd54), ctx_hex(0xe38430));
    } else if (fx == CTX_MYTHIC) {
        col = ctx_cycle3(ctx_flow(f, 30.0, 1.6), ctx_hex(0xe64848), ctx_hex(0xff8864), ctx_hex(0xc72e52));
    } else if (fx == CTX_EXOTIC) {
        float band = mod(floor((f.X + y - f.t * 0.3) / 3.0), 2.0);   // candy stripes sliding right
        col = min((band < 0.5 ? ctx_hex(0xff5cdd) : ctx_hex(0xffbdf1)) * mix(1.05, 0.88, clamp(y / 7.0, 0.0, 1.0)), 1.0);
    } else if (fx == CTX_DIVINE) {
        col = ctx_cycle3(ctx_flow(f, 32.0, 1.4) + y * 0.03, ctx_hex(0x52cfe3), ctx_hex(0x71fff1), ctx_hex(0x3790c4));
    } else if (fx == CTX_CELESTIAL) {
        col = ctx_cycle3(ctx_flow(f, 32.0, 0.84) + y * 0.03, ctx_hex(0xaab6dc), ctx_hex(0xd6e7fb), ctx_hex(0x98a0cf));
    } else if (fx == CTX_RADIANT) {
        col = ctx_cycle3(ctx_flow(f, 32.0, 1.4) + y * 0.03, ctx_hex(0xf2c43c), ctx_hex(0xffe854), ctx_hex(0xd39224));
    } else if (fx == CTX_ASTRAL) {
        // clouds of colour drifting through the letters, blending into each other
        float n = ctx_noise2(vec2(f.X * 0.16 - f.t * 0.04, y * 0.3 + f.t * 0.02));
        col = mix(ctx_hex(0x5b45d6), ctx_hex(0x8a6cff), smoothstep(0.15, 0.4, n));
        col = mix(col, ctx_hex(0xc77dff), smoothstep(0.4, 0.62, n));
        col = mix(col, ctx_hex(0xff8ad8), smoothstep(0.62, 0.85, n));
    } else if (fx == CTX_ETERNAL) {
        // curtains of light flowing along the word, a violet edge now and then
        float a = 0.5 + 0.5 * sin(f.X * 0.13 - f.t * 0.21 + y * 0.45);
        col = mix(ctx_hex(0x0fa59d), ctx_hex(0x39e38a), a);
        col = mix(col, ctx_hex(0x8f7dff), smoothstep(0.55, 0.9, ctx_noise(f.X * 0.08 - f.t * 0.06)) * clamp(y / 7.0, 0.0, 1.0));
    } else if (fx == CTX_ECLIPSE) {
        col = ctx_cycle3(ctx_flow(f, 36.0, 1.6) + y * 0.03, ctx_hex(0x52307a), ctx_hex(0x9a62d8), ctx_hex(0x3a2259));
    } else if (fx == CTX_MERGE) {
        col = mix(ctx_hex(0xffd541), ctx_hex(0xfff0b3), ctx_flash(f.t));   // with its pad's plate, about as bright
    } else if (fx == CTX_MERGE_LINE) {
        col = mix(ctx_hex(0xf2d6a2), ctx_hex(0xfff0d0), ctx_flash(f.t));   // the line under the title, as bright as it
    } else if (fx == CTX_SELL_SPEED) {
        col = mix(ctx_hex(0x3cb1f0), ctx_hex(0xb8eeff), ctx_flash(f.t));   // the same for Sell Speed, its blue gone pale
    } else if (fx == CTX_SELL_SPEED_LINE) {
        col = mix(ctx_hex(0x55ff55), ctx_hex(0xd0ffc8), ctx_flash(f.t));   // and its price's green
    } else if (fx >= CTX_SECOND) {
        col = ctx_rarity(fx, f.X, y, f.t);
    } else {
        col = ctx_hsv(ctx_godly_hue(f.X + y * 0.8, f.t), 0.72, 1.0);   // Godly
    }
    return vec4(col * color.rgb, color.a);
}

// How many pixels the parkour flag's column drops in frame (0 to 7): from the third column, up to 1 near the pole and
// up to 2 further out, a wave running away from it. IconArt.flutter draws the same frames (icons-flutter.png): change
// them together.
float ctx_flutter(float column, float frame) {
    float reach = column <= 2.0 ? 0.0 : column <= 4.0 ? 1.0 : 2.0;
    return floor(reach * (0.5 - 0.5 * cos(2.0 * CTX_PI * ((column - 2.0) / 7.0 - frame / 8.0))) + 0.5);
}

// A pixel of the fluttering parkour icon (CTX_FLUTTER) or its shadow: its glyph is 9 pixels square, the flag in rows 1
// to 5 of the columns from the third with room under them, and each of those columns shows the flag ctx_flutter
// pixels lower, a frame every 3 ticks. The glyph's place in the atlas comes from the derivatives, as in ctx_frag.
vec4 ctx_flutter_px(vec4 tint, vec4 info, vec2 uv, vec4 local, sampler2D atlas) {
    vec2 lp = local.xy;
    vec2 tuv = uv * vec2(textureSize(atlas, 0));
    float wt = length(vec2(dFdx(tuv.x), dFdy(tuv.x))) / max(length(vec2(dFdx(lp.x), dFdy(lp.x))), 1e-6);
    float ht = length(vec2(dFdx(tuv.y), dFdy(tuv.y))) / max(length(vec2(dFdx(lp.y), dFdy(lp.y))), 1e-6);
    vec2 o = floor(tuv - lp * vec2(wt, ht) + 0.5);   // the glyph's top-left texel
    float ts = max(ht / 9.0, 1e-3);                  // atlas texels per glyph pixel
    vec2 p = clamp(floor((tuv - o) / ts), vec2(0.0), vec2(max(floor(wt / ts + 0.5), 1.0) - 1.0, 8.0));
    if (p.x >= 2.0) {
        float dy = ctx_flutter(p.x, mod(floor(info.w / 3.0), 8.0));
        if (p.y - dy >= 1.0 && p.y - dy <= 5.0) {
            p.y -= dy;
        } else if (p.y >= 1.0 && p.y <= 5.0) {
            return vec4(0.0);   // where the flag was before it dropped
        }
    }
#ifdef IS_GRAYSCALE
    return texelFetch(atlas, ivec2(o + (p + 0.5) * ts), 0).rrrr * tint;
#else
    return texelFetch(atlas, ivec2(o + (p + 0.5) * ts), 0) * tint;
#endif
}

// A pixel of the tutorial's floor arrow (CTX_TRAIL): chevrons on a grid of pixels CTX_TRAIL_ROWS to its width, each
// pointing along the text and gliding that way, to the line's end at the pad. Its length comes from its quad, as in
// ctx_frag, so it's the same however far the server stretches it. Places are counted back from that end, which stays
// put while the player walks at the pad and the server moves the other, so the chevrons don't come along with them.
// The generator's TutorialArt.trail draws the same (tutorial.png): change them together.
vec4 ctx_trail_px(vec4 tint, vec4 info, vec4 local, vec3 pos) {
    vec2 size = ctx_quad_size(local.xy, pos);
    float len = size.x * CTX_TRAIL_ROWS / max(size.y, 1e-6);   // the line's length in pixels
    float back = (1.0 - local.x) * len;                         // pixels back from its end at the pad
    float run = info.w * CTX_TRAIL_SPEED;                       // how far every chevron has come
    float n = floor((back + run) / CTX_TRAIL_PITCH);            // the chevron whose room this pixel is in
    float column = floor(back + run - n * CTX_TRAIL_PITCH);     // pixels back from its point
    float row = abs(floor(local.y * CTX_TRAIL_ROWS) - floor(CTX_TRAIL_ROWS / 2.0));   // rows from the middle one
    if (column < row || column >= row + CTX_TRAIL_THICK) return vec4(0.0);
    // the whole chevron fades: in as its tail comes off the line's start, out to nothing as its point reaches the end
    float tip = n * CTX_TRAIL_PITCH - run;
    float tail = len - tip - floor(CTX_TRAIL_ROWS / 2.0) - CTX_TRAIL_THICK;
    return vec4(tint.rgb, tint.a * smoothstep(0.0, CTX_TRAIL_FADE, tip) * smoothstep(0.0, CTX_TRAIL_FADE, tail));
}

// A pixel of a rainbow row of the global event's card (its strip: ctx_card), flowing with the name's own
// rainbow: x is the card's column and y the row from the name's top, as its letters have them (X and y), so the colours
// line up down the card. info.y and z are the shade's saturation and value.
vec4 ctx_card_rainbow_px(vec4 tint, vec4 texColor, vec4 info, vec3 pos) {
    float x = pos.x - CTX_CARD_X - 0.5;
    float y = pos.y - CTX_CARD_Y - float(CTX_CARD_NAME_Y) - 0.5;
    return vec4(ctx_hsv(ctx_rainbow_hue(x, y, info.w), info.y, info.z), texColor.a * tint.a);
}

// A text pixel: tint is the vertex colour times ColorModulator, texColor the glyph texel at uv in atlas, info and
// local what ctx_vertex and ctx_project returned, pos the vertex position passed on. Ordinary text comes back as
// vanilla draws it.
vec4 ctx_fragment(vec4 tint, vec4 texColor, vec4 info, vec2 uv, vec4 local, vec3 pos, sampler2D atlas) {
    vec4 color = texColor * tint;
    if (abs(info.x - CTX_CARD_RAINBOWING) < 0.5) return ctx_card_rainbow_px(tint, texColor, info, pos);
    if (info.x < CTX_TRAILING + 0.5) return ctx_trail_px(tint, info, local, pos);
    if (info.x < 0.0) return info.x < CTX_FLUTTERING + 0.5 ? ctx_flutter_px(tint, info, uv, local, atlas) : color;
    int fx = int(info.x + 0.5);
    CtxFrag f = ctx_frag(info, uv, local, pos, atlas);
    // A grown quad's texture sample is the glyph stretched over the whole quad, so it's no use there: a glow takes its
    // light and strength from the vertex alone (a wobbling letter's quad only moves, so it keeps its sample).
    if (f.kind == CTX_GLOW_QUAD) color = tint;
    return ctx_effect(fx, color, f, atlas);
}

#endif

#ifndef CHICKINS_LUCKY_GLSL
#define CHICKINS_LUCKY_GLSL

// Include chickins_flash.glsl first: every release includes this file, and they don't share a directive to do it here.

// Lucky Blocks from Exotic up, coloured for every pixel like their text effects, by each release's item shader.
// The generator's LuckyBlockArt writes them, and this does what its Flow and Shading do: keep the two the same.
//   - The item tints each face (253, 240 + face, 240 + effect): face is its direction (0 down, 1 up, 2 north, 3 south,
//     4 west, 5 east), effect the rarity less 8 (0 Exotic, 1 Divine, 2 Celestial, 3 Radiant, 4 Astral, 5 Eternal,
//     6 Eclipse, 7 Godly). Without this shader the tint is almost white.
//   - Its texture is the face's design, 16 x 16: each texel's blue channel says in its lowest two bits what it is
//     (0 the panel, 1 the border, 2 the "?"'s shadow, 3 the white "?" and rivets).
//   - The vertex stage passes on where on the face the pixel is (texels, 0 to 16, continuous): the game writes a
//     face's corners at its uv's (min, min), (min, max), (max, max), (max, min).
// The panel's colour comes from where the pixel is on the cube, continuously, so it carries on over every edge and
// is a smooth gradient however close you look; the border and the shadow are shades of the colour under them, and
// stay the design's pixels. Time is the game's clock in ticks (GameTime x 24000, passed on by the vertex stage, so the
// fragment stage needs no uniforms of its own); every loop divides 24000.
// Vertex stage: info = ctx_lucky_info(Color, GameTime) (flat), uv = ctx_lucky_at(info, CTX_VERTEX_ID), and light the
// vertex as if untinted. Fragment stage: the texture's colour is ctx_lucky_color(info, uv, texCoord0, Sampler0).
//
// The openings' glows and shines (the generator's OpeningArt) come through here too: every texel is the colour
// CTX_OPENING_MARK with its strength in its alpha, and the item's tint is the glow's colour. Item displays shade by the
// way a face looks, so a quad turned to the camera would go grey from most sides; these aren't lit at all. Anything
// but a Lucky Block passes its tint on in info.yzw (flat), and ctx_opening_glow says whether a texel is one of these.
// The mark is a colour nothing else may use: any item's texel within 1 of it is drawn unlit too (ResourcePackTest).
//
// A flashing button's plate comes through the Lucky Blocks' path too: its faces are tinted (253, 240, 240 + CTX_LUCKY_FLASH)
// (the generator's ButtonArt), and its texture just gets lit up by the beat (chickins_flash.glsl).
//
// A Rainbow chicken's frame in the chicken menu (the generator's MenuArt) comes through it as well: its face is tinted
// (253, 240 + picture, 240 + CTX_LUCKY_FRAME), and its bevel is the rainbow flowing along it (ctx_frame_pixel, below).
//
// A Rainbow egg (the generator's EggArt.rainbowModel) comes through it too: each face is tinted (251, 128 + box, 240 + face),
// and the rainbow runs across the whole egg from where a pixel is on it (ctx_lucky_at and ctx_egg_pixel, below).
//
// The Flock 200 page's blocks (CTX_LUCKY_PAINTED, below) are tinted (252, 240 + face, 200 + design) instead, and a
// see-through one's walls seen from inside (252, 246 + face, 200 + design), face being the wall's outside.

#define CTX_LUCKY_MARK 253
#define CTX_LUCKY_FLASH 8
#define CTX_LUCKY_FRAME 9
#define CTX_LUCKY_EGG 10
#define CTX_EGG_MARK 251
#define CTX_EGG_GREEN 128       // a Rainbow egg's tint green: this + the face's box
#define CTX_EGG_BOXES 18
#define CTX_OPENING_MARK ivec3(255, 248, 255)
#define CTX_LUCKY_PAINTED 252
#define CTX_PAINTED_BLUE 200    // a painted design's tint blue: this + its number (ctx_painted)
#define CTX_PAINTED 25          // how many there are
#define CTX_FX_PAINTED 16       // ctx_lucky_info's effect for design 0

// A vertex's number in its own draw (chickins_text.glsl has the same: change both together). From 26.2 the game packs a
// frame's draws into one vertex buffer (StagedVertexBuffer), each starting where the one before ended, rounded to its own
// vertex size, and the game's number counts from the buffer's start, so a quad's corner (& 3) came out wrong by whatever
// was drawn before it that frame, changing from frame to frame. The draw's first vertex comes off: CTX_BASE_VERTEX, which
// 26.2's and 26.3's vertex shaders define where the device has it. 1.21.11 and 26.1 don't share a buffer between draws.
#ifndef CTX_VERTEX_ID
#ifdef VULKAN
#define CTX_BUFFER_VERTEX gl_VertexIndex
#else
#define CTX_BUFFER_VERTEX gl_VertexID
#endif
#ifdef CTX_BASE_VERTEX
#define CTX_VERTEX_ID (CTX_BUFFER_VERTEX - CTX_BASE_VERTEX)
#else
#define CTX_VERTEX_ID CTX_BUFFER_VERTEX
#endif
#endif

// What a vertex passes on, flat: (face, effect, tick, 0) for a Lucky Block's, (-1, its tint) for anything else; a
// painted one's effect is CTX_FX_PAINTED + its design, and its last 1 on a wall seen from inside; a Rainbow egg's
// effect is CTX_LUCKY_EGG and its last the face's box
vec4 ctx_lucky_info(vec4 color, float gameTime) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if (c.r == CTX_LUCKY_MARK && c.g >= 240 && c.g <= 245 && c.b >= 240 && c.b <= 240 + CTX_LUCKY_FRAME) {
        return vec4(float(c.g - 240), float(c.b - 240), gameTime * 24000.0, 0.0);
    }
    if (c.r == CTX_LUCKY_PAINTED && c.g >= 240 && c.g <= 251 && c.b >= CTX_PAINTED_BLUE && c.b < CTX_PAINTED_BLUE + CTX_PAINTED) {
        return vec4(float(c.g >= 246 ? c.g - 246 : c.g - 240), float(CTX_FX_PAINTED + c.b - CTX_PAINTED_BLUE),
                    gameTime * 24000.0, c.g >= 246 ? 1.0 : 0.0);
    }
    if (c.r == CTX_EGG_MARK && c.g >= CTX_EGG_GREEN && c.g < CTX_EGG_GREEN + CTX_EGG_BOXES && c.b >= 240 && c.b <= 245) {
        return vec4(float(c.b - 240), float(CTX_LUCKY_EGG), gameTime * 24000.0, float(c.g - CTX_EGG_GREEN));
    }
    return vec4(-1.0, color.rgb);
}

// Whether a texel of a vertex with this info is an opening's glow: draw it as vec4(info.yzw, texel.a), unlit
bool ctx_opening_glow(vec4 info, vec4 texel) {
    return info.x < 0.0 && all(lessThanEqual(abs(ivec3(round(texel.rgb * 255.0)) - CTX_OPENING_MARK), ivec3(1)));
}

// Where a face's corner is on it, in texels
vec2 ctx_lucky_corner(int vertexId) {
    int corner = vertexId & 3;
    return vec2(corner >= 2 ? 16.0 : 0.0, (corner == 1 || corner == 2) ? 16.0 : 0.0);
}

vec3 ctx_lucky_hex(int c) {
    return vec3(float((c >> 16) & 255), float((c >> 8) & 255), float(c & 255)) / 255.0;
}

// The model point of face position uv (as LuckyBlockArt.point)
vec3 ctx_lucky_point(int face, vec2 uv) {
    if (face == 0) return vec3(uv.x, 0.0, 16.0 - uv.y);
    if (face == 1) return vec3(uv.x, 16.0, uv.y);
    if (face == 2) return vec3(16.0 - uv.x, 16.0 - uv.y, 0.0);
    if (face == 3) return vec3(uv.x, 16.0 - uv.y, 16.0);
    if (face == 4) return vec3(0.0, 16.0 - uv.y, uv.x);
    return vec3(16.0, 16.0 - uv.y, 16.0 - uv.x);
}

// Along the straight line across the cube, and down from the top (LuckyBlockArt.across)
vec2 ctx_lucky_across(int face, vec2 uv) {
    vec3 p = ctx_lucky_point(face, uv);
    return vec2((32.0 - p.x - p.z) / sqrt(2.0), 16.0 - p.y);
}

// Round the cube, and down from the top (LuckyBlockArt.around and ring)
vec2 ctx_lucky_around(int face, vec2 uv) {
    if (face == 3) return uv;
    if (face == 5) return vec2(16.0 + uv.x, uv.y);
    if (face == 2) return vec2(32.0 + uv.x, uv.y);
    if (face == 4) return vec2(48.0 + uv.x, uv.y);
    bool top = face == 1;
    vec2 d = vec2(uv.x, top ? uv.y : 16.0 - uv.y) - 8.0;
    float r = max(1e-6, max(abs(d.x), abs(d.y)));
    vec2 k = d / r;
    float s;
    if (k.y >= abs(k.x)) {
        s = 8.0 + 8.0 * k.x;
    } else if (k.x >= abs(k.y)) {
        s = 24.0 - 8.0 * k.y;
    } else if (-k.y >= abs(k.x)) {
        s = 40.0 - 8.0 * k.x;
    } else {
        s = 56.0 + 8.0 * k.y;
    }
    return vec2(s, top ? r - 8.0 : 24.0 - r);
}

// --- A Rainbow egg: one rainbow across the whole egg, as Godly's is across its cube (the generator's EggArt.rainbow draws
// the same for the preview: keep the two the same). The egg is 18 boxes, so a face's tint says which box it's on, and the
// vertex stage works out where on the egg each corner is and passes on how far along the rainbow that is. That's a
// straight line through the egg, so it comes out right at every pixel between and carries on over every edge. A client
// without the shader sees the egg in the tints' pink. ---

// The egg's layers from the bottom (EggArt.LAYERS): y from, y to, half-width, and the chamfer (its half-width x 0.6,
// rounded). A layer is three boxes: its middle, as wide as the layer, then the slab in front of it and the one behind.
const vec4 CTX_EGG_LAYERS[6] = vec4[6](
    vec4(3.0, 4.0, 3.0, 2.0), vec4(4.0, 6.0, 4.0, 2.0), vec4(6.0, 10.0, 5.0, 3.0),
    vec4(10.0, 12.0, 4.0, 2.0), vec4(12.0, 14.0, 3.0, 2.0), vec4(14.0, 15.0, 2.0, 1.0));
#define CTX_EGG_ROUND 14.0      // model units along the line across the egg from a hue to the same one again: about the egg's width that way
#define CTX_EGG_SLANT 0.014     // rounds for each unit down from the top (Godly's slant, at the egg's size)
#define CTX_EGG_TICKS 80.0      // ticks a round, Godly's: 24000 is 300 of them
#define CTX_EGG_SATURATION 0.55 // soft enough that the tier's pattern shows through

// Where a corner of a Rainbow egg's face is on the egg, in model units
vec3 ctx_egg_point(int box, int face, vec2 corner) {
    vec4 layer = CTX_EGG_LAYERS[box / 3];
    int part = box - 3 * (box / 3);
    float r = layer.z;
    float c = layer.w;
    vec3 from = part == 0 ? vec3(8.0 - r, layer.x, 8.0 - c) : part == 1 ? vec3(8.0 - c, layer.x, 8.0 - r) : vec3(8.0 - c, layer.x, 8.0 + c);
    vec3 to = part == 0 ? vec3(8.0 + r, layer.y, 8.0 + c) : part == 1 ? vec3(8.0 + c, layer.y, 8.0 - c) : vec3(8.0 + c, layer.y, 8.0 + r);
    return mix(from, to, ctx_lucky_point(face, corner) / 16.0);
}

// How far along the rainbow a point of the egg is, in rounds: along the cube's line (ctx_lucky_across), a little slant down
float ctx_egg_along(vec3 p) {
    return (32.0 - p.x - p.z) / sqrt(2.0) / CTX_EGG_ROUND + (16.0 - p.y) * CTX_EGG_SLANT;
}

// What the vertex stage passes on as uv: where on the face the corner is, in texels, or for a Rainbow egg how far along
// the rainbow it is
vec2 ctx_lucky_at(vec4 info, int vertexId) {
    vec2 corner = ctx_lucky_corner(vertexId);
    if (info.x < 0.0 || int(info.y + 0.5) != CTX_LUCKY_EGG) return corner;
    return vec2(ctx_egg_along(ctx_egg_point(int(info.w + 0.5), int(info.x + 0.5), corner)), 0.0);
}

vec3 ctx_lucky_cycle3(float p, int a, int b, int c) {
    float q = fract(p) * 3.0;
    return q < 1.0 ? mix(ctx_lucky_hex(a), ctx_lucky_hex(b), q)
         : q < 2.0 ? mix(ctx_lucky_hex(b), ctx_lucky_hex(c), q - 1.0)
         : mix(ctx_lucky_hex(c), ctx_lucky_hex(a), q - 2.0);
}

vec3 ctx_lucky_hsv(float h, float s, float v) {
    vec3 k = clamp(abs(fract(h + vec3(0.0, 2.0, 1.0) / 3.0) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

vec3 ctx_lucky_to_hsv(vec3 c) {
    float top = max(c.r, max(c.g, c.b));
    float d = top - min(c.r, min(c.g, c.b));
    float h = 0.0;
    if (d > 0.0) {
        if (top == c.r) h = mod((c.g - c.b) / d, 6.0);
        else if (top == c.g) h = (c.b - c.r) / d + 2.0;
        else h = (c.r - c.g) / d + 4.0;
    }
    return vec3(fract(h / 6.0), top == 0.0 ? 0.0 : d / top, top);
}

float ctx_lucky_luminance(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

// LuckyBlockArt.hash: 0 to 1 from a lattice point, in 32-bit integers
float ctx_lucky_hash(int u, int v, int period) {
    uint h = uint(((u % period) + period) % period) * 374761393u + uint(v) * 668265263u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    return float((h ^ (h >> 16u)) & 0xFFFFFFu) / 16777216.0;
}

float ctx_lucky_hash3(int x, int y, int z, int period) {
    int mx = ((x % period) + period) % period;
    int my = ((y % period) + period) % period;
    int mz = ((z % period) + period) % period;
    return ctx_lucky_hash(mx + period * mz, my, period * period);
}

vec2 ctx_lucky_smooth(vec2 f) {
    return f * f * (3.0 - 2.0 * f);
}

// LuckyBlockArt.noise: value noise repeating every period cells along u
float ctx_lucky_noise(vec2 p, int period) {
    ivec2 i = ivec2(floor(p));
    vec2 f = ctx_lucky_smooth(p - vec2(i));
    float top = mix(ctx_lucky_hash(i.x, i.y, period), ctx_lucky_hash(i.x + 1, i.y, period), f.x);
    float bottom = mix(ctx_lucky_hash(i.x, i.y + 1, period), ctx_lucky_hash(i.x + 1, i.y + 1, period), f.x);
    return mix(top, bottom, f.y);
}

// LuckyBlockArt.noise3: value noise in 3D repeating every period cells along each axis
float ctx_lucky_noise3(vec3 p, int period) {
    ivec3 i = ivec3(floor(p));
    vec3 f = p - vec3(i);
    f = f * f * (3.0 - 2.0 * f);
    float layer[2];
    for (int k = 0; k < 2; k++) {
        float near = mix(ctx_lucky_hash3(i.x, i.y, i.z + k, period), ctx_lucky_hash3(i.x + 1, i.y, i.z + k, period), f.x);
        float far = mix(ctx_lucky_hash3(i.x, i.y + 1, i.z + k, period), ctx_lucky_hash3(i.x + 1, i.y + 1, i.z + k, period), f.x);
        layer[k] = mix(near, far, f.y);
    }
    return mix(layer[0], layer[1], f.z);
}

// The panel's colour at face position uv and tick t (LuckyBlockArt.ALL's flows)
vec3 ctx_lucky_panel(int fx, int face, vec2 uv, float t) {
    if (fx == 0) {   // Exotic: candy stripes round the cube
        vec2 a = ctx_lucky_around(face, uv) * 0.75;
        return mod(floor((a.x + a.y - t * 0.3) / 3.0), 2.0) < 0.5 ? ctx_lucky_hex(0xff5cdd) : ctx_lucky_hex(0xff8de7);
    }
    if (fx == 4) {   // Astral: clouds drifting through the cube
        vec3 p = ctx_lucky_point(face, uv) * (3.0 / 16.0);
        float drift = t * 4.0 / 200.0;
        float n = ctx_lucky_noise3(p + vec3(drift, 0.0, drift), 4);
        vec3 c = mix(ctx_lucky_hex(0x5b45d6), ctx_lucky_hex(0x8a6cff), smoothstep(0.15, 0.4, n));
        c = mix(c, ctx_lucky_hex(0xc77dff), smoothstep(0.4, 0.62, n));
        return mix(c, ctx_lucky_hex(0xff8ad8), smoothstep(0.62, 0.85, n));
    }
    vec2 a = ctx_lucky_across(face, uv);
    float s = a.x;
    float h = a.y;
    if (fx == 1) return ctx_lucky_cycle3(s / 16.0 - 2.0 * t / 48.0 + h * 0.015, 0x52cfe3, 0x71fff1, 0x3790c4);   // Divine
    if (fx == 2) return ctx_lucky_cycle3(s / 16.0 - t / 40.0 + h * 0.015, 0xaab6dc, 0xc0ceec, 0x98a0cf);         // Celestial
    if (fx == 3) return ctx_lucky_cycle3(s / 16.0 - 2.0 * t / 48.0 + h * 0.015, 0xf2c43c, 0xffe854, 0xd39224);   // Radiant
    if (fx == 5) {   // Eternal: curtains of light, a violet edge now and then towards the bottom
        float w = 0.5 + 0.5 * sin(2.0 * 3.14159265 * (s / 16.0 - t * 3.0 / 96.0) + h * 0.5 * 0.45);
        vec3 c = mix(ctx_lucky_hex(0x0fa59d), ctx_lucky_hex(0x39e38a), w);
        float edge = smoothstep(0.55, 0.9, ctx_lucky_noise(vec2(s * 5.0 / 32.0 - t * 5.0 / 96.0, 0.0), 5));
        return mix(c, ctx_lucky_hex(0x8f7dff), 0.75 * edge * clamp(h * 0.5 / 7.0, 0.0, 1.0));
    }
    if (fx == 6) return ctx_lucky_cycle3(s / 16.0 - 2.0 * t / 48.0 + h * 0.015, 0x52307a, 0x9a62d8, 0x3a2259);   // Eclipse
    return ctx_lucky_hsv(s * 2.0 * 0.022 + h * 0.5 * 0.8 * 0.022 - t / 80.0, 0.72, 1.0);                        // Godly
}

float ctx_lucky_from_blue(float h) {
    return abs(fract(h - 240.0 / 360.0 + 0.5) - 0.5) * 360.0;
}

// LuckyBlockArt.Shade.of: turn the hue towards blue by turn + perDegree x its distance from blue (degrees), the
// saturation x saturate, and find the value that makes the luminance x luminance
vec3 ctx_lucky_shade(vec3 panel, vec4 shade, bool rainbow) {
    vec3 hsv = ctx_lucky_to_hsv(panel);
    float degrees = rainbow ? 0.0 : shade.x + shade.y * ctx_lucky_from_blue(hsv.x);
    float d = fract(240.0 / 360.0 - hsv.x + 0.5) - 0.5;
    float hue = hsv.x + sign(d) * min(abs(d), degrees / 360.0);
    float saturation = min(1.0, hsv.y * shade.z);
    float target = ctx_lucky_luminance(panel) * shade.w;
    float low = 0.0;
    float high = 1.0;
    for (int i = 0; i < 16; i++) {
        float value = (low + high) * 0.5;
        if (ctx_lucky_luminance(ctx_lucky_hsv(hue, saturation, value)) < target) low = value;
        else high = value;
    }
    return ctx_lucky_hsv(hue, saturation, (low + high) * 0.5);
}

// LuckyBlockArt.Shade.from: the shade that turns the user's example panel into its border or its shadow
vec4 ctx_lucky_shade_from(int panel, int shade) {
    vec3 p = ctx_lucky_to_hsv(ctx_lucky_hex(panel));
    vec3 q = ctx_lucky_to_hsv(ctx_lucky_hex(shade));
    float turned = abs(fract(p.x - q.x + 0.5) - 0.5) * 360.0;
    return vec4(0.0, turned / ctx_lucky_from_blue(p.x), q.y / p.y,
                ctx_lucky_luminance(ctx_lucky_hex(shade)) / ctx_lucky_luminance(ctx_lucky_hex(panel)));
}

// A border (shadow false) or a shadow of panel colour c, shaded as LuckyBlockArt.ALL's Shading: VIVID for Exotic,
// Eternal and Godly (Godly's keeps its hue), SOFT for the rest
vec3 ctx_lucky_shaded(int fx, vec3 c, bool shadow) {
    bool vivid = fx == 0 || fx == 5 || fx == 7;
    vec4 shade = vivid
        ? (shadow ? vec4(27.0, 0.0, 1.65, 0.587) : vec4(17.0, 0.0, 1.65, 0.706))
        : (shadow ? ctx_lucky_shade_from(0xfad739, 0xe0690b) : ctx_lucky_shade_from(0xfad739, 0xf09424));
    return ctx_lucky_shade(c, shade, fx == 7);
}

// A flashing plate's colour at a flash's height (the generator's ButtonArt.lit, for its preview: keep the two the same):
// paler, the hue turned towards yellow as highlights are, so its bevel still shows
vec3 ctx_flash_lit(vec3 c) {
    vec3 hsv = ctx_lucky_to_hsv(c);
    float d = fract(60.0 / 360.0 - hsv.x + 0.5) - 0.5;
    return ctx_lucky_hsv(hsv.x + sign(d) * min(abs(d), 9.0 / 360.0), max(hsv.y - 0.42, 0.0), min(hsv.z + 0.045, 1.0));
}

// --- The Flock 200 page's blocks, painted as the page paints them (resourcepack/flock/art.js: its function of the same
// name for each design below, and its helpers). The page and this must stay the same: the harness the user's sessions
// keep (tools: a WebGL page that draws every face with both) checked them within a few levels of 255 at every tick.
// Every loop divides 24000 ticks. ---

#define CTX_PT_PI 3.14159265
#define CTX_PT_TAU 6.2831853

// art.js smoothstep: from and to either way round (GLSL's is undefined when from > to)
float ctx_ss(float from, float to, float v) {
    float x = clamp((v - from) / (to - from), 0.0, 1.0);
    return x * x * (3.0 - 2.0 * x);
}

float ctx_smooth(float f) {
    return f * f * (3.0 - 2.0 * f);
}

// art.js mix: a colour between two, kept in range
vec3 ctx_mx(vec3 a, vec3 b, float t) {
    return clamp(mix(a, b, t), 0.0, 1.0);
}

vec3 ctx_mx(vec3 a, int b, float t) {
    return ctx_mx(a, ctx_lucky_hex(b), t);
}

vec3 ctx_mx(int a, int b, float t) {
    return ctx_mx(ctx_lucky_hex(a), ctx_lucky_hex(b), t);
}

// 1 inside r × core, 0 outside r, smooth between
float ctx_soft(float d, float r, float core) {
    return 1.0 - ctx_ss(r * core, r, d);
}

// a mod p, never negative (% is undefined for a negative a)
int ctx_imod(int a, int p) {
    return a - p * int(floor(float(a) / float(p)));
}

// art.js rnd: 0 to 1 from up to four integers
float ctx_rnd(int a, int b, int c, int d) {
    uint h = uint(a) * 374761393u + uint(b) * 668265263u + uint(c) * 1440662683u + uint(d) * 1274126177u;
    h = (h ^ (h >> 15u)) * 2246822519u;
    h = (h ^ (h >> 13u)) * 3266489917u;
    return float((h ^ (h >> 16u)) & 0xFFFFFFu) / 16777216.0;
}

// art.js hash and noise3 (the same as ctx_lucky_noise3, without % of a negative)
float ctx_pt_hash(int u, int v, int period) {
    uint h = uint(ctx_imod(u, period)) * 374761393u + uint(v) * 668265263u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    return float((h ^ (h >> 16u)) & 0xFFFFFFu) / 16777216.0;
}

float ctx_pt_hash3(int x, int y, int z, int period) {
    return ctx_pt_hash(ctx_imod(x, period) + period * ctx_imod(z, period), ctx_imod(y, period), period * period);
}

float ctx_noise3(vec3 p, int period) {
    ivec3 i = ivec3(floor(p));
    vec3 f = p - vec3(i);
    f = f * f * (3.0 - 2.0 * f);
    float near0 = mix(ctx_pt_hash3(i.x, i.y, i.z, period), ctx_pt_hash3(i.x + 1, i.y, i.z, period), f.x);
    float far0 = mix(ctx_pt_hash3(i.x, i.y + 1, i.z, period), ctx_pt_hash3(i.x + 1, i.y + 1, i.z, period), f.x);
    float near1 = mix(ctx_pt_hash3(i.x, i.y, i.z + 1, period), ctx_pt_hash3(i.x + 1, i.y, i.z + 1, period), f.x);
    float far1 = mix(ctx_pt_hash3(i.x, i.y + 1, i.z + 1, period), ctx_pt_hash3(i.x + 1, i.y + 1, i.z + 1, period), f.x);
    return mix(mix(near0, far0, f.y), mix(near1, far1, f.y), f.z);
}

// art.js noise2: value noise wrapping at pu across and pv down
float ctx_noise2(float u, float v, int pu, int pv) {
    int iu = int(floor(u));
    int iv = int(floor(v));
    float fu = ctx_smooth(u - float(iu));
    float fv = ctx_smooth(v - float(iv));
    float a = ctx_rnd(ctx_imod(iu, pu), ctx_imod(iv, pv), 7, 0);
    float b = ctx_rnd(ctx_imod(iu + 1, pu), ctx_imod(iv, pv), 7, 0);
    float c = ctx_rnd(ctx_imod(iu, pu), ctx_imod(iv + 1, pv), 7, 0);
    float d = ctx_rnd(ctx_imod(iu + 1, pu), ctx_imod(iv + 1, pv), 7, 0);
    return mix(mix(a, b, fu), mix(c, d, fu), fv);
}

// art.js cells3: (how much nearer the nearest point is than the next, the nearest's cell)
vec2 ctx_cells3(vec3 p) {
    ivec3 i = ivec3(floor(p));
    float d1 = 9.0;
    float d2 = 9.0;
    float id = 0.0;
    for (int a = -1; a <= 1; a++) {
        for (int b = -1; b <= 1; b++) {
            for (int c = -1; c <= 1; c++) {
                ivec3 k = i + ivec3(a, b, c);
                vec3 q = vec3(k) + vec3(ctx_rnd(k.x, k.y, k.z, 1), ctx_rnd(k.x, k.y, k.z, 2), ctx_rnd(k.x, k.y, k.z, 3)) - p;
                float d = length(q);
                if (d < d1) {
                    d2 = d1;
                    d1 = d;
                    id = ctx_rnd(k.x, k.y, k.z, 4);
                } else if (d < d2) {
                    d2 = d;
                }
            }
        }
    }
    return vec2(d2 - d1, id);
}

// The "?" (LuckyBlockArt's MARK, art.js Q_MARK) at x 4, y 3: a row's bit x - 4
const int CTX_MARK_ROWS[10] = int[10](0x3E, 0x63, 0x63, 0x63, 0x70, 0x18, 0x18, 0x00, 0x18, 0x18);

bool ctx_mark(int x, int y) {
    return x >= 4 && x <= 10 && y >= 3 && y <= 12 && ((CTX_MARK_ROWS[y - 3] >> (x - 4)) & 1) != 0;
}

bool ctx_rivet(int x, int y) {
    return (x == 1 || x == 14) && (y == 1 || y == 14);
}

// art.js markAt: a texel of the "?" (not a rivet) under a point of the face
bool ctx_mark_at(float u, float v) {
    return ctx_mark(int(floor(u)), int(floor(v)));
}

// art.js markDistance: how far a point of the face is from the "?" (0 on it)
float ctx_mark_distance(float u, float v) {
    float best = 9.0;
    int fu = int(floor(u));
    int fv = int(floor(v));
    for (int y = max(0, fv - 3); y <= min(15, fv + 3); y++) {
        for (int x = max(0, fu - 3); x <= min(15, fu + 3); x++) {
            if (!ctx_mark(x, y)) continue;
            best = min(best, length(vec2(max(max(float(x) - u, 0.0), u - float(x) - 1.0),
                                         max(max(float(y) - v, 0.0), v - float(y) - 1.0))));
        }
    }
    return best;
}

// art.js std: white rivets and "?", the panel's border and shadow (VIVID or SOFT, a rainbow one keeping its hue)
vec3 ctx_std(vec3 panel, int kind, bool vivid, bool rainbow) {
    if (kind == 3) return vec3(1.0);
    if (kind == 0) return panel;
    bool shadow = kind == 2;
    vec4 shade = vivid
        ? (shadow ? vec4(27.0, 0.0, 1.65, 0.587) : vec4(17.0, 0.0, 1.65, 0.706))
        : (shadow ? ctx_lucky_shade_from(0xfad739, 0xe0690b) : ctx_lucky_shade_from(0xfad739, 0xf09424));
    return ctx_lucky_shade(panel, shade, rainbow);
}

vec3 ctx_std(vec3 panel, int kind) {
    return ctx_std(panel, kind, false, false);
}

// art.js acrossAt: along the cube from its south east edge to its north west one, with k of the height
float ctx_across_at(vec3 p, float k) {
    return (32.0 - p.x - p.z) / sqrt(2.0) + (16.0 - p.y) * k;
}

// art.js ring: round the sides (0 to 64) and the height (0 at the bottom, 16 at the top's edge, 24 at its middle)
vec2 ctx_ring(int face, vec2 uv) {
    vec2 a = ctx_lucky_around(face, uv);
    return vec2(a.x, 16.0 - a.y);
}

// Where on its face a point of the cube is: ctx_lucky_point turned round
vec2 ctx_lucky_uv(int face, vec3 p) {
    if (face == 0) return vec2(p.x, 16.0 - p.z);
    if (face == 1) return vec2(p.x, p.z);
    if (face == 2) return vec2(16.0 - p.x, 16.0 - p.y);
    if (face == 3) return vec2(p.x, 16.0 - p.y);
    if (face == 4) return vec2(p.z, 16.0 - p.y);
    return vec2(16.0 - p.z, 16.0 - p.y);
}

// art.js boltX: a bolt's x at height v, a jagged line down a face, a kink every 2.4 texels
float ctx_bolt_x(int seed, float v) {
    float seg = clamp(v / 2.4, 0.0, 7.999);
    int i = int(floor(seg));
    float x = 4.0 + ctx_rnd(seed, 301, 0, 0) * 8.0;
    float a = x;
    float b = x;
    for (int j = 1; j <= 8; j++) {
        float next = max(2.0, min(14.0, x + (ctx_rnd(seed, j, 302, 0) - 0.5) * 4.5));
        if (j - 1 == i) {
            a = x;
            b = next;
        }
        x = next;
    }
    return a + (b - a) * (seg - float(i));
}

const int CTX_FIRE[6] = int[6](0x3a0e0a, 0x8a1a0a, 0xe83a1a, 0xff8a1a, 0xffd84a, 0xfff4b0);

// Painted design number d's pixel at face position uv, tick t, of texel kind (0 panel, 1 border, 2 the "?"'s shadow,
// 3 white): (colour, how solid). Numbered in lucky-blocks.yml's order when they came (LuckyBlockArt.PAINTED).
vec4 ctx_painted(int d, int face, vec2 uv, float t, int kind) {
    float u = uv.x;
    float v = uv.y;
    vec3 p = ctx_lucky_point(face, uv);
    bool side = face >= 2;
    bool panel = kind == 0 || kind == 2;
    vec3 white = vec3(1.0);
    if (d == 0) {   // brilliant
        float a = ctx_across_at(p, 0.5);
        vec3 c = ctx_mx(0x5ac4e8, 0xa8e8f8, clamp(p.y / 16.0 * 0.7 + 0.15 + 0.15 * sin(a / 2.5), 0.0, 1.0));
        float k = mod(a - t * 1.2, 48.0) - 24.0;
        c = ctx_mx(c, white, clamp(exp(-k * k / 10.0) + 0.5 * exp(-(k + 5.0) * (k + 5.0) / 3.0), 0.0, 1.0) * 0.9);
        if (panel) {
            for (int s = 0; s < 2; s++) {
                float ph = ctx_rnd(face, s, 11, 0) * 40.0;
                float g = mod(t + ph, 40.0) / 40.0;
                int cyc = int(floor((t + ph) / 40.0));
                if (g >= 0.5) continue;
                float dx = abs(u - 2.5 - ctx_rnd(cyc, face, s, 12) * 11.0);
                float dy = abs(v - 2.5 - ctx_rnd(cyc, face, s, 13) * 11.0);
                float star = max(exp(-dx * dx / 0.15 - dy / 1.6), exp(-dy * dy / 0.15 - dx / 1.6)) * sin(CTX_PT_PI * g * 2.0);
                c = ctx_mx(c, white, clamp(star, 0.0, 1.0));
            }
        }
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 1) {   // enchanted
        float a = ctx_across_at(p, 0.35);
        float b = (p.x - p.z) / sqrt(2.0) * 0.7 + p.y;
        vec3 c = ctx_mx(0x22186a, 0x3a2a9a, clamp(p.y / 16.0, 0.0, 1.0));
        float g1 = pow(0.5 + 0.5 * sin(CTX_PT_TAU * (a / 9.0 - t / 40.0) + 1.3 * sin(CTX_PT_TAU * a / 23.0)), 5.0);
        float g2 = pow(0.5 + 0.5 * sin(CTX_PT_TAU * (b / 13.0 + t / 60.0) + 1.1 * sin(CTX_PT_TAU * b / 29.0)), 7.0);
        float g = clamp(g1 * 0.85 + g2 * 0.65, 0.0, 1.0);
        c = ctx_mx(c, 0xb070f8, g);
        c = ctx_mx(c, 0xf0d8ff, g * g * g * 0.6);
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 2) {   // mercurial
        float w = ctx_noise3(vec3(p.x / 6.0, p.y / 6.0 - t / 300.0, p.z / 6.0), 8);
        float q = mod(p.y / 20.0 + 0.9 * (w - 0.5) + 0.25 * sin(CTX_PT_TAU * (ctx_across_at(p, 0.0) / 22.0 - t / 120.0)), 1.0);
        vec3 c = q < 0.45 ? ctx_mx(0x262a36, 0x7c8698, q / 0.45)
               : q < 0.5 ? ctx_mx(0x7c8698, 0xf4f8ff, ctx_ss(0.45, 0.5, q))
               : ctx_mx(0xd0d8e6, 0x4a5262, (q - 0.5) / 0.5);
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 3) {   // toxic
        vec3 c = side ? ctx_mx(0x24561c, 0x4ea82e, v / 16.0) : face == 1 ? ctx_lucky_hex(0x2a621e) : ctx_lucky_hex(0x4ea82e);
        if (panel && side) {
            for (int k = 0; k < 4; k++) {
                float ph = ctx_rnd(face, k, 1, 0) * 48.0;
                float size = 1.3 + ctx_rnd(face, k, 2, 0) * 0.8;
                float a = mod(t + ph, 48.0) / 48.0;
                float by = 19.0 - a * 24.0;
                float bx = 3.0 + float(k) * 3.3 + 0.8 * sin(CTX_PT_TAU * (a * 2.0 + ctx_rnd(face, k, 3, 0)));
                float dist = length(vec2(u - bx, v - by));
                if (dist > size + 0.4) continue;
                vec3 inside = ctx_mx(0x78c232, 0xf0ffc0, ctx_soft(length(vec2(u - bx + size * 0.4, v - by + size * 0.4)), size * 0.45, 0.2));
                c = ctx_mx(c, ctx_mx(inside, 0xc4f44a, ctx_ss(size - 0.8, size - 0.3, dist)), ctx_ss(size + 0.35, size - 0.05, dist));
            }
        } else if (panel && face == 1) {
            for (int k = 0; k < 3; k++) {
                float ph = ctx_rnd(face, k, 5, 0) * 48.0;
                float a = mod(t + ph, 48.0);
                int cyc = int(floor((t + ph) / 48.0));
                if (a > 16.0) continue;
                float dist = length(vec2(u - 3.5 - ctx_rnd(cyc, k, 6, 0) * 10.0, v - 3.5 - ctx_rnd(cyc, k, 7, 0) * 10.0));
                float ring = dist - a * 0.3;
                float g = a < 4.0 ? ctx_soft(dist, 1.8, 0.5) : exp(-ring * ring / 0.25);
                c = ctx_mx(c, 0xc4f44a, g * (1.0 - a / 16.0));
            }
        }
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 4) {   // silken
        float x = ctx_across_at(p, 0.25);
        float T = CTX_PT_TAU * t / 160.0;
        float fold = sin(x / 2.6 + 1.6 * sin(p.y / 4.5 + T) + 0.8 * sin((p.x - p.z) / 7.0 - T));
        vec3 c = ctx_mx(0x0c4a30, 0x1e9a62, 0.5 + 0.5 * fold);
        c = ctx_mx(c, 0xc8f8e0, pow(max(0.0, fold), 8.0) * 0.85);
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 5) {   // thunderous
        float cloud = ctx_noise3(vec3(p.x / 4.0 + t / 75.0, p.y / 4.0, p.z / 4.0 - t / 150.0), 8);
        vec3 c = ctx_mx(0x1a2234, 0x4a5672, ctx_ss(0.3, 0.75, cloud));
        float T = mod(t, 30.0);
        int cyc = int(floor(t / 30.0));
        float lit = T < 2.0 ? 1.0 : T < 3.0 ? 0.3 : T < 6.0 ? 1.0 : T < 12.0 ? (12.0 - T) / 6.0 * 0.8 : 0.0;
        c = ctx_mx(c, 0xb0bce8, 0.4 * lit);
        if (lit > 0.0 && panel) {
            float glow = 0.0;
            float core = 0.0;
            for (int k = 0; k < 3; k++) {
                int seed = (cyc * 8 + face) * 4 + k;
                bool flip = !side && ctx_rnd(seed, 305, 0, 0) > 0.5;
                float along = flip ? u : v;
                float across = flip ? v : u;
                float dist = abs(across - ctx_bolt_x(seed, along));
                glow = max(glow, exp(-dist / 2.2));
                core = max(core, ctx_ss(1.0, 0.35, dist));
                float a0 = 3.0 + ctx_rnd(seed, 306, 0, 0) * 6.0;
                if (along > a0 && along < a0 + 6.0) {
                    float db = abs(across - (ctx_bolt_x(seed, a0) + (ctx_bolt_x(seed + 4096, along - a0 + 2.4) - ctx_bolt_x(seed + 4096, 2.4)) * 1.4));
                    glow = max(glow, 0.7 * exp(-db / 1.4) * (1.0 - (along - a0) / 6.0));
                    core = max(core, 0.8 * ctx_ss(0.6, 0.2, db) * (1.0 - (along - a0) / 6.0));
                }
            }
            c = ctx_mx(c, 0x8aa4ff, clamp(glow * lit, 0.0, 1.0));
            c = ctx_mx(c, 0xf6f8ff, clamp(core * lit, 0.0, 1.0));
        }
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 6) {   // shimmering
        float r1 = 1.0 - abs(2.0 * ctx_noise3(vec3(p.x / 3.2 + t / 60.0, p.y / 3.2, p.z / 3.2), 8) - 1.0);
        float r2 = 1.0 - abs(2.0 * ctx_noise3(vec3(p.x / 2.6, p.y / 2.6 + t / 80.0, p.z / 2.6 - t / 80.0), 8) - 1.0);
        float light = pow(max(r1, r2) * 0.75 + min(r1, r2) * 0.3, 6.0);
        vec3 c = ctx_mx(0x0c3e5e, 0x2290ae, clamp(p.y / 16.0, 0.0, 1.0));
        c = ctx_mx(c, 0x5ad8e0, clamp(light * 1.4, 0.0, 1.0));
        return vec4(ctx_std(ctx_mx(c, 0xe0fff8, clamp((light - 0.55) * 2.2, 0.0, 1.0)), kind), 1.0);
    }
    if (d == 7) {   // wobbly: see-through
        float T = mod(t, 60.0);
        float jig = exp(-T / 14.0) * sin(T * 0.75) + 0.25 * sin(CTX_PT_TAU * t / 30.0);
        float lean = jig * (p.y / 16.0);
        vec3 c = ctx_mx(0xa01040, 0xf0406e, clamp(p.y / 18.0 + 0.15 * sin(ctx_across_at(p, 0.0) / 4.0 + jig), 0.0, 1.0));
        float hx = 4.5 + 2.2 * jig;
        float hy = 4.0 - 0.8 * jig;
        float spec = ctx_soft(length(vec2(u - hx, (v - hy) * 1.5)), 3.4, 0.15);
        c = ctx_mx(c, 0xffd6e2, spec * 0.8);
        float bubble = 0.0;
        if (kind == 0 && side) {
            for (int k = 0; k < 3; k++) {
                float a = mod(t / 240.0 + ctx_rnd(face, k, 701, 0), 1.0);
                float bx = 3.0 + ctx_rnd(face, k, 702, 0) * 10.0 + lean * 2.0;
                float by = 15.0 - a * 16.0;
                float r = 0.7 + 0.5 * ctx_rnd(face, k, 703, 0);
                float dist = length(vec2(u - bx, v - by));
                bubble = max(bubble, ctx_ss(r + 0.3, r - 0.1, dist) * (0.4 + 0.6 * ctx_ss(r - 0.5, r, dist)));
            }
        }
        c = ctx_mx(c, 0xffe8f0, bubble * 0.7);
        float alpha = kind == 0 ? min(1.0, 0.5 + 0.12 * (1.0 - p.y / 16.0) + 0.45 * spec + 0.4 * bubble) : kind == 2 ? 0.85 : 1.0;
        return vec4(ctx_std(c, kind), alpha);
    }
    if (d == 8) {   // phantom
        float ang = CTX_PT_TAU * t / 200.0;
        float x = p.x - 8.0;
        float z = p.z - 8.0;
        float rx = x * cos(ang) - z * sin(ang);
        float rz = x * sin(ang) + z * cos(ang);
        float n = ctx_noise3(vec3(rx / 4.0 + 16.0, p.y / 4.0 - t / 100.0, rz / 4.0 + 16.0), 8);
        float n2 = ctx_noise3(vec3(rx / 2.5 + 16.0 + n * 1.5, p.y / 2.5 - t / 50.0, rz / 2.5 + 16.0), 8);
        float mist = ctx_ss(0.45, 0.8, n2 * 0.6 + n * 0.5);
        float breathe = 0.5 + 0.5 * sin(CTX_PT_TAU * t / 80.0);
        vec3 c = ctx_mx(0x2a1a50, 0x4a2e86, clamp(p.y / 16.0 * 0.6 + n * 0.4, 0.0, 1.0));
        c = ctx_mx(c, 0x9a78e8, mist * (0.45 + 0.35 * breathe));
        return vec4(ctx_std(ctx_mx(c, 0x1a1030, 0.25 * (1.0 - breathe)), kind), 1.0);
    }
    if (d == 9) {   // luminous
        vec2 ring = ctx_ring(face, uv);
        float e = min(min(u, v), min(16.0 - u, 16.0 - v));
        float field = 1.4 * (0.85 + 0.15 * sin(CTX_PT_TAU * t / 80.0)) / (e * e + 0.35);
        for (int k = 0; k < 10; k++) {
            float period = k % 3 == 0 ? 96.0 : k % 3 == 1 ? 120.0 : 160.0;
            float a = mod(t + ctx_rnd(k, 91, 0, 0) * period, period) / period;
            float so = float(k) * 6.4 + ctx_rnd(k, 92, 0, 0) * 3.0 + 3.0 * sin(CTX_PT_TAU * (a + ctx_rnd(k, 93, 0, 0)));
            float ho = -5.0 + 32.0 * (0.5 - 0.5 * cos(CTX_PT_TAU * a));
            float r = 1.6 + 0.9 * ctx_rnd(k, 94, 0, 0);
            float dx = mod(ring.x - so + 32.0, 64.0) - 32.0;
            float dy = (ring.y - ho) * 0.8;
            field += r * r / (dx * dx + dy * dy + 0.3);
        }
        vec3 lamp = ctx_mx(0xc8466a, 0xf79a62, clamp(ring.y / 20.0, 0.0, 1.0));
        vec3 wax = ctx_mx(ctx_mx(0xffd0c0, 0xffe6a8, ctx_ss(1.15, 2.4, field)), 0xfff4d8, ctx_ss(2.4, 4.0, field));
        return vec4(ctx_std(ctx_mx(lamp, wax, ctx_ss(0.9, 1.15, field)), kind), 1.0);
    }
    if (d == 10) {   // undying: vivid
        float T = mod(t, 24.0);
        float beat = exp(-T / 2.2) + (T >= 6.0 ? 0.7 * exp(-(T - 6.0) / 2.2) : 0.0);
        float g = beat * clamp(1.0 - length(vec2(u - 8.0, v - 8.0)) / 11.0, 0.0, 1.0);
        vec3 c = ctx_mx(0x5e0a1c, 0xff3448, g);
        float vein = ctx_ss(0.83, 0.89, 1.0 - abs(2.0 * ctx_noise3(p / 5.0, 8) - 1.0));
        return vec4(ctx_std(ctx_mx(c, ctx_mx(0x340410, 0xff8090, min(1.0, beat * 1.2)), vein), kind, true, false), 1.0);
    }
    if (d == 11) {   // molten
        if (kind == 1) return vec4(ctx_lucky_hex(0x1a1012), 1.0);
        vec2 cell = ctx_cells3(vec3(p.x / 5.5 + 0.3, p.y / 5.5 + 0.7, p.z / 5.5 + 0.1));
        float w = 0.5 + 0.5 * sin(CTX_PT_TAU * t / 40.0 - p.y / 3.0);
        vec3 c = ctx_mx(cell.y < 0.5 ? 0x2a1c1a : 0x3a2622, 0x8a1e0e, (1.0 - ctx_ss(0.1, 0.3, cell.x)) * (0.3 + 0.55 * w));
        c = ctx_mx(c, ctx_mx(ctx_mx(0xc8300c, 0xf07018, w), 0xffc848, ctx_ss(0.08, 0.02, cell.x) * w), 1.0 - ctx_ss(0.07, 0.13, cell.x));
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 12) {   // frozen: see-through
        float e = min(min(u, v), min(16.0 - u, 16.0 - v));
        float reach = 3.0 + 1.2 * sin(CTX_PT_TAU * t / 160.0);
        float frost = 1.0 - ctx_ss(reach - 1.5, reach + 0.5, e + 2.2 * ctx_noise3(p / 2.5, 8));
        vec3 c = ctx_mx(0x7ac4f0, 0xf2faff, frost);
        float k = mod(ctx_across_at(p, 0.5) - t * 0.5, 40.0) - 20.0;
        float sheen = exp(-k * k / 6.0);
        c = ctx_mx(c, white, sheen * 0.6);
        float alpha = kind == 0 ? min(1.0, 0.4 + 0.5 * frost + 0.35 * sheen) : kind == 2 ? 0.85 : 1.0;
        return vec4(ctx_std(c, kind), alpha);
    }
    if (d == 13) {   // blazing: vivid
        if (kind == 1) return vec4(ctx_std(ctx_lucky_hex(0xe83a1a), 1, true, false), 1.0);
        float heat;
        if (side) {
            float offset = face == 3 ? 0.0 : face == 5 ? 16.0 : face == 2 ? 32.0 : 48.0;
            heat = ctx_noise2((offset + u) * 0.375, v * 0.35 + t * 0.15, 24, 12) * 0.8 + (v - 0.5) / 15.0 * 0.75 - 0.15;
        } else if (face == 1) {
            heat = 0.72 + 0.4 * ctx_noise2(u * 0.4, v * 0.4 + t * 0.15, 8, 12);
        } else {
            heat = 0.3;
        }
        float k = max(0.0, min(4.999, heat * 5.0 - 0.5));
        int i = int(floor(k));
        return vec4(ctx_std(ctx_mx(CTX_FIRE[i], CTX_FIRE[i + 1], ctx_smooth(k - float(i))), kind, true, false), 1.0);
    }
    if (d == 14) {   // solar
        float cx = u - 8.0;
        float cy = v - 8.0;
        float r = length(vec2(cx, cy));
        float ray = 0.5 + 0.5 * cos(8.0 * (atan(cy, cx) + CTX_PT_TAU * t / 320.0));
        vec3 c = ctx_mx(0xe8601e, 0xffb850, ctx_ss(0.42, 0.58, ray));
        c = ctx_mx(c, 0xffe890, clamp(1.0 - r / 5.5, 0.0, 1.0) * 0.9);
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 15) {   // lunar
        vec3 q = p - 8.0;
        float a = CTX_PT_TAU * t / 400.0;
        float k = ctx_ss(-0.12, 0.12, (q.x * cos(a) + q.y * 0.3 + q.z * sin(a)) / length(q));
        float crater = ctx_ss(0.6, 0.68, ctx_noise3(p / 3.2, 8));
        vec3 c = ctx_mx(ctx_mx(0x1c2458, 0x141a44, crater), ctx_mx(0xc4cce4, 0x98a0c0, crater), k);
        if (k < 0.5) {
            int cx = int(floor(u / 2.5));
            int cy = int(floor(v / 2.5));
            if (ctx_rnd(face, cx, cy, 31) > 0.7) {
                float d2 = length(vec2(u - (float(cx) + 0.3 + 0.4 * ctx_rnd(face, cx, cy, 32)) * 2.5,
                                       v - (float(cy) + 0.3 + 0.4 * ctx_rnd(face, cx, cy, 33)) * 2.5));
                c = ctx_mx(c, 0xe8ecff, 0.85 * (1.0 - 2.0 * k) * ctx_soft(d2, 0.6, 0.3));
            }
        }
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 16) {   // majestic
        if (kind == 1) return vec4(ctx_lucky_hex(0xc8962c), 1.0);
        vec2 ring = ctx_ring(face, uv);
        float vein = 1.0 - abs(2.0 * ctx_noise3(p / 6.0, 8) - 1.0);
        vec3 c = ctx_mx(0xf6f0e0, 0xd8c49a, ctx_ss(0.82, 0.95, vein) * 0.8);
        float shaft = pow(0.5 + 0.5 * sin(CTX_PT_TAU * ((ring.x + ring.y * 0.45) / 16.0 - t / 120.0)), 6.0);
        c = ctx_mx(c, 0xf0b83a, shaft * (0.35 + 0.5 * clamp(ring.y / 16.0, 0.0, 1.0)));
        c = ctx_mx(c, 0xfff0c0, shaft * shaft * shaft * 0.45);
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 17) {   // cascading
        vec2 ring = ctx_ring(face, uv);
        float s = ring.x;
        float H = ring.y;
        vec3 c;
        if (face == 0) {
            c = ctx_lucky_hex(0xdceefa);
        } else {
            bool top = H > 16.0;
            float fall = top ? ctx_noise2(s * 0.75, (24.0 - H) * 0.4 - t * 0.15, 48, 12) : ctx_noise2(s * 0.75, H * 0.16 + t * 0.15, 48, 12);
            float fine = top ? ctx_noise2(s * 1.5, (24.0 - H) * 0.8 - t * 0.3, 96, 24) : ctx_noise2(s * 1.5, H * 0.32 + t * 0.3, 96, 24);
            float w = fall * 0.7 + fine * 0.3;
            c = ctx_mx(0x1a5aaa, 0x6ac0f0, ctx_ss(0.25, 0.75, w));
            c = ctx_mx(c, 0xe8f6ff, ctx_ss(0.68, 0.85, w) * 0.85);
            if (!top) {
                float churn = ctx_noise2(s * 1.25, H * 0.8 + t * 0.2, 80, 16);
                c = ctx_mx(c, white, ctx_ss(3.8, 1.2, H + churn * 2.2));
            } else {
                c = ctx_mx(c, 0x9ad8fa, ctx_ss(20.0, 24.0, H) * 0.5);
            }
        }
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 18) {   // galactic
        float x = u - 8.0;
        float y = v - 8.0;
        float r = length(vec2(x, y)) + 1e-6;
        float th = atan(y, x);
        float arm = 0.5 + 0.5 * cos(2.0 * (th - CTX_PT_TAU * t / 240.0) - 2.6 * log(r + 0.6));
        float dust = ctx_noise2(th / CTX_PT_TAU * 12.0 + 12.0, r * 0.9 - t / 40.0, 12, 8);
        vec3 c = ctx_mx(0x0c0626, 0x221050, clamp(1.0 - r / 11.0, 0.0, 1.0));
        c = ctx_mx(c, ctx_mx(0xf070c8, 0x7a5af0, clamp(r / 8.0, 0.0, 1.0)), clamp(arm * arm * arm * exp(-r / 7.0) * (1.6 + dust), 0.0, 1.0));
        c = ctx_mx(c, 0xfff0f8, exp(-r * r / 3.0));
        int cx = int(floor(u / 3.0));
        int cy = int(floor(v / 3.0));
        if (ctx_rnd(face, cx, cy, 321) > 0.7) {
            float d2 = length(vec2(u - (float(cx) + 0.3 + 0.4 * ctx_rnd(face, cx, cy, 322)) * 3.0,
                                   v - (float(cy) + 0.3 + 0.4 * ctx_rnd(face, cx, cy, 323)) * 3.0));
            c = ctx_mx(c, 0xe8e0ff, ctx_soft(d2, 0.55, 0.3) * (0.5 + 0.5 * sin(CTX_PT_TAU * (t / 60.0 + ctx_rnd(cx, cy, 324, 0)))));
        }
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 19) {   // glitched
        float T = mod(t, 60.0);
        bool burst = T >= 42.0 && T < 52.0;
        int tick2 = int(floor(t / 2.0));
        int slice = int(floor(v / 1.6));
        float shift = burst ? (ctx_rnd(slice, tick2, face, 401) - 0.5) * 5.0 : 0.0;
        float split = burst ? 0.9 : 0.35 + 0.25 * sin(CTX_PT_TAU * t / 30.0);
        float su = u - shift;
        vec3 c = ctx_mx(0x0a1018, 0x14303e, 0.5 + 0.5 * sin(CTX_PT_TAU * (v / 5.0 - t / 40.0)));
        c = ctx_mx(c, 0x1e6a80, 0.35 * ctx_soft(length(vec2(su - 8.0, v - 8.0)), 9.0, 0.0));
        if (burst && ctx_rnd(slice, tick2, face, 402) > 0.8) c = ctx_mx(c, 0x3ae8ff, 0.35);
        if (kind == 1) return vec4(ctx_std(ctx_lucky_hex(0x1a3a48), 1), 1.0);
        if (ctx_rivet(int(floor(u)), int(floor(v)))) return vec4(white, 1.0);
        if (ctx_mark_at(su, v)) return vec4(white, 1.0);
        if (ctx_mark_at(su - split, v)) return vec4(ctx_lucky_hex(0xff4a6a), 1.0);
        if (ctx_mark_at(su + split, v)) return vec4(ctx_lucky_hex(0x3ae8ff), 1.0);
        return vec4(c, 1.0);
    }
    if (d == 20) {   // shadow
        if (kind == 1) return vec4(ctx_lucky_hex(0x0a0a0e), 1.0);
        if (kind == 3) return vec4(white, 1.0);
        float w = ctx_noise3(vec3(p.x * 0.15, p.y * 0.15 - t * 0.02, p.z * 0.15), 8);
        float n = ctx_noise3(vec3(p.x * 0.24 + w * 2.0, p.y * 0.24 - t * 0.04, p.z * 0.24 + w * 2.0), 8);
        vec3 c = ctx_mx(0x16161c, 0x24242c, ctx_ss(0.38, 0.5, n));
        c = ctx_mx(c, 0x383844, ctx_ss(0.52, 0.64, n));
        c = ctx_mx(c, 0x56566a, ctx_ss(0.64, 0.76, n));
        float glow = 0.25 + 0.45 * (0.5 + 0.5 * sin(CTX_PT_TAU * t / 60.0));
        return vec4(ctx_mx(c, 0xb8b8d0, glow * exp(-ctx_mark_distance(u, v) / 1.1)), 1.0);
    }
    if (d == 21) {   // inky
        float w1 = ctx_noise3(vec3(p.x / 7.0, p.y / 7.0 + t / 300.0, p.z / 7.0), 8);
        float w2 = ctx_noise3(vec3(p.x / 3.2 + w1 * 3.0, p.y / 3.2 + t / 150.0, p.z / 3.2 - w1 * 3.0), 8);
        float n = ctx_noise3(vec3(p.x / 2.2 + w2 * 2.6, p.y / 2.2 + t / 100.0 + w1 * 2.0, p.z / 2.2 + w2 * 2.6), 8);
        float wisp = 1.0 - abs(2.0 * n - 1.0);
        float cloud = ctx_ss(0.5, 0.72, w2);
        vec3 c = ctx_mx(0xc8d0e6, 0x8a94c0, cloud * 0.7);
        c = ctx_mx(c, 0x3a4280, ctx_ss(0.78, 0.92, wisp) * (0.4 + 0.6 * cloud));
        c = ctx_mx(c, 0x141838, ctx_ss(0.9, 0.98, wisp) * cloud);
        return vec4(ctx_std(c, kind), 1.0);
    }
    if (d == 22) {   // electric
        float x = u - 8.0;
        float y = v - 8.0;
        float r = length(vec2(x, y)) + 1e-6;
        float th = atan(y, x);
        vec3 c = ctx_mx(0x0a0618, 0x1e0e3a, clamp(1.0 - r / 11.0, 0.0, 1.0));
        float glow = 0.0;
        float core = 0.0;
        for (int k = 0; k < 6; k++) {
            float base = CTX_PT_TAU * (float(k) / 6.0 + 0.06 * sin(CTX_PT_TAU * (t / 120.0 + ctx_rnd(face, k, 601, 0))) + t / 480.0);
            float wig = 0.35 * sin(r * 0.9 - CTX_PT_TAU * t / 20.0 + float(k) * 1.7) * (r / 8.0);
            float da = abs(mod(th - base - wig + CTX_PT_PI, CTX_PT_TAU) - CTX_PT_PI) * r;
            float flick = 0.75 + 0.25 * sin(CTX_PT_TAU * (t / 8.0 + ctx_rnd(face, k, 602, 0)));
            glow = max(glow, exp(-da / 1.3) * flick * ctx_ss(0.5, 2.0, r));
            core = max(core, ctx_ss(0.55, 0.15, da) * flick * ctx_ss(1.0, 2.5, r));
            float tipAngle = base + 0.35 * sin(8.5 * 0.9 - CTX_PT_TAU * t / 20.0 + float(k) * 1.7);
            float tip = length(vec2(x - 8.5 * cos(tipAngle), y - 8.5 * sin(tipAngle)));
            glow = max(glow, exp(-tip / 1.2) * flick);
        }
        c = ctx_mx(c, 0xd040c0, clamp(glow, 0.0, 1.0));
        c = ctx_mx(c, 0xffd8f8, clamp(core, 0.0, 1.0));
        return vec4(ctx_std(ctx_mx(c, 0xffe8fa, exp(-r * r / 5.0)), kind), 1.0);
    }
    if (d == 23) {   // transcendent: a soft rainbow across (art.js rainbow(120, 0.4, 1)), keeping its hue in the shading
        vec2 a = ctx_lucky_across(face, uv);
        return vec4(ctx_std(ctx_lucky_hsv(a.x * 2.0 * 0.022 + a.y * 0.5 * 0.8 * 0.022 - t / 120.0, 0.4, 1.0), kind, false, true), 1.0);
    }
    // supreme
    if (kind == 1) return vec4(ctx_lucky_hex(0xc8962c), 1.0);
    float warp = ctx_noise3(vec3(p.x / 7.0, p.y / 7.0 + t / 300.0, p.z / 7.0), 8);
    float n = ctx_noise3(vec3(p.x / 4.0 + warp * 2.5, p.y / 4.0 - t / 150.0, p.z / 4.0 + warp * 2.5), 8);
    float ridge = 1.0 - abs(2.0 * n - 1.0);
    float gold = ctx_ss(0.8, 0.93, ridge);
    float surge = 0.5 + 0.5 * sin(CTX_PT_TAU * (t / 60.0 - p.y / 20.0));
    vec3 c = ctx_mx(0x0a0a0e, 0x1e1c24, ctx_ss(0.3, 0.7, n));
    c = ctx_mx(c, 0x6a4a1a, ctx_ss(0.65, 0.8, ridge) * (1.0 - gold) * 0.6);
    return vec4(ctx_std(ctx_mx(c, ctx_mx(0xb8862a, 0xffe27a, surge), gold), kind), 1.0);
}

// A painted block's pixel (ctx_lucky_color): on a wall seen from inside, the outside's picture where it is, dimmer and
// fainter (art.js insideOf). The wall's quad faces the other way, so uv runs over it as on the opposite face.
vec4 ctx_painted_pixel(int d, int face, vec2 uv, float t, int kind, bool inside) {
    if (!inside) return ctx_painted(d, face, uv, t, kind);
    vec4 c = ctx_painted(d, face, ctx_lucky_uv(face, ctx_lucky_point(face == 0 || face == 2 || face == 4 ? face + 1 : face - 1, uv)), t, kind);
    return vec4(c.rgb * 0.82, c.a * 0.7);
}

// A pixel of a Rainbow chicken's frame in the chicken menu (the generator's MenuArt.rainbow draws the same at tick 0, the
// frame's texture: keep the two the same). picture is what the face is, in GUI pixels: 0 a card (86 x 108), 1 and 2 a
// page's left and right half (140 x 114 each, the right one starting 140 along). A texel's blue says in its lowest two
// bits what it is: 0 not the bevel, drawn as it is (the wells, the plates), 1 the bevel's light edge, 2 its fill, 3 its
// dark edge. The bevel is every hue flowing right along the picture, a little slant down it, as the Rainbow name's
// letters do (chickins_text.glsl's ctx_rainbow_hue) but twice as wide, coming round as often, from where the pixel is, so
// it's smooth at any GUI scale.
#define CTX_FRAME_CARD vec2(86.0, 108.0)
#define CTX_FRAME_HALF vec2(140.0, 114.0)
#define CTX_FRAME_ROUND 80.0               // GUI pixels from a hue to the same one again: twice the name's (the user's call)
#define CTX_FRAME_LIGHT vec2(0.45, 1.0)   // saturation and value: the light edge,
#define CTX_FRAME_FILL vec2(0.7, 0.82)    // the fill,
#define CTX_FRAME_DARK vec2(0.8, 0.64)    // the dark edge
vec4 ctx_frame_pixel(int picture, vec2 uv, float t, vec2 texCoord, sampler2D atlas) {
    vec4 texel = texelFetch(atlas, ivec2(texCoord * vec2(textureSize(atlas, 0))), 0);
    int kind = int(round(texel.b * 255.0)) & 3;
    if (kind == 0) return texel;
    vec2 at = uv / 16.0 * (picture == 0 ? CTX_FRAME_CARD : CTX_FRAME_HALF) + vec2(picture == 2 ? CTX_FRAME_HALF.x : 0.0, 0.0);
    vec2 sv = kind == 1 ? CTX_FRAME_LIGHT : kind == 2 ? CTX_FRAME_FILL : CTX_FRAME_DARK;
    return vec4(ctx_lucky_hsv((at.x + at.y * 0.8) / CTX_FRAME_ROUND - t / 60.0, sv.x, sv.y), texel.a);
}

// A Rainbow egg's pixel: the tier's grey egg in the rainbow's colour where it is, along rounds along it (ctx_lucky_at)
vec4 ctx_egg_pixel(float along, float t, vec2 texCoord, sampler2D atlas) {
    vec4 texel = texture(atlas, texCoord);
    return vec4(texel.rgb * ctx_lucky_hsv(along - t / CTX_EGG_TICKS, CTX_EGG_SATURATION, 1.0), texel.a);
}

// A Lucky Block pixel: info is what its vertices passed on (ctx_lucky_info), uv where it is on the face (ctx_lucky_at),
// texCoord its texture coordinate in atlas. The colour before the light, as the texture's would be.
vec4 ctx_lucky_color(vec4 info, vec2 uv, vec2 texCoord, sampler2D atlas) {
    int face = int(info.x + 0.5);
    int fx = int(info.y + 0.5);
    if (fx == CTX_LUCKY_EGG) return ctx_egg_pixel(uv.x, info.z, texCoord, atlas);
    if (fx == CTX_LUCKY_FLASH) {
        vec4 plate = texture(atlas, texCoord);
        return vec4(mix(plate.rgb, ctx_flash_lit(plate.rgb), ctx_flash(info.z)), plate.a);
    }
    if (fx == CTX_LUCKY_FRAME) return ctx_frame_pixel(face, clamp(uv, 0.0, 16.0), info.z, texCoord, atlas);
    ivec4 texel = ivec4(round(texelFetch(atlas, ivec2(texCoord * vec2(textureSize(atlas, 0))), 0) * 255.0));
    int kind = texel.b & 3;
    if (fx >= CTX_FX_PAINTED) return ctx_painted_pixel(fx - CTX_FX_PAINTED, face, clamp(uv, 0.0, 16.0), info.z, kind, info.w > 0.5);
    if (kind == 3) return vec4(1.0);
    vec3 c = ctx_lucky_panel(fx, face, clamp(uv, 0.0, 16.0), info.z);
    if (kind == 0) return vec4(c, 1.0);
    return vec4(ctx_lucky_shaded(fx, c, kind == 2), 1.0);
}

#endif

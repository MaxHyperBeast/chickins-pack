#ifndef CHICKINS_SURFERS_GLSL
#define CHICKINS_SURFERS_GLSL

// Chickin Surfers, in each release's item shader. Three things only a vertex stage can do, on the client's own clock, at
// its own frame rate, with nothing sent:
//   - A plot's screen, in true perspective. The server places the very scene a player runs through (surfers.Stage) at the
//     screen's middle, going straight off behind the wall, and each vertex is projected onto the window's plane through a
//     camera where the player's starts. It's a projective map, so a long train's side narrows as it should and textures
//     stay right (the position goes on with its w), and a piece at a steady speed speeds up towards the viewer by itself.
//     The picture is flat in that plane, from any side; only the depth test sees near pieces as nearer (ctx_screen_depth).
//     When the player's camera moves, the whole scene moves the other way (Stage.follow: every display rides one entity).
//   - The runners' animation: every face says which part it is, and its corners move by the game's clock. A limb is sheared,
//     its top staying put and its foot swinging: a face's corners come in the order of its uv, (min, min), (min, max),
//     (max, max), (max, min), so corners 1 and 2 of a side are its bottom.
//   - The start's camera, swinging round from in front of the chicken to behind it, on the same clock: the scene turns
//     about the chicken instead, for a player and on a screen alike, so what's on a screen is what they see.
//
// The item's tint says all that: without this shader it's only an odd colour, on a piece nobody should see without it.
//   red   232 + (screen ? 1 : 0) + (start's camera ? 2 : 0) + 4 * (part / 16), or 220 + the same through Chickin
//         Crossing's camera, or 208 + the same through Peckman's (the arcade's games: arcade.Tints)
//   green (part & 15) << 4 | plot
//   blue  gait << 6 | the tick the start began / 8 % 64
// Vertex stage: if ctx_surfers_piece(Color), ctx_surfers_vertex gives the position to draw and what goes with it. A player's
// own view (ctx_surfers_own) then goes through ctx_surfers_own_view instead of ModelViewMat.
// Fragment stage: if ctx_screen_clipped(ctxScreen), discard. Every loop divides 24000 ticks, where the game's clock starts again.

#define CTX_SURFERS_MARK 232
#define CTX_TAU 6.2831853

// Which part a face is (Stage.Part, the generator's SurfersArt.Part): keep the three the same
#define CTX_PART_STILL 0
#define CTX_PART_UNLIT 1
#define CTX_PART_CHICKEN_BODY 2
#define CTX_PART_CHICKEN_HEAD 3
#define CTX_PART_CHICKEN_LEG_A 4
#define CTX_PART_CHICKEN_LEG_B 5
#define CTX_PART_CHICKEN_FOOT_A 6
#define CTX_PART_CHICKEN_FOOT_B 7
#define CTX_PART_CHICKEN_WING_E 8
#define CTX_PART_CHICKEN_WING_W 9
#define CTX_PART_CHICKEN_TAIL 10
#define CTX_PART_RUNNER_BODY 11
// The farmer: A is his right, B his left
#define CTX_PART_RUNNER_LEG_A 12
#define CTX_PART_RUNNER_LEG_B 13
#define CTX_PART_RUNNER_ARM_A 14
#define CTX_PART_RUNNER_ARM_B 15
#define CTX_PART_WOLF_BODY 16
#define CTX_PART_WOLF_HEAD 17
#define CTX_PART_WOLF_FORE_LEFT 18
#define CTX_PART_WOLF_FORE_RIGHT 19
#define CTX_PART_WOLF_TAIL 20
#define CTX_PART_FLOATING 21
#define CTX_PART_FLAME 22
#define CTX_PART_RIDE_BODY 23
#define CTX_PART_RIDE_HEAD 24
#define CTX_PART_RIDE_WING_E 25
#define CTX_PART_RIDE_WING_W 26
#define CTX_PART_RIDE_BOARD 27
#define CTX_PART_RIDE_LEGS 28
#define CTX_PART_RIDE_THRUST 29
// Bobbing as a pickup does and glowing, a little out of step with what's beside it: Peckman's ghosts and golden eggs
#define CTX_PART_GLOWING 30
// 31 to 33 are free (the farmer's shins and forearms once)
#define CTX_PART_WOLF_HIND_LEFT 34
#define CTX_PART_WOLF_HIND_RIGHT 35

// The chasers' run (the generator's SurfersMotion has the same numbers: change both together). A model unit in blocks at
// their display's size (Scene.FARMER_SIZE, WOLF_SIZE / 16); the farmer's bounce (blocks), how far his legs and arms swing
// (radians), his limbs' half depth and length, and how far below an arm's top it turns, as a player's does (units); the
// wolf's bound and rock (blocks), its legs' reach (radians) and length (units), and how far round its stride each leg is
// behind its front left one. Their strides in ticks, by gait, divide 24000.
#define CTX_FARMER_UNIT 0.059375
#define CTX_FARMER_BOUNCE 0.05
#define CTX_FARMER_HIP 1.1
#define CTX_FARMER_SHOULDER 1.0
#define CTX_FARMER_LIMB_HALF_DEPTH 2.0
#define CTX_FARMER_LIMB 12.0
#define CTX_FARMER_SHOULDER_DOWN 2.0
#define CTX_WOLF_UNIT 0.06875
#define CTX_WOLF_BOUND 0.05
#define CTX_WOLF_ROCK 0.03
#define CTX_WOLF_REACH 0.8
#define CTX_WOLF_LEG 7.0
#define CTX_WOLF_FORE_RIGHT -0.6
#define CTX_WOLF_HIND_LEFT 2.5415927
#define CTX_WOLF_HIND_RIGHT 3.1415927

#define CTX_SCREEN_HALF_WIDTH 2.0
#define CTX_SCREEN_HALF_HEIGHT 3.0
// Half the window's height / tan(half of a 75 degree view): Scene.SCREEN_FOV
#define CTX_SCREEN_FOCAL 3.90965
#define CTX_CAMERA_HEIGHT 5.0
#define CTX_CAMERA_BACK 7.5
// sin and cos of the camera's 17 degrees down
#define CTX_CAMERA_SIN 0.292372
#define CTX_CAMERA_COS 0.956305
// Chickin Crossing's pieces (crossing.Scene): the same, from this red, through a camera of their own looking down at the row
// ahead of the chicken. Its scene lies on its side in the world (CrossingStage.local): its x is the world's, its z the world's
// up and its up the world's north, or into the screen, so going forward only ever lifts it; on a screen it's LIFT blocks up,
// above the build height, where the client draws an entity whatever section it's in.
#define CTX_CROSSING_MARK 220
#define CTX_CROSSING_LIFT 300.0
// Its camera looks down at the row ahead of the chicken from 25 blocks back along a line 55 degrees down, turned 18 degrees
// to the left about the vertical (Scene.DISTANCE, PITCH, YAW), through a 26 degree view (Scene.FOV): near flat, as the
// genre looks. Where it is from what it looks at, sin and cos of the pitch and the turn, and the window's focal length.
#define CTX_CROSSING_EYE_X 4.43112
#define CTX_CROSSING_EYE_Y 20.4788
#define CTX_CROSSING_EYE_Z 13.6376
#define CTX_CROSSING_SIN 0.819152
#define CTX_CROSSING_COS 0.573576
#define CTX_CROSSING_YAW_SIN -0.309017
#define CTX_CROSSING_YAW_COS 0.951057
#define CTX_CROSSING_FOCAL 12.9944
// A player's own view is the same: the client's camera is where the server puts it, and the view is zoomed to this half
// field's tan whatever the player's own field of view (ProjMat), so it's the same for everyone
#define CTX_CROSSING_TAN_HALF_FOV 0.230868
// Peckman's pieces (peckman.Scene): the same, from this red, through a camera looking down on the whole maze from 60 blocks
// back along a line 62 degrees down (Scene.DISTANCE, PITCH). Its scene lies flat, as the arcade's menu does; on a screen
// it's LIFT blocks up, above the build height. Where the camera is from the maze's middle, sin and cos of its pitch, a
// screen's focal length (the window's half width over Scene.SCREEN_WIDTH's half, at DISTANCE) and the tan of half a
// player's own view, which is zoomed to it as Crossing's is (Scene.FOV).
#define CTX_PECKMAN_MARK 208
#define CTX_PECKMAN_LIFT 300.0
#define CTX_PECKMAN_EYE_Y 52.97686
#define CTX_PECKMAN_EYE_Z 28.16829
#define CTX_PECKMAN_SIN 0.882948
#define CTX_PECKMAN_COS 0.469472
#define CTX_PECKMAN_FOCAL 10.90909
#define CTX_PECKMAN_TAN_HALF_FOV 0.230868
// To the depth test, a piece is this many blocks nearer the viewer than the picture's plane / how far it is from the picture's
// camera: near ones over far ones. The ground is nearer by least, and what's RELIEF_HEIGHT blocks above it or more by RAISED as
// well, so the sleepers and rails, hardly off the ground, are told from it however far off they are. Going away from the camera
// below the horizon a ray only comes lower, so this never puts something far over something near. It's far more than would fit
// in front of the text, which has its own push (chickins_text.glsl), as anything thinner fights from across a plot.
#define CTX_SCREEN_RELIEF_GROUND 1.0
#define CTX_SCREEN_RELIEF_RAISED 2.0
#define CTX_SCREEN_RELIEF_HEIGHT 0.1
// All of it this many blocks nearer as well, so even the furthest of it never fights the wall behind it
#define CTX_SCREEN_RELIEF_ALL 0.1
// The picture stops this far from the window's top, leaving the wall as a bar for the name and the score
#define CTX_SCREEN_BAR 0.5
// Nearer to the camera than this isn't drawn
#define CTX_SCREEN_NEAR 1.0

// The start's camera (StartShow): in ticks from the start, when it swings and when it's before the start
#define CTX_ORBIT_FROM 38.0
#define CTX_ORBIT_TO 70.0
#define CTX_ORBIT_BEFORE 448.0
#define CTX_ORBIT_LOOP 512.0
// How much nearer and lower it starts than it ends
#define CTX_ORBIT_UP 2.0
#define CTX_ORBIT_IN 2.6

bool ctx_surfers_piece(vec4 color) {
    int red = int(round(color.r * 255.0));
    return red >= CTX_PECKMAN_MARK && red < CTX_SURFERS_MARK + 12;
}

// The tint's red past its camera's mark: screen 1, start's camera 2, the part's high bits 4 and 8
int ctx_surfers_bits(int red) {
    return red - (red >= CTX_SURFERS_MARK ? CTX_SURFERS_MARK : red >= CTX_CROSSING_MARK ? CTX_CROSSING_MARK : CTX_PECKMAN_MARK);
}

int ctx_surfers_part(vec4 color) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    return (c.g >> 4) | ((ctx_surfers_bits(c.r) >> 2) << 4);
}

// Chickin Crossing's scene from the world: CrossingStage.local the other way
vec3 ctx_crossing_scene(vec3 v) {
    return vec3(v.x, -v.z, v.y);
}

// Its camera's turn about the vertical, from the scene
vec3 ctx_crossing_yaw(vec3 v) {
    return vec3(v.x * CTX_CROSSING_YAW_COS + v.z * CTX_CROSSING_YAW_SIN, v.y, -v.x * CTX_CROSSING_YAW_SIN + v.z * CTX_CROSSING_YAW_COS);
}

// A game's view in a player's own, from its camera, already turned about the vertical as it is: tipped down by its pitch,
// zoomed to the game's field of view from the player's own (projection[1][1] is 1 / tan of half of it), and handed to
// ctx_surfers_own_view, which tips everything down the rail camera's 17 degrees, so it's tipped back up by those first
vec3 ctx_game_own_view(vec3 w, float sinDown, float cosDown, float tanHalfFov, mat4 projection) {
    w = vec3(w.x, w.y * cosDown - w.z * sinDown, w.y * sinDown + w.z * cosDown);
    w.xy /= projection[1][1] * tanHalfFov;
    return vec3(w.x, w.y * CTX_CAMERA_COS + w.z * CTX_CAMERA_SIN, -w.y * CTX_CAMERA_SIN + w.z * CTX_CAMERA_COS);
}

// Chickin Crossing's: turned and tipped down as its camera is
vec3 ctx_crossing_own_view(vec3 v, mat4 projection) {
    return ctx_game_own_view(ctx_crossing_yaw(v), CTX_CROSSING_SIN, CTX_CROSSING_COS, CTX_CROSSING_TAN_HALF_FOV, projection);
}

// A piece in a player's own view, rather than on a screen
bool ctx_surfers_own(vec4 color) {
    return ctx_surfers_piece(color) && (int(round(color.r * 255.0)) & 1) == 0;
}

// Where the game's camera sees it, whichever way the client's camera looks: an F5 that looks back turns ModelViewMat round,
// and this keeps the view as it is. It's what ModelViewMat is with the camera looking north and down by the game's pitch.
vec4 ctx_surfers_own_view(vec4 at) {
    return vec4(at.x, at.y * CTX_CAMERA_COS - at.z * CTX_CAMERA_SIN, at.y * CTX_CAMERA_SIN + at.z * CTX_CAMERA_COS, at.w);
}

bool ctx_surfers_unlit(vec4 color) {
    if (!ctx_surfers_piece(color)) {
        return false;
    }
    int part = ctx_surfers_part(color);
    return part == CTX_PART_UNLIT || part == CTX_PART_RIDE_THRUST || part == CTX_PART_GLOWING;
}

// The window's middle of plot's screen, in world coordinates (plots clockwise from the north side's west end)
vec3 ctx_screen_at(int plot) {
    int i = plot % 3;
    float along = float(i) * 44.0;
    int side = plot / 3;
    if (side == 0) return vec3(-59.96875 + along, 44.0, -76.0);
    if (side == 1) return vec3(77.0, 44.0, -59.96875 + along);
    if (side == 2) return vec3(60.96875 - along, 44.0, 77.0);
    return vec3(-76.0, 44.0, 60.96875 - along);
}

// Which way it looks out of the wall: the plot's +u
vec3 ctx_screen_out(int plot) {
    int side = plot / 3;
    if (side == 0) return vec3(1.0, 0.0, 0.0);
    if (side == 1) return vec3(0.0, 0.0, 1.0);
    if (side == 2) return vec3(-1.0, 0.0, 0.0);
    return vec3(0.0, 0.0, -1.0);
}

// Its right, as you look at it: the plot's +v
vec3 ctx_screen_right(int plot) {
    int side = plot / 3;
    if (side == 0) return vec3(0.0, 0.0, -1.0);
    if (side == 1) return vec3(1.0, 0.0, 0.0);
    if (side == 2) return vec3(0.0, 0.0, 1.0);
    return vec3(-1.0, 0.0, 0.0);
}

// Which corner of its box a vertex is, -1 or 1 along each axis of the scene: the normal says which face it's on, and a face's
// corners come in the game's order for that face (26.2 FaceInfo: UP from its north-west corner, south, east, north; a side
// from its top on the left as seen from outside, down, across, up). Only for boxes turned by less than 45 degrees.
vec3 ctx_corner(vec3 normal, int corner) {
    vec3 a = abs(normal);
    float first = corner < 2 ? -1.0 : 1.0;
    float middle = (corner == 1 || corner == 2) ? 1.0 : -1.0;
    if (a.y >= a.x && a.y >= a.z) {
        return normal.y > 0.0 ? vec3(first, 1.0, middle) : vec3(first, -1.0, -middle);
    }
    if (a.z >= a.x) {
        return normal.z < 0.0 ? vec3(-first, -middle, -1.0) : vec3(first, -middle, 1.0);
    }
    return normal.x < 0.0 ? vec3(-1.0, -middle, first) : vec3(1.0, -middle, -first);
}

// How far a limb's vertex moves, in blocks, when the limb turns by angle about a point down below the middle of its top (its
// foot forward, to -z): corner is the vertex's corner of the box (ctx_corner), halfDepth half the box's depth and l its length.
vec3 ctx_swing(vec3 corner, float halfDepth, float l, float down, float angle) {
    vec2 at = vec2((corner.y > 0.0 ? 0.0 : -l) + down, corner.z * halfDepth);
    float s = sin(angle);
    float c = cos(angle);
    return vec3(0.0, at.x * c - at.y * s - at.x, at.x * s + at.y * c - at.y);
}

// The farmer running as a player does, stride radians round: his legs swing from the hip and his arms from the shoulder, each
// arm against the leg on its side, and he's off the ground between strides. A is his right, B his left.
vec3 ctx_farmer_motion(int part, vec3 corner, float stride) {
    vec3 up = vec3(0.0, CTX_FARMER_BOUNCE * (0.5 - 0.5 * cos(2.0 * stride)), 0.0);
    bool left = part == CTX_PART_RUNNER_LEG_B || part == CTX_PART_RUNNER_ARM_B;
    float swing = sin(left ? stride + 3.14159265 : stride);
    float depth = CTX_FARMER_LIMB_HALF_DEPTH * CTX_FARMER_UNIT;
    float limb = CTX_FARMER_LIMB * CTX_FARMER_UNIT;
    if (part == CTX_PART_RUNNER_LEG_A || part == CTX_PART_RUNNER_LEG_B) return up + ctx_swing(corner, depth, limb, 0.0, CTX_FARMER_HIP * swing);
    if (part == CTX_PART_RUNNER_ARM_A || part == CTX_PART_RUNNER_ARM_B) {
        return up + ctx_swing(corner, depth, limb, CTX_FARMER_SHOULDER_DOWN * CTX_FARMER_UNIT, -CTX_FARMER_SHOULDER * swing);
    }
    return up;
}

// The wolf galloping, stride radians round: its front and hind legs reach apart and gather in, it bounds highest stretched
// out, and its back rocks, the front of each box of it up as its back goes down.
vec3 ctx_wolf_motion(int part, vec3 corner, float stride) {
    float up = CTX_WOLF_BOUND * (0.5 + 0.5 * sin(stride));
    float rock = CTX_WOLF_ROCK * sin(stride - 0.6);
    float depth = CTX_WOLF_UNIT;
    float leg = CTX_WOLF_LEG * CTX_WOLF_UNIT;
    if (part == CTX_PART_WOLF_HEAD) return vec3(0.0, up + 1.4 * rock + 0.02 * sin(2.0 * stride), 0.0);
    if (part == CTX_PART_WOLF_TAIL) return vec3(0.06 * sin(stride), up - rock, 0.0);
    if (part == CTX_PART_WOLF_FORE_LEFT) return vec3(0.0, up + rock, 0.0) + ctx_swing(corner, depth, leg, 0.0, CTX_WOLF_REACH * sin(stride));
    if (part == CTX_PART_WOLF_FORE_RIGHT) return vec3(0.0, up + rock, 0.0) + ctx_swing(corner, depth, leg, 0.0, CTX_WOLF_REACH * sin(stride + CTX_WOLF_FORE_RIGHT));
    if (part == CTX_PART_WOLF_HIND_LEFT) return vec3(0.0, up - rock, 0.0) + ctx_swing(corner, depth, leg, 0.0, CTX_WOLF_REACH * sin(stride + CTX_WOLF_HIND_LEFT));
    if (part == CTX_PART_WOLF_HIND_RIGHT) return vec3(0.0, up - rock, 0.0) + ctx_swing(corner, depth, leg, 0.0, CTX_WOLF_REACH * sin(stride + CTX_WOLF_HIND_RIGHT));
    return vec3(0.0, up - corner.z * rock, 0.0);
}

bool ctx_farmer_part(int part) {
    return part >= CTX_PART_RUNNER_BODY && part <= CTX_PART_RUNNER_ARM_B;
}

bool ctx_wolf_part(int part) {
    return part >= CTX_PART_WOLF_BODY && part <= CTX_PART_WOLF_TAIL || part == CTX_PART_WOLF_HIND_LEFT || part == CTX_PART_WOLF_HIND_RIGHT;
}

// How far a part's vertex moves, in blocks of the scene (x right, y up, z towards the camera, the chicken at z 0): a run's gait
// is 0 for still, or how quick its steps are. normal is the vertex's in the scene. low is 1 for what's at the bottom of a
// limb, 0 at its top.
vec3 ctx_surfers_motion(int part, int gait, int vertexId, vec3 normal, float tick, vec3 scene) {
    if (part == CTX_PART_STILL || part == CTX_PART_UNLIT) {
        return vec3(0.0);
    }
    int corner = vertexId & 3;
    float normalY = normal.y;
    float low = normalY < -0.5 ? 1.0 : normalY > 0.5 ? 0.0 : (corner == 1 || corner == 2) ? 1.0 : 0.0;
    if (part >= CTX_PART_RIDE_BODY && part <= CTX_PART_RIDE_THRUST) {
        // On a hoverboard: it all floats together, the board rocks under the chicken, its wings balance and the thrust flickers.
        float hover = 0.07 * sin(fract(tick / 30.0) * CTX_TAU);
        float rock = sin(fract(tick / 24.0) * CTX_TAU);
        float flap = sin(fract(tick / 8.0) * CTX_TAU);
        if (part == CTX_PART_RIDE_BOARD) return vec3(0.0, hover + 0.06 * rock * scene.z, 0.0);
        if (part == CTX_PART_RIDE_LEGS) return vec3(0.0, hover, 0.0);
        if (part == CTX_PART_RIDE_BODY) return vec3(0.0, hover + 0.02 * rock, 0.0);
        if (part == CTX_PART_RIDE_HEAD) return vec3(0.0, hover + 0.03 * rock, -0.03 * rock);
        if (part == CTX_PART_RIDE_WING_E) return vec3(0.08 * low * (1.0 + flap), hover + 0.07 * low * flap, 0.0);
        if (part == CTX_PART_RIDE_WING_W) return vec3(-0.08 * low * (1.0 + flap), hover + 0.07 * low * flap, 0.0);
        return vec3(0.0, hover, max(0.0, scene.z - 0.75) * (0.5 + 0.5 * sin(fract(tick / 3.0) * CTX_TAU)));
    }
    if (part == CTX_PART_FLOATING) {
        return vec3(0.0, 0.12 * sin(fract(tick / 40.0) * CTX_TAU), 0.0);
    }
    if (part == CTX_PART_GLOWING) {
        // Where it is along the floor puts it out of step: a ghost sways as it bobs, and no two keep time.
        return vec3(0.0, 0.07 * sin(fract(tick / 30.0) * CTX_TAU + 1.3 * (scene.x - scene.z)), 0.0);
    }
    if (part == CTX_PART_FLAME) {
        return vec3(0.0, -0.1 * low * (0.5 + 0.5 * sin(fract(tick / 3.0) * CTX_TAU)), 0.0);
    }
    if (gait == 0) {
        return vec3(0.0);
    }
    if (ctx_farmer_part(part)) {
        float stride = fract(tick / (gait == 1 ? 9.6 : gait == 2 ? 8.0 : 6.4)) * CTX_TAU;
        return ctx_farmer_motion(part, ctx_corner(normal, corner), stride);
    }
    if (ctx_wolf_part(part)) {
        float stride = fract(tick / (gait == 1 ? 8.0 : gait == 2 ? 6.4 : 5.0) + 0.3) * CTX_TAU;
        return ctx_wolf_motion(part, ctx_corner(normal, corner), stride);
    }
    float period = gait == 1 ? 8.0 : gait == 2 ? 6.0 : 5.0;
    float phase = fract(tick / period) * CTX_TAU;
    float step = sin(phase);
    float lift = cos(phase);
    float bob = abs(sin(phase));

    if (part == CTX_PART_CHICKEN_BODY) return vec3(0.0, 0.05 * bob, 0.0);
    if (part == CTX_PART_CHICKEN_HEAD) return vec3(0.0, 0.07 * bob, -0.07 * sin(2.0 * phase));
    if (part == CTX_PART_CHICKEN_LEG_A) return vec3(0.0, 0.0, 0.2 * step * low);
    if (part == CTX_PART_CHICKEN_LEG_B) return vec3(0.0, 0.0, -0.2 * step * low);
    if (part == CTX_PART_CHICKEN_FOOT_A) return vec3(0.0, 0.08 * max(0.0, lift), 0.2 * step);
    if (part == CTX_PART_CHICKEN_FOOT_B) return vec3(0.0, 0.08 * max(0.0, -lift), -0.2 * step);
    if (part == CTX_PART_CHICKEN_WING_E) return vec3(0.1 * bob * low, 0.05 * bob, 0.0);
    if (part == CTX_PART_CHICKEN_WING_W) return vec3(-0.1 * bob * low, 0.05 * bob, 0.0);
    if (part == CTX_PART_CHICKEN_TAIL) return vec3(0.05 * step, 0.05 * bob, 0.0);
    return vec3(0.0);
}

// The start's camera: where a point of the scene looks to be with the camera t ticks into its swing round the chicken.
vec3 ctx_surfers_orbit(vec3 point, float t) {
    float along = t >= CTX_ORBIT_BEFORE ? 0.0 : clamp((t - CTX_ORBIT_FROM) / (CTX_ORBIT_TO - CTX_ORBIT_FROM), 0.0, 1.0);
    float eased = along * along * (3.0 - 2.0 * along);
    if (eased >= 1.0) {
        return point;
    }
    float turn = 3.14159265 * (1.0 - eased);
    float c = cos(turn);
    float s = sin(turn);
    float left = 1.0 - eased;
    return vec3(point.x * c + point.z * s, point.y + CTX_ORBIT_UP * left, -point.x * s + point.z * c + CTX_ORBIT_IN * left);
}

// What to add to a clip position's z, for the depth test to see a piece at this height nearer the viewer, along the line they
// look along, without it moving. Blocks nearer along that line at depth z and distance d are worth projection[3][2] * blocks /
// (z * d) in depth, whatever the angle, in any release's depth range; its w is ahead times z, so ahead cancels and what's left
// is linear in the scene: faces meet and cross where they should. d is the window's middle's, the same for every vertex of a
// frame. Standing out for real would make a bowl of the picture, near things at its edges standing out and far things in its
// middle sunk in, and it looks curved from any side but straight on.
float ctx_screen_depth(mat4 projection, vec3 middle, float height, float ahead) {
    float relief = CTX_SCREEN_RELIEF_GROUND + CTX_SCREEN_RELIEF_RAISED * clamp(height / CTX_SCREEN_RELIEF_HEIGHT, 0.0, 1.0);
    return projection[3][2] * (relief + CTX_SCREEN_RELIEF_ALL * ahead) / max(length(middle), 1.0);
}

// A piece's vertex. camera: the camera in world coordinates; position is relative to it. It comes out with the position to draw (w and all), its normal as it is in a player's own view (so every
// screen is lit alike), where to take its fog from and, on a screen, ctxScreen for the fragment stage and ctxDepth to add to
// the clip position's z.
void ctx_surfers_vertex(vec4 color, vec3 position, int vertexId, float gameTime, vec3 camera, mat4 projection, inout vec4 clipInput, inout vec3 normal, inout vec3 fogAt, inout vec4 ctxScreen, inout float ctxDepth) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    bool crossing = c.r >= CTX_CROSSING_MARK && c.r < CTX_SURFERS_MARK;
    bool maze = c.r < CTX_CROSSING_MARK;
    int bits = ctx_surfers_bits(c.r);
    bool onScreen = (bits & 1) != 0;
    bool orbit = (bits & 2) != 0;
    int part = ctx_surfers_part(color);
    int plot = c.g & 15;
    int gait = c.b >> 6;
    float tick = gameTime * 24000.0;

    vec3 middle = ctx_screen_at(plot) - camera;
    vec3 outward = ctx_screen_out(plot);
    vec3 right = ctx_screen_right(plot);
    vec3 eye = crossing ? vec3(CTX_CROSSING_EYE_X, CTX_CROSSING_EYE_Y, CTX_CROSSING_EYE_Z)
            : maze ? vec3(0.0, CTX_PECKMAN_EYE_Y, CTX_PECKMAN_EYE_Z) : vec3(0.0, CTX_CAMERA_HEIGHT, CTX_CAMERA_BACK);
    vec3 scene;
    vec3 sceneNormal;
    if (onScreen) {
        vec3 q = position - middle - vec3(0.0, crossing ? CTX_CROSSING_LIFT : maze ? CTX_PECKMAN_LIFT : 0.0, 0.0);
        scene = vec3(dot(q, right), q.y, dot(q, outward));
        sceneNormal = vec3(dot(normal, right), normal.y, dot(normal, outward));
    } else {
        scene = position;
        sceneNormal = normal;
    }
    if (crossing) {
        scene = ctx_crossing_scene(scene);
        sceneNormal = ctx_crossing_scene(sceneNormal);
    }
    if (!onScreen) {
        scene += eye;   // the game's camera where the client's is
    }
    scene += ctx_surfers_motion(part, gait, vertexId, sceneNormal, tick, scene);
    float height = scene.y;
    if (orbit) {
        scene = ctx_surfers_orbit(scene, mod(tick - float(c.b & 63) * 8.0, CTX_ORBIT_LOOP));
    }
    normal = sceneNormal;
    if (!onScreen) {
        // It's all in the game, so nothing fades: the client fogs by its own render distance, and Surfers' sky has its
        // far wall's corners about 200 blocks from the camera, which fogged the whole wall to the fog colour on a client
        // whose render distance was 12 chunks or less. Crossing's and Peckman's cameras are far back too.
        fogAt = vec3(0.0);
        if (crossing) {
            clipInput = vec4(ctx_crossing_own_view(scene - eye, projection), 1.0);
        } else if (maze) {
            clipInput = vec4(ctx_game_own_view(scene - eye, CTX_PECKMAN_SIN, CTX_PECKMAN_COS, CTX_PECKMAN_TAN_HALF_FOV, projection), 1.0);
        } else {
            clipInput = vec4(scene - eye, 1.0);
        }
        return;
    }

    float sinDown = crossing ? CTX_CROSSING_SIN : maze ? CTX_PECKMAN_SIN : CTX_CAMERA_SIN;
    float cosDown = crossing ? CTX_CROSSING_COS : maze ? CTX_PECKMAN_COS : CTX_CAMERA_COS;
    float focal = crossing ? CTX_CROSSING_FOCAL : maze ? CTX_PECKMAN_FOCAL : CTX_SCREEN_FOCAL;
    vec3 v = scene - eye;
    if (crossing) {
        v = ctx_crossing_yaw(v);
    }
    float up = v.y * cosDown - v.z * sinDown;
    float ahead = -v.y * sinDown - v.z * cosDown;

    float px = focal * v.x;
    float py = focal * up;
    clipInput = vec4(middle * ahead + right * px + vec3(0.0, py, 0.0), ahead);
    ctxScreen = vec4(px, py, ahead, 1.0);
    ctxDepth = ctx_screen_depth(projection, middle, height, ahead);
    fogAt = middle;
}

// Whether a fragment of a screen's picture falls outside its window, or too close to the camera
bool ctx_screen_clipped(vec4 ctxScreen) {
    if (ctxScreen.w < 0.5) {
        return false;
    }
    if (ctxScreen.z < CTX_SCREEN_NEAR) {
        return true;
    }
    vec2 at = ctxScreen.xy / ctxScreen.z;
    return abs(at.x) > CTX_SCREEN_HALF_WIDTH || at.y < -CTX_SCREEN_HALF_HEIGHT || at.y > CTX_SCREEN_HALF_HEIGHT - CTX_SCREEN_BAR;
}

#endif

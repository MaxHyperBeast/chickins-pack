#ifndef CHICKINS_TEXT_GLSL
#define CHICKINS_TEXT_GLSL

// Text effects: ordinary text (labels, titles, the action bar, item names, chat) that the pack animates. The server's
// <fx:name> MiniMessage tag (lol.chickins.text.TextFx) colours every letter #F4GGBB:
//   G = 128 + 4 * effect   effect: CTX_* below
//   B = 128 + 4 * index    index: letter number along the text, spaces skipped, mod 32
// Everything is a multiple of 4 so the vanilla drop shadow (colour * 0.25, rounded down) still decodes: a shadow
// vertex is #3D (32 + effect) (32 + index). Without the pack the letters show in that pinkish red. G has room for 32,
// and the greys text fades through would read as 29 and 30 (ctx_decode), so the effects from CTX_SECOND on are #F0GGBB,
// G = 128 + 4 * (effect - CTX_SECOND), their glow pass #FC…. Their drop shadows are set by the server (TextFx.shadow),
// (68, G, B) and the glow pass's (72, G, B): most colours in their red cast a shadow (a quarter of it) that would read as
// one of them otherwise, the Chicken's #F2D6A2 among them, and no shadow the game makes has a channel over 63.
// The effects were designed on the preview page (the text effects artifact) and match it; the wobblers move their
// letters. A glowing effect's text comes twice (TextFx.prepare): first its glow pass, the same letters coloured #F8GGBB
// (shadow #3E…), then a negative space back and the letters themselves. The glow pass draws only the glow, on its
// drop-shadow copy, moved back under its letter and grown; the letters keep a plain dark drop shadow. So every glow is
// drawn before any letter: on screen the game draws text in order with no depth, a glyph's shadow, then its letter,
// then the next glyph, and a glow drawn with its own letter would cover the letter before it. A bold effect letter comes
// in the pack's bold font (chickins:bold, one glyph already drawn bold) instead: the game draws a bold letter twice, a
// pixel apart, and each copy's colours, from its own position, jumped back a pixel where the second covered the first.
// Fragment shaders also include chickins_text_frag.glsl.
//
// The vertex stage moves and grows quads in units: a GUI pixel on screen, CTX_PX_WORLD blocks in the world (a font
// pixel of a Lucky Block label at scale 0.9). The fragment stage measures the glyph's real size from its quad, so text
// of any size (a 4× title, a label at another scale) still lines up; only the wobble's reach is in units, and the room
// round a glow fits glyph pixels up to CTX_PULL units big (a label up to scale 3.6).

#define CTX_GOLDEN 0
#define CTX_DIAMOND 1
#define CTX_COMMON 2
#define CTX_UNCOMMON 3
#define CTX_RARE 4
#define CTX_SUPER_RARE 5
#define CTX_EPIC 6
#define CTX_LEGENDARY 7
#define CTX_MYTHIC 8
#define CTX_EXOTIC 9
#define CTX_DIVINE 10
#define CTX_CELESTIAL 11
#define CTX_RADIANT 12
#define CTX_ASTRAL 13
#define CTX_ETERNAL 14
#define CTX_ECLIPSE 15
#define CTX_GODLY 16
#define CTX_MERGE 17
#define CTX_MERGE_LINE 18
#define CTX_SELL_SPEED 19
#define CTX_SELL_SPEED_LINE 20
#define CTX_EFFECTS 21         // how many there are (one more than the last): ctx_decode reads no others
// The new rarities', in their own red (above)
#define CTX_SECOND 32          // the first effect in the second red
#define CTX_BRILLIANT 32
#define CTX_ENCHANTED 33
#define CTX_MERCURIAL 34
#define CTX_TOXIC 35
#define CTX_SILKEN 36
#define CTX_THUNDEROUS 37
#define CTX_SHIMMERING 38
#define CTX_WOBBLY 39
#define CTX_PHANTOM 40
#define CTX_LUMINOUS 41
#define CTX_UNDYING 42
#define CTX_MOLTEN 43
#define CTX_FROZEN 44
#define CTX_BLAZING 45
#define CTX_SOLAR 46
#define CTX_LUNAR 47
#define CTX_MAJESTIC 48
#define CTX_CASCADING 49
#define CTX_GALACTIC 50
#define CTX_GLITCHED 51
#define CTX_SHADOWY 52
#define CTX_INKY 53
#define CTX_ELECTRIC 54
#define CTX_TRANSCENDENT 55
#define CTX_SUPREME 56
// The Rainbow modifier's name (chickens.yml): a plain rainbow flowing along, no glow
#define CTX_RAINBOW 57
#define CTX_EFFECTS_SECOND 26  // how many there are from CTX_SECOND

#define CTX_PI 3.14159265
#define CTX_GLOW 4.0            // glyph pixels a glow reaches round its letter (where its blur has faded out)
#define CTX_GLOW_BLUR 1.2       // glyph pixels: how soft a glow is, the spread of the blur of its letters' shapes
#define CTX_GLOW_GAIN 6.0       // how brightly the blurred shape lights the glow (ctx_glow_strength)
#define CTX_WOBBLE 1.2          // units a wobbling letter moves up and down
#define CTX_PULL 4.0            // units a glow's quad moves back up and left (the biggest glyph pixel it fits)...
#define CTX_ROOM 16.0           // ...and grows on every side: 4 glyph pixels round the letter at that size
#define CTX_PX_WORLD 0.0225     // world text: blocks per unit (a Lucky Block label's font pixel, scale 0.9 × 1/40)
#define CTX_DEPTH_STEP 0.03125  // blocks: world glows sit on depths in steps of this (ctx_project)

// A player's head in text in exactly this colour is drawn 3 times as big about its middle, untinted (the visit menu,
// VisitFont.BIG_HEAD): dialog text can't be scaled, and a font can't hold a skin. The game writes a head's quads in the
// style's colour, in the order of a glyph's (26.2 PlayerGlyphProvider). It's nearly white, so a client without these
// shaders sees a plain head at its usual size.
#define CTX_BIG_HEAD ivec3(254, 253, 254)
#define CTX_BIG_HEAD_GROW 8.0   // units each side moves out: 8 wide to 24

// The parkour icon in exactly this colour flutters (Icons.FLUTTER): its glyph is the still flag, and the fragment stage
// moves the flag's columns down in turn (ctx_flutter_px). Its drop shadow is the colour / 4, as no other text's shadow
// is, so the shadow flutters with it. Nearly white, so a client without these shaders sees the still flag.
#define CTX_FLUTTER ivec3(240, 255, 255)
#define CTX_FLUTTER_SHADOW ivec3(60, 63, 63)
#define CTX_FLUTTERING -2.0     // ctx_vertex's info.x for it (-1 is ordinary text)

// The tutorial's arrow on the floor (tutorial.Pointer) in exactly this colour (TutorialFont.TRAIL_COLOR): one glyph the
// server stretches from in front of the player's feet to the pad, on which the fragment stage draws yellow chevrons
// pointing along the text, to the pad, gliding that way on the game's clock (ctx_trail_px): smooth at any frame rate,
// with nothing sent. A client without these shaders sees a plain strip in about that yellow.
#define CTX_TRAIL ivec3(254, 212, 64)
#define CTX_TRAILING -3.0       // ctx_vertex's info.x for it
#define CTX_TRAIL_ROWS 9.0      // its glyph's height, in pixels as long along it as across (TutorialFont.TRAIL_ACROSS)
#define CTX_TRAIL_THICK 5.0     // a chevron's arms, in pixels along: it's floor(ROWS / 2) + THICK long, its point in front
#define CTX_TRAIL_PITCH 11.0    // pixels from one chevron to the next: a gap of 2 behind each
#define CTX_TRAIL_SPEED 0.55    // pixels a tick: PITCH / SPEED ticks divides 24000, where the game's clock starts again
#define CTX_TRAIL_FADE 8.0      // pixels a chevron fades in over after the line's start, and out over before its end

// Pickup popups (lol.chickins.text.Popups): the +Eggs, +$Money, +Chickens and so on that pop up over the hotbar and
// float up as they fade, on the game's clock. They're on the action bar's line, each placed across by spaces, and every
// glyph's colour, and its drop shadow's (the server sets shadow_color), says what it is:
//   R  a letter's CTX_POPUP_LETTER, a shadow's CTX_POPUP_SHADOW, + 4 * (hue / 64)
//   G  4 * the tick it starts on, mod CTX_POPUP_SLOTS
//   B  4 * (hue mod 64)
// where hue is ctx_popup_hue's. No shadow the game makes is CTX_POPUP_SHADOW's red, as its own are a quarter of their
// letter's (under 64). Where it starts, across (ACROSS) and below the line (DROP), comes from that tick, so every glyph
// knows the popup's middle and a pile's land all over. Only GUI text on the action bar's line is one (26.2 Gui: its
// line's top CTX_POPUP_LINE above the screen's bottom), so no other text in those colours moves. The server sends the
// bar again as each one ends (ActionBars), so a bar the client still shows never plays one twice. A client without
// these shaders sees them standing on the line in odd colours.
#define CTX_POPUP_LETTER 192    // to 204: 200 is Lavender's red, but its green isn't a multiple of 4
#define CTX_POPUP_SHADOW 100    // to 112
#define CTX_POPUP_SLOTS 64      // divides 24000, where the game's clock starts again
#define CTX_POPUP_LIFE 26.0     // ticks it shows
#define CTX_POPUP_POP 4.0       // ticks it pops in over, from CTX_POPUP_SMALL of its size and a little past it
#define CTX_POPUP_SMALL 0.3
#define CTX_POPUP_RISE 16.0     // GUI pixels it rises over its life, slowing down
#define CTX_POPUP_FADE 9.0      // ticks it fades out over, at its end
#define CTX_POPUP_DROP 6        // GUI pixels below the line's top its letters start: DROP + slot * DROP_STEP % DROPS
#define CTX_POPUP_DROP_STEP 13  // so popups a tick apart start apart
#define CTX_POPUP_DROPS 18      // down to just over the hearts
#define CTX_POPUP_ACROSS 112    // GUI pixels its middle starts from the screen's: -ACROSS + 4 * (slot * ACROSS_STEP % ACROSSES)
#define CTX_POPUP_ACROSS_STEP 25   // so popups a tick apart start a popup's width apart or more
#define CTX_POPUP_ACROSSES 57   // over the hotbar and a little past its ends
#define CTX_POPUP_LINE 72.0     // the action bar line's top, above the screen's bottom
#define CTX_POPUP_SLACK 3.5     // GUI pixels a popup glyph's quad top may be off it, either way (the icon's is a pixel higher)
#define CTX_POPUP_TIERS 16      // the hue of Tier 1's colour; tier t's is TIERS + t - 1
#define CTX_POPUP_TIER_COUNT 200  // chickens.yml tier-colors, in CTX_POPUP_TIER_COLORS

// The global event's card (lol.chickins.globalevent.EventCard): a boss bar's name, laid out from the screen's middle (it
// measures 0 wide), which these move to the screen's top-left corner from wherever its bar is in the list (the first
// bar's line at y CARD_LINE, each next one CARD_STEP lower). Every glyph's colour, and a letter's drop shadow's (the
// server sets shadow_color), says what it is:
//   R  a glyph's CTX_CARD_LETTER, a shadow's CTX_CARD_SHADOW, + 4 * (hue / 64)
//   G  4 * its part: where on the card it goes (ctx_card_part)
//   B  4 * (hue mod 64)
// where hue is ctx_card_hue's. The card's pictures (chickins:event_card) are white where they're tinted: the strip that
// drains. Golden's, Diamond's and Rainbow's hues are their text effects; on a row, Rainbow's and
// RAINBOW_DEEP are the rainbow flowing along it with the name's (ctx_card_rainbow_px), its light and its deep shade. Before it moves, a
// glyph's top is its line's + 7 - its ascent, which ctx_card_part knows for every part; only GUI text on a boss bar's
// line moves. A client without these shaders sees the card in pieces and odd colours on its bar's line.
#define CTX_CARD_LETTER 148     // a glyph's red, for hues 0 to 63 (4 more for each 64 more)
#define CTX_CARD_SHADOW 84      // no shadow the game makes is that red: theirs are a quarter of their letter's
#define CTX_CARD_X 3.0          // where the card's top left goes, in GUI pixels
#define CTX_CARD_Y 3.0
#define CTX_CARD_LINE 3.0       // the first boss bar's name's line, and how much lower each next one's is
#define CTX_CARD_STEP 19.0
#define CTX_CARD_H 32           // the plaque's height (part 0)
#define CTX_CARD_ICON 18        // the icon's size (part 1), and its top on the card
#define CTX_CARD_ICON_Y 6       // (the icon's top)
#define CTX_CARD_LABEL_Y 3      // the text's lines' tops on the card (parts 2, 3 and 4)
#define CTX_CARD_NAME_Y 11      // (the name's)
#define CTX_CARD_TIME_Y 21      // (the time's)
#define CTX_CARD_ROWS 16        // part ROWS + r: row r of the card, a pixel high, ROW_DROP below its line before it moves
#define CTX_CARD_ROW_DROP 7     // (a row's glyphs have ascent 0)
#define CTX_CARD_HUES 76        // how many hues the palette has (CTX_CARD_COLORS)
#define CTX_CARD_GOLDEN 64      // Golden's, Diamond's and Rainbow's hues, which are their text effects
#define CTX_CARD_DIAMOND 65     // (Diamond's)
#define CTX_CARD_RAINBOW 66     // (Rainbow's)
#define CTX_CARD_RAINBOW_DEEP 75   // a row in the rainbow's deep shade (Rainbow's own is its light one)
#define CTX_CARD_RAINBOWING -4.0   // ctx_vertex's info.x for a rainbow row: info.y and z its saturation and value
#define CTX_CARD_RAINBOW_LIGHT vec2(0.45, 1.0)
#define CTX_CARD_RAINBOW_DEEP_SV vec2(0.7, 0.82)

// ctx_vertex's kinds of quad (info.z)
#define CTX_LETTER 0.0
#define CTX_SHADOW 1.0         // the drop shadow of an effect without a glow
#define CTX_SHADOW_PLAIN 2.0   // a glowing effect's dark drop shadow (its glow is the glow pass's)
#define CTX_GLOW_QUAD 3.0      // a glow pass's drop-shadow quad, grown: the glow
#define CTX_HIDDEN 4.0         // a glow pass's letter, which draws nothing (nor its shadow where items draw the glow)

// CTX_GLOW_IN_ITEMS (defined by 1.21.11's text shaders): world labels' glows aren't drawn with the text. 1.21.11 draws
// all text before any item display, and a glow, see-through but writing depth like all text, would cut holes in every
// item behind it. An item display just behind the label draws it instead (chickins_glow_item.glsl), sorted with the
// other items, and the glow pass draws nothing.

// A vertex's number in its own draw: the draw's base vertex (CTX_BASE_VERTEX) comes off where the vertex shader has it, as
// from 26.2 a frame's draws share one vertex buffer (chickins_lucky.glsl says why: change both together)
#ifndef CTX_VERTEX_ID
#ifdef VULKAN
#define CTX_BUFFER_VERTEX gl_VertexIndex
#else
#define CTX_BUFFER_VERTEX gl_VertexID
#endif
#ifdef CTX_BASE_VERTEX
#define CTX_VERTEX_ID (CTX_BUFFER_VERTEX - CTX_BASE_VERTEX)
#else
#define CTX_VERTEX_ID CTX_BUFFER_VERTEX
#endif
#endif

// (effect, letter index, flags: 1 the drop shadow, 2 the glow pass), or effect -1 for ordinary text
ivec3 ctx_decode(vec4 color) {
    // only the effects there are (below CTX_EFFECTS): text that fades through greys (subtitles) passes #F4F4F4 and
    // #F8F8F8, and their shadows #3D3D3D and #3E3E3E, which would read as effect 29 otherwise (and #F0F0F0 and
    // #FCFCFC as CTX_SECOND + 28 and + 31)
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if ((c.r == 244 || c.r == 248) && c.g >= 128 && c.g < 128 + 4 * CTX_EFFECTS && c.b >= 128
            && (c.g & 3) == 0 && (c.b & 3) == 0) {
        return ivec3((c.g - 128) >> 2, (c.b - 128) >> 2, c.r == 248 ? 2 : 0);
    }
    if ((c.r == 240 || c.r == 252) && c.g >= 128 && c.g < 128 + 4 * CTX_EFFECTS_SECOND && c.b >= 128
            && (c.g & 3) == 0 && (c.b & 3) == 0) {
        return ivec3(CTX_SECOND + ((c.g - 128) >> 2), (c.b - 128) >> 2, c.r == 252 ? 2 : 0);
    }
    if ((c.r == 61 || c.r == 62) && c.g >= 32 && c.g < 32 + CTX_EFFECTS && c.b >= 32 && c.b < 64) {
        return ivec3(c.g - 32, c.b - 32, c.r == 62 ? 3 : 1);
    }
    if ((c.r == 68 || c.r == 72) && c.g >= 128 && c.g < 128 + 4 * CTX_EFFECTS_SECOND && c.b >= 128
            && (c.g & 3) == 0 && (c.b & 3) == 0) {
        return ivec3(CTX_SECOND + ((c.g - 128) >> 2), (c.b - 128) >> 2, c.r == 72 ? 3 : 1);
    }
    return ivec3(-1, 0, 0);
}

vec3 ctx_hex(int c) {
    return vec3(float((c >> 16) & 255), float((c >> 8) & 255), float(c & 255)) / 255.0;
}

vec3 ctx_hsv(float h, float s, float v) {
    vec3 k = clamp(abs(fract(h + vec3(0.0, 2.0, 1.0) / 3.0) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

// Godly's rainbow: the hue at text column x, flowing right
float ctx_godly_hue(float x, float t) {
    return fract(x * 0.022 - t * 0.012);
}

// Transcendent's soft rainbow: Godly's, slower
float ctx_transcendent_hue(float x, float t) {
    return fract(x * 0.022 - t / 120.0);
}

// The Rainbow modifier's hue at text column x and row y: every hue flowing right along the letters, a little slant down
// them (its letters, and the event card's rainbow rows, which flow with its name)
float ctx_rainbow_hue(float x, float y, float t) {
    return fract((x + y * 0.8) / 40.0 - t / 60.0);
}

// Thunderous's flash, 30 ticks round: two strikes, then fading (the block's)
float ctx_thunder_lit(float t) {
    float T = mod(t, 30.0);
    return T < 2.0 ? 1.0 : T < 3.0 ? 0.3 : T < 6.0 ? 1.0 : T < 12.0 ? (12.0 - T) / 6.0 * 0.8 : 0.0;
}

// Undying's heartbeat, two beats every 24 ticks (the block's)
float ctx_heartbeat(float t) {
    float T = mod(t, 24.0);
    return exp(-T / 2.2) + (T >= 6.0 ? 0.7 * exp(-(T - 6.0) / 2.2) : 0.0);
}

// Divine and up (lucky-blocks.yml's order), and every new rarity's but Brilliant's, which comes before Divine
bool ctx_glows(int fx) {
    return fx >= CTX_DIVINE && fx <= CTX_GODLY || fx >= CTX_ENCHANTED && fx <= CTX_SUPREME;
}

// The wobblers (Radiant and up) move like Godly's wave, faster the rarer: radians per tick, 0 for none. Enchanted comes
// between Astral and Eternal, and Mercurial to Supreme, in order, between Eclipse and Godly.
float ctx_wobble(int fx) {
    if (fx == CTX_RADIANT) return 0.08;
    if (fx == CTX_ASTRAL) return 0.10;
    if (fx == CTX_ENCHANTED) return 0.11;
    if (fx == CTX_ETERNAL) return 0.12;
    if (fx == CTX_ECLIPSE) return 0.14;
    if (fx >= CTX_MERCURIAL && fx <= CTX_SUPREME) return 0.14 + 0.02 * float(fx - CTX_ENCHANTED) / 24.0;
    if (fx == CTX_GODLY) return 0.16;
    return 0.0;
}

// The drop shadow's colour for the effects without a glow
vec3 ctx_shadow(int fx) {
    if (fx == CTX_GOLDEN) return ctx_hex(0x3f340f);
    if (fx == CTX_DIAMOND) return ctx_hex(0x173839);
    if (fx == CTX_COMMON) return ctx_hex(0x2b2f32);
    if (fx == CTX_UNCOMMON) return ctx_hex(0x1b360f);
    if (fx == CTX_RARE) return ctx_hex(0x0a2638);
    if (fx == CTX_SUPER_RARE) return ctx_hex(0x131b3c);
    if (fx == CTX_EPIC) return ctx_hex(0x2a153a);
    if (fx == CTX_LEGENDARY) return ctx_hex(0x3c280f);
    if (fx == CTX_MYTHIC) return ctx_hex(0x3a1212);
    if (fx == CTX_EXOTIC) return ctx_hex(0x3f1737);
    if (fx == CTX_MERGE) return ctx_hex(0x3f3510);   // what #FFD541's plain text gets, so going on and off shows nothing
    if (fx == CTX_MERGE_LINE) return ctx_hex(0x3c3528);   // and #F2D6A2's
    if (fx == CTX_SELL_SPEED) return ctx_hex(0x0f2c3c);   // Sell Speed's #3CB1F0
    if (fx == CTX_SELL_SPEED_LINE) return ctx_hex(0x153f15);   // and its price's #55FF55
    if (fx == CTX_BRILLIANT) return ctx_hex(0x16343e);
    if (fx == CTX_RAINBOW) return ctx_hex(0x30203f);
    return vec3(0.25);
}

// The darker drop shadow kept inside each glow, so pale names stay readable against the sky; Godly's follows its rainbow
// at text column x
vec3 ctx_glow_dark(int fx, float x, float t) {
    if (fx == CTX_DIVINE) return ctx_hex(0x143439);
    if (fx == CTX_CELESTIAL) return ctx_hex(0x363650);
    if (fx == CTX_RADIANT) return ctx_hex(0x3d310f);
    if (fx == CTX_ASTRAL) return ctx_hex(0x120a30);
    if (fx == CTX_ETERNAL) return ctx_hex(0x083125);
    if (fx == CTX_ECLIPSE) return ctx_hex(0x140b1f);
    if (fx == CTX_ENCHANTED) return ctx_hex(0x1c1236);
    if (fx == CTX_MERCURIAL) return ctx_hex(0x22262e);
    if (fx == CTX_TOXIC) return ctx_hex(0x142a0c);
    if (fx == CTX_SILKEN) return ctx_hex(0x0a2e1e);
    if (fx == CTX_THUNDEROUS) return ctx_hex(0x1a2234);
    if (fx == CTX_SHIMMERING) return ctx_hex(0x0a2e3a);
    if (fx == CTX_WOBBLY) return ctx_hex(0x3a0a1a);
    if (fx == CTX_PHANTOM) return ctx_hex(0x1a1030);
    if (fx == CTX_LUMINOUS) return ctx_hex(0x3a1420);
    if (fx == CTX_UNDYING) return ctx_hex(0x340410);
    if (fx == CTX_MOLTEN) return ctx_hex(0x2a0a04);
    if (fx == CTX_FROZEN) return ctx_hex(0x0e2a3c);
    if (fx == CTX_BLAZING) return ctx_hex(0x3a0e0a);
    if (fx == CTX_SOLAR) return ctx_hex(0x3a1806);
    if (fx == CTX_LUNAR) return ctx_hex(0x141a44);
    if (fx == CTX_MAJESTIC) return ctx_hex(0x3a2a0c);
    if (fx == CTX_CASCADING) return ctx_hex(0x0a2444);
    if (fx == CTX_GALACTIC) return ctx_hex(0x120830);
    if (fx == CTX_GLITCHED) return ctx_hex(0x082028);
    if (fx == CTX_SHADOWY) return ctx_hex(0x0a0a0e);
    if (fx == CTX_INKY) return ctx_hex(0x141838);
    if (fx == CTX_ELECTRIC) return ctx_hex(0x2a0828);
    if (fx == CTX_TRANSCENDENT) return ctx_hsv(ctx_transcendent_hue(x, t), 0.5, 0.25);
    if (fx == CTX_SUPREME) return ctx_hex(0x1a140a);
    return ctx_hsv(ctx_godly_hue(x, t), 0.8, 0.28);   // Godly
}

// A glow's colour and strength at text column x and row y, the letters' own positions (CtxFrag's X and y), so it flows
// along the text as smoothly as they do; the fragment shader fades it out towards its edge
vec4 ctx_glow(int fx, float x, float y, float t) {
    float breath = sin(t * 0.05 - x * (0.4 / 6.0));
    if (fx == CTX_DIVINE) return vec4(ctx_hex(0x52cfe3), 0.24 + 0.12 * breath);
    if (fx == CTX_CELESTIAL) return vec4(ctx_hex(0xaab6dc), 0.26 + 0.12 * breath);
    if (fx == CTX_RADIANT) return vec4(ctx_hex(0xf2c43c), 0.26 + 0.12 * breath);
    if (fx == CTX_ASTRAL) return vec4(ctx_hex(0x7a5cff), 0.4);
    if (fx == CTX_ETERNAL) return vec4(ctx_hex(0x22c495), 0.22 + 0.16 * (0.5 + 0.5 * sin(t * 0.15 - x * (0.8 / 6.0))));
    if (fx == CTX_ECLIPSE) return vec4(ctx_hex(0xcdb8ff), 0.4 + 0.14 * breath);   // a pale lavender corona
    if (fx == CTX_ENCHANTED) return vec4(ctx_hex(0xb070f8), 0.28 + 0.12 * breath);
    if (fx == CTX_MERCURIAL) return vec4(ctx_hex(0xc8d2e0), 0.26 + 0.12 * breath);
    if (fx == CTX_TOXIC) return vec4(ctx_hex(0x9ae03a), 0.3 + 0.12 * breath);
    if (fx == CTX_SILKEN) return vec4(ctx_hex(0x3acb88), 0.28 + 0.12 * breath);
    if (fx == CTX_THUNDEROUS) return vec4(ctx_hex(0x8ea4cc), 0.22 + 0.3 * ctx_thunder_lit(t));   // flashing with the storm
    if (fx == CTX_SHIMMERING) return vec4(ctx_hex(0x4adcd8), 0.3 + 0.12 * breath);
    if (fx == CTX_WOBBLY) return vec4(ctx_hex(0xf0406e), 0.3 + 0.12 * breath);
    if (fx == CTX_PHANTOM) return vec4(ctx_hex(0x7a5cc8), 0.18 + 0.26 * (0.5 + 0.5 * sin(6.2831853 * t / 80.0)));   // a ghost's
    if (fx == CTX_LUMINOUS) return vec4(ctx_hex(0xf79a62), 0.32 + 0.12 * breath);
    if (fx == CTX_UNDYING) return vec4(ctx_hex(0xe8304a), 0.2 + 0.3 * ctx_heartbeat(t));   // beating
    if (fx == CTX_MOLTEN) return vec4(ctx_hex(0xff8a2a), 0.32 + 0.14 * sin(6.2831853 * t / 40.0 - x / 8.0));
    if (fx == CTX_FROZEN) return vec4(ctx_hex(0x9ad4f4), 0.3 + 0.12 * breath);
    if (fx == CTX_BLAZING) return vec4(ctx_hex(0xff8a1a), 0.34 + 0.12 * sin(t * 0.3 + x * 0.2));   // flickering
    if (fx == CTX_SOLAR) return vec4(ctx_hex(0xf07a2a), 0.34 + 0.12 * breath);
    if (fx == CTX_LUNAR) return vec4(ctx_hex(0xc4cce4), 0.3 + 0.12 * breath);
    if (fx == CTX_MAJESTIC) return vec4(ctx_hex(0xe8b848), 0.34 + 0.12 * breath);
    if (fx == CTX_CASCADING) return vec4(ctx_hex(0x6ac0f0), 0.3 + 0.12 * breath);
    if (fx == CTX_GALACTIC) return vec4(ctx_hex(0xb07af0), 0.36 + 0.12 * breath);
    if (fx == CTX_GLITCHED) return vec4(ctx_hex(0x3ae8ff), mod(t, 60.0) >= 42.0 && mod(t, 60.0) < 52.0 ? 0.5 : 0.28);   // bursting with it
    if (fx == CTX_SHADOWY) return vec4(ctx_hex(0x14141c), 0.5 + 0.12 * breath);   // a dark aura
    if (fx == CTX_INKY) return vec4(ctx_hex(0x6a74c8), 0.32 + 0.12 * breath);
    if (fx == CTX_ELECTRIC) return vec4(ctx_hex(0xf070d8), 0.3 + 0.14 * sin(6.2831853 * t / 8.0));   // crackling
    if (fx == CTX_TRANSCENDENT) return vec4(ctx_hsv(ctx_transcendent_hue(x + y * 0.8, t), 0.35, 1.0), 0.36 + 0.12 * breath);
    if (fx == CTX_SUPREME) return vec4(ctx_hex(0xf0c050), 0.38 + 0.14 * sin(6.2831853 * t / 60.0 - x / 20.0));
    return vec4(ctx_hsv(ctx_godly_hue(x + y * 0.8, t), 0.7, 1.0), 0.38 + 0.14 * sin(t * 0.1));   // Godly, as its letters
}

// How much of a blur round p (glyph pixels) falls on the pixel square from lo to lo + 1: a Gaussian's, in the
// logistic approximation. A glow is the sum of this over its letters' pixels, their shapes blurred, which is smooth
// everywhere; a glow from the distance to the nearest pixel creased wherever that pixel changed (between letters, in
// their corners), and the creases showed as outlines.
float ctx_cover1(float lo, float p) {
    float k = 1.702 / CTX_GLOW_BLUR;
    return 1.0 / (1.0 + exp(k * (p - lo - 1.0))) - 1.0 / (1.0 + exp(k * (p - lo)));
}

float ctx_cover(vec2 lo, vec2 p) {
    return ctx_cover1(lo.x, p.x) * ctx_cover1(lo.y, p.y);
}

// A glow's strength (0 to 1, times ctx_glow's) from its letters' blurred shape (the sum of ctx_cover)
float ctx_glow_strength(float cover) {
    return 1.0 - exp(-CTX_GLOW_GAIN * cover);
}

// Moves a glyph corner by d units, x along the text and y down. GUI text is in GUI pixels; world text (labels that face
// the camera) moves along the camera's right and up. Those come from the whole view and projection, not the model-view
// matrix alone: depending on the release, the camera's turn is in the model-view matrix or already in the positions,
// and only the combination is right in both.
void ctx_move(inout vec3 position, vec2 d, mat4 modelView, mat4 proj) {
    if (proj[2][3] == 0.0) {
        position.xy += d;
        return;
    }
    mat4 m = proj * modelView;
    vec3 right = normalize(vec3(m[0][0], m[1][0], m[2][0]));
    vec3 up = normalize(vec3(m[0][1], m[1][1], m[2][1]));
    position += (right * d.x - up * d.y) * CTX_PX_WORLD;
}

// Every tier's colour, chickens.yml tier-colors in order (PopupsTest checks they're the same)
const int CTX_POPUP_TIER_COLORS[CTX_POPUP_TIER_COUNT] = int[CTX_POPUP_TIER_COUNT](
    0xf2d6a2, 0xc98e5b, 0x92d4e2, 0xf2eba8, 0x5bc24a, 0xbcc765, 0xf0566c, 0xf3a0b5,
    0xb4b2ac, 0xe8cf7a, 0xf2c232, 0xc8a86a, 0xf58a2c, 0xf2a0b4, 0xd9d4cb, 0xffb98c,
    0xf8e36b, 0xf0505a, 0xf2c040, 0xe0324e, 0xa8d048, 0xb0805a, 0xf2a6c8, 0xc8aef0,
    0x8ee6b8, 0xa8a8b0, 0xf07a2e, 0xe0e0e8, 0x2aa0c8, 0xf59a2e, 0x3aa86a, 0xf0524b,
    0xe0483a, 0xf5c02e, 0xe8402e, 0xd89a58, 0x8ab86a, 0xe8e4d8, 0x6ccd5a, 0x8ada6a,
    0xc060f0, 0xa5a5a5, 0xe8ecf8, 0xff6a2a, 0xff7a1f, 0x6aa0f0, 0xbce7ff, 0x86b657,
    0x7ebe54, 0xa87a4a, 0x9aa0ac, 0xe08a55, 0xcdd1d6, 0xb088e0, 0xc77deb, 0xf0402a,
    0x4a78e0, 0x6af4ec, 0xe8ecf4, 0x2ac870, 0xd8d2c8, 0xb585ff, 0xffd860, 0xd8ecff,
    0x8a94a6, 0x8a7c80, 0x29dfeb, 0xd0d4dc, 0xf3ac25, 0xe8283f, 0x4f82f0, 0x38be79,
    0xf8b040, 0x6ae0f0, 0xb8eeff, 0xb8b8c8, 0x7dbbff, 0xe8c878, 0xf4806e, 0x38c8d8,
    0x3ac8b8, 0x6cc8b6, 0xd8d84a, 0x2bc0b9, 0xffd030, 0x5ac8c0, 0xe8b878, 0xf06a50,
    0x8ad858, 0xb8d8ff, 0xf3a8c8, 0xf3a0be, 0x9a9aa6, 0xe0602e, 0xc88a4a, 0x5cc06a,
    0x74c95a, 0xf5ae2a, 0xff8dc9, 0xf0505a, 0xb47a50, 0xe0a860, 0x8fe0c0, 0xf57ab0,
    0xe8b060, 0xf7854f, 0xf3a0b0, 0xf8e080, 0xf2b84a, 0xf0a040, 0xf0a040, 0xf77fe0,
    0xf0505a, 0xe8e8f0, 0xe0404e, 0x4a7ae8, 0xffb03a, 0xa8d8f8, 0x5cc060, 0xf5821e,
    0xe4ecf4, 0xc8844a, 0x3ac070, 0x4cc060, 0xe8484a, 0x6a8ae8, 0xd8b040, 0x5a8ae8,
    0x5ab04a, 0x5a8ae8, 0xf2c040, 0xf0c0e9, 0xe8a8f8, 0xf0503a, 0xe0a050, 0xe04a3a,
    0xf8c830, 0xf0a040, 0xf0f0f0, 0xd89a5a, 0xe8a040, 0x5a7ad8, 0xe04a2a, 0xc89060,
    0xd8c08a, 0xc8925a, 0x4ac8be, 0x7ae05a, 0xf2c850, 0x6ac8a4, 0xc89a6a, 0xa8c0e8,
    0xe04048, 0xd83a4a, 0xe0a040, 0x5a8af0, 0x6a8af0, 0x7ad04a, 0xc88a4a, 0x5aa8f0,
    0xa8b8e0, 0xffd541, 0x7adcf0, 0xf8e04c, 0xf0408a, 0xff6ab0, 0xf060d0, 0x4ab0ff,
    0xc08a4a, 0x9cdb43, 0x8ae0ff, 0x9ac4e0, 0xff5a5a, 0x9af4ff, 0x3af0d8, 0x4af080,
    0xf800f8, 0xf5c400, 0x9cdb43, 0x9af0e0, 0xf0f4fa, 0xa8e0ff, 0xf0d8a1, 0xd4d4e0,
    0xffc31c, 0x7f6cf0, 0x44b874, 0x7ad05a, 0xe8502a, 0xff6a1a, 0x9a7be3, 0x6c8cff,
    0xc8e8ff, 0xf0e8ff, 0xe58cff, 0xb89aff, 0x5ad07a, 0xffe890, 0xff3a50, 0xffe04a
);

// A popup's colours (Popups' hues): white (an icon as it is), the sidebar's Money green, Sell Speed's blue, the Eggs' 8
// Warm shades of the Chicken's label colour (#F2D6A2), apricot to butter, every other one a little richer (picked on the
// pickup popups page), the modifiers' names (Golden, Diamond, Rainbow: their text effects, these only their middle colour), and
// every tier's colour
vec3 ctx_popup_hue(int hue) {
    if (hue == 1) return ctx_hex(0x55ff55);
    if (hue == 2) return ctx_hex(0x3cb1f0);
    if (hue == 3) return ctx_hex(0xf3c8a8);
    if (hue == 4) return ctx_hex(0xffc892);
    if (hue == 5) return ctx_hex(0xf2d0a6);
    if (hue == 6) return ctx_hex(0xfcd295);
    if (hue == 7) return ctx_hex(0xf0d8a9);
    if (hue == 8) return ctx_hex(0xf6db97);
    if (hue == 9) return ctx_hex(0xefdfae);
    if (hue == 10) return ctx_hex(0xf5e297);
    if (hue == 11) return ctx_hex(0xfcd03c);   // Golden: four times its effect's shadow (ctx_popup draws its effect instead)
    if (hue == 12) return ctx_hex(0x5ce0e4);   // Diamond
    if (hue == 13) return ctx_hex(0xc080fc);   // Rainbow
    if (hue >= CTX_POPUP_TIERS && hue < CTX_POPUP_TIERS + CTX_POPUP_TIER_COUNT) return ctx_hex(CTX_POPUP_TIER_COLORS[hue - CTX_POPUP_TIERS]);
    return vec3(1.0);
}

// Moves a pickup popup's glyph corner and colours it (see CTX_POPUP_LETTER); false, touching nothing, for any other text.
// corner is ctx_vertex's. info comes back as ctx_vertex returns it: ordinary text, but for Golden's, Diamond's and Rainbow's hues,
// which are their text effects, flowing along the popup as along any text.
bool ctx_popup(inout vec4 color, inout vec3 position, mat4 proj, float gameTime, int corner, out vec4 info) {
    info = vec4(-1.0, 0.0, 0.0, 0.0);
    if (proj[2][3] != 0.0) return false;   // GUI text only
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if (((c.r | c.g | c.b) & 3) != 0) return false;
    bool shadow = c.r >= CTX_POPUP_SHADOW && c.r <= CTX_POPUP_SHADOW + 12;
    if (!shadow && (c.r < CTX_POPUP_LETTER || c.r > CTX_POPUP_LETTER + 12)) return false;
    // Its quad's top: a default font glyph's quad is its cell, 8 high (the icon's 9), and a shadow's a pixel down. Judged
    // by the quad's top, all its corners judge alike: on 1.21.11 the icon's top corners once fell outside a tighter check
    // of each corner and stayed put, raw pink, while its bottom ones moved, stretching it from the line.
    float top = position.y - (corner == 1 || corner == 2 ? 8.0 : 0.0) - (shadow ? 1.0 : 0.0);
    float height = round(2.0 / abs(proj[1][1]));   // the GUI's size, from its projection
    float width = round(2.0 / abs(proj[0][0]));
    if (abs(height - top - CTX_POPUP_LINE) > CTX_POPUP_SLACK) return false;
    int slot = c.g >> 2;
    int hue = ((c.r - (shadow ? CTX_POPUP_SHADOW : CTX_POPUP_LETTER)) >> 2) * 64 + (c.b >> 2);
    float across = float(-CTX_POPUP_ACROSS + 4 * (slot * CTX_POPUP_ACROSS_STEP % CTX_POPUP_ACROSSES));
    vec2 middle = vec2(floor(width / 2.0) + across, height - CTX_POPUP_LINE + 4.0);   // the action bar starts at the middle
    float age = mod(gameTime * 24000.0 - float(slot), float(CTX_POPUP_SLOTS));
    if (age >= CTX_POPUP_LIFE) {   // done, or not yet started
        position.xy = middle;
        color.a = 0.0;
        return true;
    }
    float u = min(age / CTX_POPUP_POP, 1.0) - 1.0;
    float size = CTX_POPUP_SMALL + (1.0 - CTX_POPUP_SMALL) * (1.0 + 2.70158 * u * u * u + 1.70158 * u * u);   // eased out, back
    float ahead = 1.0 - age / CTX_POPUP_LIFE;
    float rise = CTX_POPUP_RISE * (1.0 - ahead * ahead * ahead);
    float drop = float(CTX_POPUP_DROP + slot * CTX_POPUP_DROP_STEP % CTX_POPUP_DROPS);
    float left = position.x - (corner >= 2 ? 8.0 : 0.0) - (shadow ? 1.0 : 0.0);   // its letter's quad's, before it moves
    position.xy = middle + (position.xy - middle) * size + vec2(0.0, drop - rise);
    float fade = clamp((CTX_POPUP_LIFE - age) / CTX_POPUP_FADE, 0.0, 1.0);
    int fx = hue == 11 ? CTX_GOLDEN : hue == 12 ? CTX_DIAMOND : hue == 13 ? CTX_RAINBOW : -1;
    if (fx >= 0) {   // white letters the effect colours, and its own shadow; the letter index from where it is along the popup
        color = vec4(shadow ? ctx_shadow(fx) : vec3(1.0), color.a * fade);
        info = vec4(float(fx), (left - middle.x) / 6.0 + 32.0, shadow ? CTX_SHADOW : CTX_LETTER, gameTime * 24000.0);
        return true;
    }
    vec3 rgb = ctx_popup_hue(hue);
    if (shadow) rgb = floor(rgb * 255.0 / 4.0) / 255.0;   // as the game makes a drop shadow
    color = vec4(rgb, color.a * fade);
    return true;
}

// The card's palette (EventCard.PALETTE, EventCardTest checks they're the same): white, AAP-64 without it, the effects'
// middle colours, the strip's dark track and its slate between events, and the few colours off AAP-64 the game's text has
const int CTX_CARD_COLORS[CTX_CARD_HUES] = int[CTX_CARD_HUES](
    0xffffff, 0x060608, 0x141013, 0x3b1725, 0x73172d, 0xb4202a, 0xdf3e23, 0xfa6a0a,
    0xf9a31b, 0xffd541, 0xfffc40, 0xd6f264, 0x9cdb43, 0x59c135, 0x14a02e, 0x1a7a3e,
    0x24523b, 0x122020, 0x143464, 0x285cc4, 0x249fde, 0x20d6c7, 0xa6fcdb, 0xfef3c0,
    0xfad6b8, 0xf5a097, 0xe86a73, 0xbc4a9b, 0x793a80, 0x403353, 0x242234, 0x221c1a,
    0x322b28, 0x71413b, 0xbb7547, 0xdba463, 0xf4d29c, 0xdae0ea, 0xb3b9d1, 0x8b93af,
    0x6d758d, 0x4a5462, 0x333941, 0x422433, 0x5b3138, 0x8e5252, 0xba756a, 0xe9b5a3,
    0xe3e6ff, 0xb9bffb, 0x849be4, 0x588dbe, 0x477d85, 0x23674e, 0x328464, 0x5daf8d,
    0x92dcba, 0xcdf7e2, 0xe4d2aa, 0xc7b08b, 0xa08662, 0x796755, 0x5a4e44, 0x423934,
    0xfcd03c, 0x5ce0e4, 0xc080fc, 0x191b1f, 0x5a606a, 0x4a4f57, 0x777d85, 0xf2d6a2,
    0x3cb1f0, 0x55ffff, 0x55ff55, 0x8a3fc4
);

// A part of the card: (its glyphs' top below their line before they move, their height, their top on the card)
vec3 ctx_card_part(int part) {
    if (part == 0) return vec3(0.0, float(CTX_CARD_H), 0.0);   // the plaque's pieces, ascent 7
    if (part == 1) return vec3(0.0, float(CTX_CARD_ICON), float(CTX_CARD_ICON_Y));   // the icon, ascent 7
    if (part == 2) return vec3(0.0, 8.0, float(CTX_CARD_LABEL_Y));   // text: the default font's and the bold font's cells
    if (part == 3) return vec3(0.0, 8.0, float(CTX_CARD_NAME_Y));
    if (part == 4) return vec3(0.0, 8.0, float(CTX_CARD_TIME_Y));
    return vec3(float(CTX_CARD_ROW_DROP), 1.0, float(part - CTX_CARD_ROWS));   // a row, ascent 0
}

// Moves a glyph corner of the global event's card to the screen's top-left corner and colours it (see CTX_CARD_LETTER);
// false, touching nothing, for any other text. corner is ctx_vertex's; info comes back as ctx_vertex returns it, ordinary
// text but for Golden's, Diamond's and Rainbow's hues, which are their text effects, flowing along the card's text.
bool ctx_card(inout vec4 color, inout vec3 position, mat4 proj, float gameTime, int corner, out vec4 info) {
    info = vec4(-1.0, 0.0, 0.0, 0.0);
    if (proj[2][3] != 0.0) return false;   // GUI text only
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if (((c.r | c.g | c.b) & 3) != 0) return false;
    bool shadow = c.r == CTX_CARD_SHADOW || c.r == CTX_CARD_SHADOW + 4;
    if (!shadow && c.r != CTX_CARD_LETTER && c.r != CTX_CARD_LETTER + 4) return false;
    int part = c.g >> 2;
    if (part > 4 && (part < CTX_CARD_ROWS || part >= CTX_CARD_ROWS + CTX_CARD_H)) return false;
    int hue = ((c.r - (shadow ? CTX_CARD_SHADOW : CTX_CARD_LETTER)) >> 2) * 64 + (c.b >> 2);
    if (hue >= CTX_CARD_HUES) return false;
    vec3 p = ctx_card_part(part);
    // its quad's top: a glyph's quad is its cell, corners 1 and 2 at its bottom; a drop shadow's is a pixel down and right.
    // Judged by the quad's top, all its corners judge alike (as the popups' do).
    float top = position.y - (corner == 1 || corner == 2 ? p.y : 0.0) - (shadow ? 1.0 : 0.0);
    float line = top - p.x;
    float bar = round((line - CTX_CARD_LINE) / CTX_CARD_STEP);
    if (bar < 0.0 || abs(line - CTX_CARD_LINE - bar * CTX_CARD_STEP) > 0.5) return false;   // on a boss bar's line only
    float middle = floor(round(2.0 / abs(proj[0][0])) / 2.0);   // where the bar's name starts: it measures 0 wide
    float left = position.x - (corner >= 2 ? 8.0 : 0.0) - (shadow ? 1.0 : 0.0) - middle;   // its letter's, on the card
    position.x += CTX_CARD_X - middle;
    position.y += CTX_CARD_Y + p.z - top;
    if (part >= CTX_CARD_ROWS && (hue == CTX_CARD_RAINBOW || hue == CTX_CARD_RAINBOW_DEEP)) {   // the fragment stage colours it
        vec2 sv = hue == CTX_CARD_RAINBOW ? CTX_CARD_RAINBOW_LIGHT : CTX_CARD_RAINBOW_DEEP_SV;
        color = vec4(1.0, 1.0, 1.0, color.a);
        info = vec4(CTX_CARD_RAINBOWING, sv, gameTime * 24000.0);
        return true;
    }
    if (hue >= CTX_CARD_GOLDEN && hue <= CTX_CARD_RAINBOW) {   // white letters the effect colours, and its own shadow
        int fx = hue == CTX_CARD_GOLDEN ? CTX_GOLDEN : hue == CTX_CARD_DIAMOND ? CTX_DIAMOND : CTX_RAINBOW;
        color = vec4(shadow ? ctx_shadow(fx) : vec3(1.0), color.a);
        info = vec4(float(fx), left / 6.0, shadow ? CTX_SHADOW : CTX_LETTER, gameTime * 24000.0);
        return true;
    }
    vec3 rgb = ctx_hex(CTX_CARD_COLORS[hue]);
    if (shadow) rgb = floor(rgb * 255.0 / 4.0) / 255.0;   // as the game makes a drop shadow
    color = vec4(rgb, color.a);
    return true;
}

// Sets an effect letter's colour and moves it: the wobble, and a glow pass's shadow quad moved back under its letter
// and grown. position is the vertex position the shader projects (and passes on to the fragment stage); vertexId is
// CTX_VERTEX_ID. local comes back as this corner of the glyph quad (xy:
// 0..1, y down) and how the quad was grown, in position units: z on every side, w back up and left (ctx_frag needs both
// to find the glyph in it). Returns (effect, index, kind, ticks) for ctx_project and ctx_fragment, kind CTX_LETTER,
// CTX_SHADOW, CTX_SHADOW_PLAIN, CTX_GLOW_QUAD or CTX_HIDDEN, effect -1 for ordinary text (left as it is).
vec4 ctx_vertex(inout vec4 color, inout vec3 position, mat4 modelView, mat4 proj, float gameTime, int vertexId, out vec4 local) {
    int corner = vertexId & 3;   // the game writes a glyph quad top left, bottom left, bottom right, top right
    vec2 lp = vec2(corner >= 2 ? 1.0 : 0.0, corner == 1 || corner == 2 ? 1.0 : 0.0);
    local = vec4(lp, 0.0, 0.0);
    vec4 popup;
    if (ctx_popup(color, position, proj, gameTime, corner, popup)) return popup;
    if (ctx_card(color, position, proj, gameTime, corner, popup)) return popup;
    if (ivec3(round(color.rgb * 255.0)) == CTX_BIG_HEAD) {
        ctx_move(position, (lp * 2.0 - 1.0) * CTX_BIG_HEAD_GROW, modelView, proj);
        color = vec4(1.0, 1.0, 1.0, color.a);
        return vec4(-1.0, 0.0, 0.0, 0.0);
    }
    ivec3 rgb = ivec3(round(color.rgb * 255.0));
    if (rgb == CTX_TRAIL) {
        color = vec4(ctx_hex(0xffd541), color.a);   // the yellow of the arrow over things (TutorialArt)
        return vec4(CTX_TRAILING, 0.0, 0.0, gameTime * 24000.0);
    }
    if (rgb == CTX_FLUTTER || rgb == CTX_FLUTTER_SHADOW) {
        bool shade = rgb == CTX_FLUTTER_SHADOW;
        color = vec4(vec3(shade ? 63.0 / 255.0 : 1.0), color.a);   // as white text and its shadow
        return vec4(CTX_FLUTTERING, 0.0, shade ? CTX_SHADOW : CTX_LETTER, gameTime * 24000.0);
    }
    ivec3 info = ctx_decode(color);
    if (info.x < 0) return vec4(-1.0, 0.0, 0.0, 0.0);
    int fx = info.x;
    float k = float(info.y);
    bool shadow = (info.z & 1) != 0;
    bool pass = (info.z & 2) != 0;
    float t = gameTime * 24000.0;
    bool gui = proj[2][3] == 0.0;
    float unit = gui ? 1.0 : CTX_PX_WORLD;

    vec2 d = vec2(0.0);
    float wobble = ctx_wobble(fx);
    if (wobble > 0.0) d.y += sin(t * wobble - k * 0.5) * CTX_WOBBLE;
#ifdef CTX_GLOW_IN_ITEMS
    bool glowHere = gui;
#else
    bool glowHere = true;
#endif
    vec4 c = vec4(1.0);   // a glow and its dark shadow are coloured per pixel (ctx_effect)
    float kind = CTX_LETTER;
    if (pass) {
        kind = CTX_HIDDEN;
        if (shadow && ctx_glows(fx) && glowHere) {
            kind = CTX_GLOW_QUAD;
            d += (lp * 2.0 - 1.0) * CTX_ROOM - CTX_PULL;   // back towards its letter, grown on every side
            local.zw = vec2(CTX_ROOM, CTX_PULL) * unit;
        }
    } else if (shadow && ctx_glows(fx)) {
        kind = CTX_SHADOW_PLAIN;
    } else if (shadow) {
        kind = CTX_SHADOW;
        c = vec4(ctx_shadow(fx), 1.0);
    }
    ctx_move(position, d, modelView, proj);
    color = vec4(c.rgb, c.a * color.a);
    return vec4(float(fx), k, kind, t);
}

// The clip position for a vertex at position (after ctx_vertex): clip is the one the shader computed. A glow in the
// world is drawn on a glow pass letter's drop-shadow quad, and the glows round a label overlap: the next letter's, and
// a bold letter's second copy a pixel over. That close together, their depths would fight over every pixel (vanilla
// shadows get away with it by being one flat colour). So every glow vertex of a label goes to exactly the same depth, a
// bit behind the label: the glows then blend over each other, all behind the letters and their shadows. The depth comes
// from the model-view matrix, which has the camera's turn but not the view bobbing, so it's the same all over a label
// facing the camera; rounded to CTX_DEPTH_STEP so every vertex gets the very same number, and with w 1 so nothing
// changes it on the way (over a quad facing the camera, w was the same at every corner anyway).
vec4 ctx_project(vec4 clip, inout vec4 info, vec3 position, mat4 modelView, mat4 proj) {
    if (info.z != CTX_GLOW_QUAD || proj[2][3] == 0.0 || clip.w < 0.1) return clip;
    float w = -(modelView * vec4(position, 1.0)).z;   // how far in front of the camera
    if (w < 0.1) return clip;
    float behind = (ceil(w * 1.01 / CTX_DEPTH_STEP) + 1.0) * CTX_DEPTH_STEP;   // 1 % for the bobbing's tilt
    vec4 back = proj * vec4(0.0, 0.0, -behind, 1.0);
    return vec4(clip.xy / clip.w, back.z / back.w, 1.0);
}

// Drops a text pixel below this alpha: vanilla's 0.1, but effects keep their soft edges (a glow fades out to nothing), as
// do the floor arrow's chevrons
float ctx_cutoff(vec4 info) {
    return info.x < 0.0 && info.x > CTX_TRAILING + 0.5 ? 0.1 : 0.01;
}

// A plot's Chickin Surfers screen's text (surfers.Stage: this light, as nothing else has) stands right on its picture, whose pieces
// the depth test sees up to several blocks nearer than they are (chickins_surfers.glsl), so it's brought nearer by more, along the
// line the viewer looks along, without moving. What to add to its clip position's z: see ctx_screen_depth.
#define CTX_SCREEN_TEXT_NEAR 3.5
float ctx_screen_text_depth(ivec2 light, vec3 position, mat4 projection) {
    return light == ivec2(240, 224) ? projection[3][2] * CTX_SCREEN_TEXT_NEAR / max(length(position), 1.0) : 0.0;
}

#endif

#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chickins_lucky.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out vec4 ctxLucky;
out vec2 ctxLuckyUv;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    ctxLucky = ctx_lucky_info(Color, GameTime);
    ctxLuckyUv = ctx_lucky_corner(CTX_VERTEX_ID);
    vec4 tint = ctxLucky.x >= 0.0 ? vec4(1.0) : Color;   // a Lucky Block's tint only says which one it is
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, tint) * sample_lightmap(Sampler2, UV2);

    texCoord0 = UV0;
}

#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:chickins_lucky.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 ctxLucky;
in vec2 ctxLuckyUv;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif
    if (ctxLucky.x >= 0.0) {
        color = ctx_lucky_color(ctxLucky, ctxLuckyUv, texCoord0, Sampler0);   // like a text effect (chickins_lucky.glsl)
    }

    if (ctx_opening_glow(ctxLucky, color)) {
        color = vec4(ctxLucky.yzw, color.a) * ColorModulator;   // an opening's glow: its tint, unlit (chickins_lucky.glsl)
    } else {
        color *= vertexColor * ColorModulator;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}

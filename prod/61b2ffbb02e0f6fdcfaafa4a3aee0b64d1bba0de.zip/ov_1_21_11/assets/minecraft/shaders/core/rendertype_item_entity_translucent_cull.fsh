#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chickins_text.glsl>
#moj_import <minecraft:chickins_glow_item.glsl>
#moj_import <minecraft:chickins_lucky.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
flat in float ctxGlow;
in vec4 ctxLight;
flat in vec4 ctxLucky;
in vec2 ctxLuckyUv;

out vec4 fragColor;

void main() {
    vec4 color;
    if (ctxGlow >= 0.0) {
        // a text effect's glow, drawn here so it comes after the text and with the other items (chickins_glow_item.glsl)
        color = ctx_item_glow(int(ctxGlow + 0.5), texCoord0, Sampler0, GameTime * 24000.0);
        color.rgb *= ctxLight.rgb;
        if (color.a < 0.01) {
            discard;
        }
    } else {
        // a Lucky Block's colours, worked out for every pixel like a text effect (chickins_lucky.glsl)
        vec4 texel = ctxLucky.x >= 0.0 ? ctx_lucky_color(ctxLucky, ctxLuckyUv, texCoord0, Sampler0) : texture(Sampler0, texCoord0);
        // an opening's glow is its tint, unlit (chickins_lucky.glsl), and fades out further than the game's 0.1
        bool opening = ctx_opening_glow(ctxLucky, texel);
        color = (opening ? vec4(ctxLucky.yzw, texel.a) : texel * vertexColor) * ColorModulator;
        if (color.a < (opening ? 0.02 : 0.1)) {
            discard;
        }
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}

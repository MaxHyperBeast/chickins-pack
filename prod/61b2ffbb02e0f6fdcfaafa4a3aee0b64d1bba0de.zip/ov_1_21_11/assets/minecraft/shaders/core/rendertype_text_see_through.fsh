#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:chickins_text.glsl>
#moj_import <minecraft:chickins_text_frag.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 ctxInfo;
in vec4 ctxLocal;
in vec3 ctxPos;

out vec4 fragColor;

void main() {
    vec4 color = ctx_fragment(vertexColor, texture(Sampler0, texCoord0), ctxInfo, texCoord0, ctxLocal, ctxPos, Sampler0);
    if (color.a < ctx_cutoff(ctxInfo)) {
        discard;
    }
    fragColor = color * ColorModulator;
}

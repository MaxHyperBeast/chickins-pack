#ifndef CHICKINS_TEXT_GLSL
#define CHICKINS_TEXT_GLSL

// Text effects: ordinary text (labels, titles, the action bar, item names, chat) that the pack animates. The server's
// <fx:name> MiniMessage tag (lol.chickins.text.TextFx) colours every letter #F4GGBB:
//   G = 128 + 4 * effect   effect: CTX_* below
//   B = 128 + 4 * index    index: letter number along the text, spaces skipped, mod 32
// Everything is a multiple of 4 so the vanilla drop shadow (colour * 0.25, rounded down) still decodes: a shadow
// vertex is #3D (32 + effect) (32 + index). Without the pack the letters show in that pinkish red.
// The effects were designed on the preview page (the text effects artifact) and match it; the wobblers move their
// letters. A glowing effect's text comes twice (TextFx.prepare): first its glow pass, the same letters coloured #F8GGBB
// (shadow #3E…), then a negative space back and the letters themselves. The glow pass draws only the glow, on its
// drop-shadow copy, moved back under its letter and grown; the letters keep a plain dark drop shadow. So every glow is
// drawn before any letter: on screen the game draws text in order with no depth, a glyph's shadow, then its letter,
// then the next glyph, and a glow drawn with its own letter would cover the letter before it. A bold effect letter comes
// in the pack's bold font (chickins:bold, one glyph already drawn bold) instead: the game draws a bold letter twice, a
// pixel apart, and each copy's colours, from its own position, jumped back a pixel where the second covered the first.
// Fragment shaders also include chickins_text_frag.glsl.
//
// The vertex stage moves and grows quads in units: a GUI pixel on screen, CTX_PX_WORLD blocks in the world (a font
// pixel of a Lucky Block label at scale 0.9). The fragment stage measures the glyph's real size from its quad, so text
// of any size (a 4× title, a label at another scale) still lines up; only the wobble's reach is in units, and the room
// round a glow fits glyph pixels up to CTX_PULL units big (a label up to scale 3.6).

#define CTX_GOLDEN 0
#define CTX_DIAMOND 1
#define CTX_COMMON 2
#define CTX_UNCOMMON 3
#define CTX_RARE 4
#define CTX_SUPER_RARE 5
#define CTX_EPIC 6
#define CTX_LEGENDARY 7
#define CTX_MYTHIC 8
#define CTX_EXOTIC 9
#define CTX_DIVINE 10
#define CTX_CELESTIAL 11
#define CTX_RADIANT 12
#define CTX_ASTRAL 13
#define CTX_ETERNAL 14
#define CTX_ECLIPSE 15
#define CTX_GODLY 16
#define CTX_EFFECTS 17          // how many there are (one more than the last): ctx_decode reads no others

#define CTX_PI 3.14159265
#define CTX_GLOW 4.0            // glyph pixels a glow reaches round its letter (where its blur has faded out)
#define CTX_GLOW_BLUR 1.2       // glyph pixels: how soft a glow is, the spread of the blur of its letters' shapes
#define CTX_GLOW_GAIN 6.0       // how brightly the blurred shape lights the glow (ctx_glow_strength)
#define CTX_WOBBLE 1.2          // units a wobbling letter moves up and down
#define CTX_PULL 4.0            // units a glow's quad moves back up and left (the biggest glyph pixel it fits)...
#define CTX_ROOM 16.0           // ...and grows on every side: 4 glyph pixels round the letter at that size
#define CTX_PX_WORLD 0.0225     // world text: blocks per unit (a Lucky Block label's font pixel, scale 0.9 × 1/40)
#define CTX_DEPTH_STEP 0.03125  // blocks: world glows sit on depths in steps of this (ctx_project)

// ctx_vertex's kinds of quad (info.z)
#define CTX_LETTER 0.0
#define CTX_SHADOW 1.0         // the drop shadow of an effect without a glow
#define CTX_SHADOW_PLAIN 2.0   // a glowing effect's dark drop shadow (its glow is the glow pass's)
#define CTX_GLOW_QUAD 3.0      // a glow pass's drop-shadow quad, grown: the glow
#define CTX_HIDDEN 4.0         // a glow pass's letter, which draws nothing (nor its shadow where items draw the glow)

// CTX_GLOW_IN_ITEMS (defined by 1.21.11's text shaders): world labels' glows aren't drawn with the text. 1.21.11 draws
// all text before any item display, and a glow, see-through but writing depth like all text, would cut holes in every
// item behind it. An item display just behind the label draws it instead (chickins_glow_item.glsl), sorted with the
// other items, and the glow pass draws nothing.

#ifdef VULKAN
#define CTX_VERTEX_ID gl_VertexIndex
#else
#define CTX_VERTEX_ID gl_VertexID
#endif

// (effect, letter index, flags: 1 the drop shadow, 2 the glow pass), or effect -1 for ordinary text
ivec3 ctx_decode(vec4 color) {
    // only the effects there are (below CTX_EFFECTS): text that fades through greys (subtitles) passes #F4F4F4 and
    // #F8F8F8, and their shadows #3D3D3D and #3E3E3E, which would read as effect 29 otherwise
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if ((c.r == 244 || c.r == 248) && c.g >= 128 && c.g < 128 + 4 * CTX_EFFECTS && c.b >= 128
            && (c.g & 3) == 0 && (c.b & 3) == 0) {
        return ivec3((c.g - 128) >> 2, (c.b - 128) >> 2, c.r == 248 ? 2 : 0);
    }
    if ((c.r == 61 || c.r == 62) && c.g >= 32 && c.g < 32 + CTX_EFFECTS && c.b >= 32 && c.b < 64) {
        return ivec3(c.g - 32, c.b - 32, c.r == 62 ? 3 : 1);
    }
    return ivec3(-1, 0, 0);
}

vec3 ctx_hex(int c) {
    return vec3(float((c >> 16) & 255), float((c >> 8) & 255), float(c & 255)) / 255.0;
}

vec3 ctx_hsv(float h, float s, float v) {
    vec3 k = clamp(abs(fract(h + vec3(0.0, 2.0, 1.0) / 3.0) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

// Godly's rainbow: the hue at text column x, flowing right
float ctx_godly_hue(float x, float t) {
    return fract(x * 0.022 - t * 0.012);
}

bool ctx_glows(int fx) {
    return fx >= CTX_DIVINE;
}

// The wobblers (Radiant and up) move like Godly's wave, faster the rarer: radians per tick, 0 for none
float ctx_wobble(int fx) {
    if (fx == CTX_RADIANT) return 0.08;
    if (fx == CTX_ASTRAL) return 0.10;
    if (fx == CTX_ETERNAL) return 0.12;
    if (fx == CTX_ECLIPSE) return 0.14;
    if (fx == CTX_GODLY) return 0.16;
    return 0.0;
}

// The drop shadow's colour for the effects without a glow
vec3 ctx_shadow(int fx) {
    if (fx == CTX_GOLDEN) return ctx_hex(0x3f340f);
    if (fx == CTX_DIAMOND) return ctx_hex(0x173839);
    if (fx == CTX_COMMON) return ctx_hex(0x2b2f32);
    if (fx == CTX_UNCOMMON) return ctx_hex(0x1b360f);
    if (fx == CTX_RARE) return ctx_hex(0x0a2638);
    if (fx == CTX_SUPER_RARE) return ctx_hex(0x131b3c);
    if (fx == CTX_EPIC) return ctx_hex(0x2a153a);
    if (fx == CTX_LEGENDARY) return ctx_hex(0x3c280f);
    if (fx == CTX_MYTHIC) return ctx_hex(0x3a1212);
    if (fx == CTX_EXOTIC) return ctx_hex(0x3f1737);
    return vec3(0.25);
}

// The darker drop shadow kept inside each glow, so pale names stay readable against the sky; Godly's follows its rainbow
// at text column x
vec3 ctx_glow_dark(int fx, float x, float t) {
    if (fx == CTX_DIVINE) return ctx_hex(0x143439);
    if (fx == CTX_CELESTIAL) return ctx_hex(0x363650);
    if (fx == CTX_RADIANT) return ctx_hex(0x3d310f);
    if (fx == CTX_ASTRAL) return ctx_hex(0x120a30);
    if (fx == CTX_ETERNAL) return ctx_hex(0x083125);
    if (fx == CTX_ECLIPSE) return ctx_hex(0x140b1f);
    return ctx_hsv(ctx_godly_hue(x, t), 0.8, 0.28);   // Godly
}

// A glow's colour and strength at text column x and row y, the letters' own positions (CtxFrag's X and y), so it flows
// along the text as smoothly as they do; the fragment shader fades it out towards its edge
vec4 ctx_glow(int fx, float x, float y, float t) {
    float breath = sin(t * 0.05 - x * (0.4 / 6.0));
    if (fx == CTX_DIVINE) return vec4(ctx_hex(0x52cfe3), 0.24 + 0.12 * breath);
    if (fx == CTX_CELESTIAL) return vec4(ctx_hex(0xaab6dc), 0.26 + 0.12 * breath);
    if (fx == CTX_RADIANT) return vec4(ctx_hex(0xf2c43c), 0.26 + 0.12 * breath);
    if (fx == CTX_ASTRAL) return vec4(ctx_hex(0x7a5cff), 0.4);
    if (fx == CTX_ETERNAL) return vec4(ctx_hex(0x22c495), 0.22 + 0.16 * (0.5 + 0.5 * sin(t * 0.15 - x * (0.8 / 6.0))));
    if (fx == CTX_ECLIPSE) return vec4(ctx_hex(0xcdb8ff), 0.4 + 0.14 * breath);   // a pale lavender corona
    return vec4(ctx_hsv(ctx_godly_hue(x + y * 0.8, t), 0.7, 1.0), 0.38 + 0.14 * sin(t * 0.1));   // Godly, as its letters
}

// How much of a blur round p (glyph pixels) falls on the pixel square from lo to lo + 1: a Gaussian's, in the
// logistic approximation. A glow is the sum of this over its letters' pixels, their shapes blurred, which is smooth
// everywhere; a glow from the distance to the nearest pixel creased wherever that pixel changed (between letters, in
// their corners), and the creases showed as outlines.
float ctx_cover1(float lo, float p) {
    float k = 1.702 / CTX_GLOW_BLUR;
    return 1.0 / (1.0 + exp(k * (p - lo - 1.0))) - 1.0 / (1.0 + exp(k * (p - lo)));
}

float ctx_cover(vec2 lo, vec2 p) {
    return ctx_cover1(lo.x, p.x) * ctx_cover1(lo.y, p.y);
}

// A glow's strength (0 to 1, times ctx_glow's) from its letters' blurred shape (the sum of ctx_cover)
float ctx_glow_strength(float cover) {
    return 1.0 - exp(-CTX_GLOW_GAIN * cover);
}

// Moves a glyph corner by d units, x along the text and y down. GUI text is in GUI pixels; world text (labels that face
// the camera) moves along the camera's right and up. Those come from the whole view and projection, not the model-view
// matrix alone: depending on the release, the camera's turn is in the model-view matrix or already in the positions,
// and only the combination is right in both.
void ctx_move(inout vec3 position, vec2 d, mat4 modelView, mat4 proj) {
    if (proj[2][3] == 0.0) {
        position.xy += d;
        return;
    }
    mat4 m = proj * modelView;
    vec3 right = normalize(vec3(m[0][0], m[1][0], m[2][0]));
    vec3 up = normalize(vec3(m[0][1], m[1][1], m[2][1]));
    position += (right * d.x - up * d.y) * CTX_PX_WORLD;
}

// Sets an effect letter's colour and moves it: the wobble, and a glow pass's shadow quad moved back under its letter
// and grown. position is the vertex position the shader projects (and passes on to the fragment stage); vertexId is
// CTX_VERTEX_ID. local comes back as this corner of the glyph quad (xy:
// 0..1, y down) and how the quad was grown, in position units: z on every side, w back up and left (ctx_frag needs both
// to find the glyph in it). Returns (effect, index, kind, ticks) for ctx_project and ctx_fragment, kind CTX_LETTER,
// CTX_SHADOW, CTX_SHADOW_PLAIN, CTX_GLOW_QUAD or CTX_HIDDEN, effect -1 for ordinary text (left as it is).
vec4 ctx_vertex(inout vec4 color, inout vec3 position, mat4 modelView, mat4 proj, float gameTime, int vertexId, out vec4 local) {
    int corner = vertexId & 3;   // the game writes a glyph quad top left, bottom left, bottom right, top right
    vec2 lp = vec2(corner >= 2 ? 1.0 : 0.0, corner == 1 || corner == 2 ? 1.0 : 0.0);
    local = vec4(lp, 0.0, 0.0);
    ivec3 info = ctx_decode(color);
    if (info.x < 0) return vec4(-1.0, 0.0, 0.0, 0.0);
    int fx = info.x;
    float k = float(info.y);
    bool shadow = (info.z & 1) != 0;
    bool pass = (info.z & 2) != 0;
    float t = gameTime * 24000.0;
    bool gui = proj[2][3] == 0.0;
    float unit = gui ? 1.0 : CTX_PX_WORLD;

    vec2 d = vec2(0.0);
    float wobble = ctx_wobble(fx);
    if (wobble > 0.0) d.y += sin(t * wobble - k * 0.5) * CTX_WOBBLE;
#ifdef CTX_GLOW_IN_ITEMS
    bool glowHere = gui;
#else
    bool glowHere = true;
#endif
    vec4 c = vec4(1.0);   // a glow and its dark shadow are coloured per pixel (ctx_effect)
    float kind = CTX_LETTER;
    if (pass) {
        kind = CTX_HIDDEN;
        if (shadow && ctx_glows(fx) && glowHere) {
            kind = CTX_GLOW_QUAD;
            d += (lp * 2.0 - 1.0) * CTX_ROOM - CTX_PULL;   // back towards its letter, grown on every side
            local.zw = vec2(CTX_ROOM, CTX_PULL) * unit;
        }
    } else if (shadow && ctx_glows(fx)) {
        kind = CTX_SHADOW_PLAIN;
    } else if (shadow) {
        kind = CTX_SHADOW;
        c = vec4(ctx_shadow(fx), 1.0);
    }
    ctx_move(position, d, modelView, proj);
    color = vec4(c.rgb, c.a * color.a);
    return vec4(float(fx), k, kind, t);
}

// The clip position for a vertex at position (after ctx_vertex): clip is the one the shader computed. A glow in the
// world is drawn on a glow pass letter's drop-shadow quad, and the glows round a label overlap: the next letter's, and
// a bold letter's second copy a pixel over. That close together, their depths would fight over every pixel (vanilla
// shadows get away with it by being one flat colour). So every glow vertex of a label goes to exactly the same depth, a
// bit behind the label: the glows then blend over each other, all behind the letters and their shadows. The depth comes
// from the model-view matrix, which has the camera's turn but not the view bobbing, so it's the same all over a label
// facing the camera; rounded to CTX_DEPTH_STEP so every vertex gets the very same number, and with w 1 so nothing
// changes it on the way (over a quad facing the camera, w was the same at every corner anyway).
vec4 ctx_project(vec4 clip, inout vec4 info, vec3 position, mat4 modelView, mat4 proj) {
    if (info.z != CTX_GLOW_QUAD || proj[2][3] == 0.0 || clip.w < 0.1) return clip;
    float w = -(modelView * vec4(position, 1.0)).z;   // how far in front of the camera
    if (w < 0.1) return clip;
    float behind = (ceil(w * 1.01 / CTX_DEPTH_STEP) + 1.0) * CTX_DEPTH_STEP;   // 1 % for the bobbing's tilt
    vec4 back = proj * vec4(0.0, 0.0, -behind, 1.0);
    return vec4(clip.xy / clip.w, back.z / back.w, 1.0);
}

// Drops a text pixel below this alpha: vanilla's 0.1, but effects keep their soft edges (a glow fades out to nothing)
float ctx_cutoff(vec4 info) {
    return info.x < 0.0 ? 0.1 : 0.01;
}

#endif

#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#define CTX_GLOW_IN_ITEMS
#moj_import <minecraft:chickins_text.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out vec4 ctxInfo;
out vec4 ctxLocal;
out vec3 ctxPos;

void main() {
    vec3 position = Position;
    vec4 color = Color;
    ctxInfo = ctx_vertex(color, position, ModelViewMat, ProjMat, GameTime, CTX_VERTEX_ID, ctxLocal);
    gl_Position = ctx_project(ProjMat * ModelViewMat * vec4(position, 1.0), ctxInfo, position, ModelViewMat, ProjMat);
    ctxPos = position;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}

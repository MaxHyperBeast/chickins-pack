#ifndef CHICKINS_SURFERS_GLSL
#define CHICKINS_SURFERS_GLSL

// Chickin Surfers, in each release's item shader. Three things only a vertex stage can do, on the client's own clock, at
// its own frame rate, with nothing sent:
//   - A plot's screen, in true perspective. The server places the very scene a player runs through (surfers.Stage) at the
//     screen's middle, going straight off behind the wall, and each vertex is projected onto the window's plane through a
//     camera where the player's starts. It's a projective map, so a long train's side narrows as it should and textures
//     stay right (the position goes on with its w), and a piece at a steady speed speeds up towards the viewer by itself.
//     The picture is flat in that plane, from any side; only the depth test sees near pieces as nearer (ctx_screen_depth).
//     When the player's camera moves, the whole scene moves the other way (Stage.follow: every display rides one entity).
//   - The runners' animation: every face says which part it is, and its corners move by the game's clock. A limb is sheared,
//     its top staying put and its foot swinging: a face's corners come in the order of its uv, (min, min), (min, max),
//     (max, max), (max, min), so corners 1 and 2 of a side are its bottom.
//   - The start's camera, swinging round from in front of the chicken to behind it, on the same clock: the scene turns
//     about the chicken instead, for a player and on a screen alike, so what's on a screen is what they see.
//
// The item's tint says all that: without this shader it's only an odd colour, on a piece nobody should see without it.
//   red   232 + (screen ? 1 : 0) + (start's camera ? 2 : 0) + (part >= 16 ? 4 : 0)
//   green (part & 15) << 4 | plot
//   blue  gait << 6 | the tick the start began / 8 % 64
// Vertex stage: if ctx_surfers_piece(Color), ctx_surfers_vertex gives the position to draw and what goes with it. A player's
// own view (ctx_surfers_own) then goes through ctx_surfers_own_view instead of ModelViewMat.
// Fragment stage: if ctx_screen_clipped(ctxScreen), discard. Every loop divides 24000 ticks, where the game's clock starts again.

#define CTX_SURFERS_MARK 232
#define CTX_TAU 6.2831853

// Which part a face is (Stage.Part, the generator's SurfersArt.Part): keep the three the same
#define CTX_PART_STILL 0
#define CTX_PART_UNLIT 1
#define CTX_PART_CHICKEN_BODY 2
#define CTX_PART_CHICKEN_HEAD 3
#define CTX_PART_CHICKEN_LEG_A 4
#define CTX_PART_CHICKEN_LEG_B 5
#define CTX_PART_CHICKEN_FOOT_A 6
#define CTX_PART_CHICKEN_FOOT_B 7
#define CTX_PART_CHICKEN_WING_E 8
#define CTX_PART_CHICKEN_WING_W 9
#define CTX_PART_CHICKEN_TAIL 10
#define CTX_PART_RUNNER_BODY 11
#define CTX_PART_RUNNER_LEG_A 12
#define CTX_PART_RUNNER_LEG_B 13
#define CTX_PART_RUNNER_ARM_A 14
#define CTX_PART_RUNNER_ARM_B 15
#define CTX_PART_WOLF_BODY 16
#define CTX_PART_WOLF_HEAD 17
#define CTX_PART_WOLF_LEG_A 18
#define CTX_PART_WOLF_LEG_B 19
#define CTX_PART_WOLF_TAIL 20
#define CTX_PART_FLOATING 21
#define CTX_PART_FLAME 22
#define CTX_PART_RIDE_BODY 23
#define CTX_PART_RIDE_HEAD 24
#define CTX_PART_RIDE_WING_E 25
#define CTX_PART_RIDE_WING_W 26
#define CTX_PART_RIDE_BOARD 27
#define CTX_PART_RIDE_LEGS 28
#define CTX_PART_RIDE_THRUST 29

#define CTX_SCREEN_HALF_WIDTH 2.0
#define CTX_SCREEN_HALF_HEIGHT 3.0
// Half the window's height / tan(half of a 75 degree view): Scene.SCREEN_FOV
#define CTX_SCREEN_FOCAL 3.90965
#define CTX_CAMERA_HEIGHT 5.0
#define CTX_CAMERA_BACK 7.5
// sin and cos of the camera's 17 degrees down
#define CTX_CAMERA_SIN 0.292372
#define CTX_CAMERA_COS 0.956305
// To the depth test, a piece stands this many blocks out of the picture / how far it is from the picture's camera: all of
// them in front of the wall, near ones over far ones
#define CTX_SCREEN_RELIEF 0.3
// Nearer to the camera than this isn't drawn
#define CTX_SCREEN_NEAR 1.0

// The start's camera (StartShow): in ticks from the start, when it swings and when it's before the start
#define CTX_ORBIT_FROM 38.0
#define CTX_ORBIT_TO 70.0
#define CTX_ORBIT_BEFORE 448.0
#define CTX_ORBIT_LOOP 512.0
// How much nearer and lower it starts than it ends
#define CTX_ORBIT_UP 2.0
#define CTX_ORBIT_IN 2.6

bool ctx_surfers_piece(vec4 color) {
    int red = int(round(color.r * 255.0));
    return red >= CTX_SURFERS_MARK && red < CTX_SURFERS_MARK + 8;
}

int ctx_surfers_part(vec4 color) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    return (c.g >> 4) | (((c.r - CTX_SURFERS_MARK) >> 2) << 4);
}

// A piece in a player's own view, rather than on a screen
bool ctx_surfers_own(vec4 color) {
    return ctx_surfers_piece(color) && (int(round(color.r * 255.0)) & 1) == 0;
}

// Where the game's camera sees it, whichever way the client's camera looks: an F5 that looks back turns ModelViewMat round,
// and this keeps the view as it is. It's what ModelViewMat is with the camera looking north and down by the game's pitch.
vec4 ctx_surfers_own_view(vec4 at) {
    return vec4(at.x, at.y * CTX_CAMERA_COS - at.z * CTX_CAMERA_SIN, at.y * CTX_CAMERA_SIN + at.z * CTX_CAMERA_COS, at.w);
}

bool ctx_surfers_unlit(vec4 color) {
    if (!ctx_surfers_piece(color)) {
        return false;
    }
    int part = ctx_surfers_part(color);
    return part == CTX_PART_UNLIT || part == CTX_PART_RIDE_THRUST;
}

// The window's middle of plot's screen, in world coordinates (plots clockwise from the north side's west end)
vec3 ctx_screen_at(int plot) {
    int i = plot % 3;
    float along = float(i) * 44.0;
    int side = plot / 3;
    if (side == 0) return vec3(-59.96875 + along, 44.0, -76.0);
    if (side == 1) return vec3(77.0, 44.0, -59.96875 + along);
    if (side == 2) return vec3(60.96875 - along, 44.0, 77.0);
    return vec3(-76.0, 44.0, 60.96875 - along);
}

// Which way it looks out of the wall: the plot's +u
vec3 ctx_screen_out(int plot) {
    int side = plot / 3;
    if (side == 0) return vec3(1.0, 0.0, 0.0);
    if (side == 1) return vec3(0.0, 0.0, 1.0);
    if (side == 2) return vec3(-1.0, 0.0, 0.0);
    return vec3(0.0, 0.0, -1.0);
}

// Its right, as you look at it: the plot's +v
vec3 ctx_screen_right(int plot) {
    int side = plot / 3;
    if (side == 0) return vec3(0.0, 0.0, -1.0);
    if (side == 1) return vec3(1.0, 0.0, 0.0);
    if (side == 2) return vec3(0.0, 0.0, 1.0);
    return vec3(-1.0, 0.0, 0.0);
}

// How far a part's vertex moves, in blocks of the scene (x right, y up, z towards the camera, the chicken at z 0): a run's gait
// is 0 for still, or how quick its steps are. low is 1 for what's at the bottom of a limb, 0 at its top.
vec3 ctx_surfers_motion(int part, int gait, int vertexId, float normalY, float tick, vec3 scene) {
    if (part == CTX_PART_STILL || part == CTX_PART_UNLIT) {
        return vec3(0.0);
    }
    int corner = vertexId & 3;
    float low = normalY < -0.5 ? 1.0 : normalY > 0.5 ? 0.0 : (corner == 1 || corner == 2) ? 1.0 : 0.0;
    if (part >= CTX_PART_RIDE_BODY) {
        // On a hoverboard: it all floats together, the board rocks under the chicken, its wings balance and the thrust flickers.
        float hover = 0.07 * sin(fract(tick / 30.0) * CTX_TAU);
        float rock = sin(fract(tick / 24.0) * CTX_TAU);
        float flap = sin(fract(tick / 8.0) * CTX_TAU);
        if (part == CTX_PART_RIDE_BOARD) return vec3(0.0, hover + 0.06 * rock * scene.z, 0.0);
        if (part == CTX_PART_RIDE_LEGS) return vec3(0.0, hover, 0.0);
        if (part == CTX_PART_RIDE_BODY) return vec3(0.0, hover + 0.02 * rock, 0.0);
        if (part == CTX_PART_RIDE_HEAD) return vec3(0.0, hover + 0.03 * rock, -0.03 * rock);
        if (part == CTX_PART_RIDE_WING_E) return vec3(0.08 * low * (1.0 + flap), hover + 0.07 * low * flap, 0.0);
        if (part == CTX_PART_RIDE_WING_W) return vec3(-0.08 * low * (1.0 + flap), hover + 0.07 * low * flap, 0.0);
        return vec3(0.0, hover, max(0.0, scene.z - 0.75) * (0.5 + 0.5 * sin(fract(tick / 3.0) * CTX_TAU)));
    }
    if (part == CTX_PART_FLOATING) {
        return vec3(0.0, 0.12 * sin(fract(tick / 40.0) * CTX_TAU), 0.0);
    }
    if (part == CTX_PART_FLAME) {
        return vec3(0.0, -0.1 * low * (0.5 + 0.5 * sin(fract(tick / 3.0) * CTX_TAU)), 0.0);
    }
    if (gait == 0) {
        return vec3(0.0);
    }
    float period = gait == 1 ? 8.0 : gait == 2 ? 6.0 : 5.0;
    float phase = fract(tick / period) * CTX_TAU;
    float step = sin(phase);
    float lift = cos(phase);
    float bob = abs(sin(phase));

    if (part == CTX_PART_CHICKEN_BODY) return vec3(0.0, 0.05 * bob, 0.0);
    if (part == CTX_PART_CHICKEN_HEAD) return vec3(0.0, 0.07 * bob, -0.07 * sin(2.0 * phase));
    if (part == CTX_PART_CHICKEN_LEG_A) return vec3(0.0, 0.0, 0.2 * step * low);
    if (part == CTX_PART_CHICKEN_LEG_B) return vec3(0.0, 0.0, -0.2 * step * low);
    if (part == CTX_PART_CHICKEN_FOOT_A) return vec3(0.0, 0.08 * max(0.0, lift), 0.2 * step);
    if (part == CTX_PART_CHICKEN_FOOT_B) return vec3(0.0, 0.08 * max(0.0, -lift), -0.2 * step);
    if (part == CTX_PART_CHICKEN_WING_E) return vec3(0.1 * bob * low, 0.05 * bob, 0.0);
    if (part == CTX_PART_CHICKEN_WING_W) return vec3(-0.1 * bob * low, 0.05 * bob, 0.0);
    if (part == CTX_PART_CHICKEN_TAIL) return vec3(0.05 * step, 0.05 * bob, 0.0);
    if (part == CTX_PART_RUNNER_BODY) return vec3(0.0, 0.06 * bob, 0.0);
    if (part == CTX_PART_RUNNER_LEG_A) return vec3(0.0, 0.0, 0.42 * step * low);
    if (part == CTX_PART_RUNNER_LEG_B) return vec3(0.0, 0.0, -0.42 * step * low);
    if (part == CTX_PART_RUNNER_ARM_A) return vec3(0.0, 0.06 * bob, -0.36 * step * low);
    if (part == CTX_PART_RUNNER_ARM_B) return vec3(0.0, 0.06 * bob, 0.36 * step * low);
    if (part == CTX_PART_WOLF_BODY) return vec3(0.0, 0.05 * bob, 0.0);
    if (part == CTX_PART_WOLF_HEAD) return vec3(0.0, 0.08 * bob, -0.05 * sin(2.0 * phase));
    if (part == CTX_PART_WOLF_LEG_A) return vec3(0.0, 0.0, 0.2 * step * low);
    if (part == CTX_PART_WOLF_LEG_B) return vec3(0.0, 0.0, -0.2 * step * low);
    if (part == CTX_PART_WOLF_TAIL) return vec3(0.1 * step, 0.05 * bob, 0.0);
    return vec3(0.0);
}

// The start's camera: where a point of the scene looks to be with the camera t ticks into its swing round the chicken.
vec3 ctx_surfers_orbit(vec3 point, float t) {
    float along = t >= CTX_ORBIT_BEFORE ? 0.0 : clamp((t - CTX_ORBIT_FROM) / (CTX_ORBIT_TO - CTX_ORBIT_FROM), 0.0, 1.0);
    float eased = along * along * (3.0 - 2.0 * along);
    if (eased >= 1.0) {
        return point;
    }
    float turn = 3.14159265 * (1.0 - eased);
    float c = cos(turn);
    float s = sin(turn);
    float left = 1.0 - eased;
    return vec3(point.x * c + point.z * s, point.y + CTX_ORBIT_UP * left, -point.x * s + point.z * c + CTX_ORBIT_IN * left);
}

// What to add to a clip position's z, for the depth test to see a piece CTX_SCREEN_RELIEF / ahead blocks out of the picture
// without it moving: its w is ahead times that of a point on the plane, so a constant does it, and depth stays linear over a
// face, so faces meet and cross where they should. It's the window's middle's depth per block, the same for every vertex of a
// frame. Standing out for real would make a bowl of the picture, near things at its edges standing out and far things in its
// middle sunk in, and it looks curved from any side but straight on.
float ctx_screen_depth(mat4 view, vec3 middle, vec3 outward) {
    vec4 at = view * vec4(middle, 1.0);
    vec4 front = view * vec4(middle + outward, 1.0);
    return (at.w * front.z / max(front.w, 0.05) - at.z) * CTX_SCREEN_RELIEF;
}

// A piece's vertex. camera: the camera in world coordinates; position is relative to it. view: what the release's shader
// multiplies by. It comes out with the position to draw (w and all), its normal as it is in a player's own view (so every
// screen is lit alike), where to take its fog from and, on a screen, ctxScreen for the fragment stage and ctxDepth to add to
// the clip position's z.
void ctx_surfers_vertex(vec4 color, vec3 position, int vertexId, float gameTime, vec3 camera, mat4 view, inout vec4 clipInput, inout vec3 normal, inout vec3 fogAt, inout vec4 ctxScreen, inout float ctxDepth) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    int bits = c.r - CTX_SURFERS_MARK;
    bool onScreen = (bits & 1) != 0;
    bool orbit = (bits & 2) != 0;
    int part = ctx_surfers_part(color);
    int plot = c.g & 15;
    int gait = c.b >> 6;
    float tick = gameTime * 24000.0;

    vec3 middle = ctx_screen_at(plot) - camera;
    vec3 outward = ctx_screen_out(plot);
    vec3 right = ctx_screen_right(plot);
    vec3 scene;
    if (onScreen) {
        vec3 q = position - middle;
        scene = vec3(dot(q, right), q.y, dot(q, outward));
    } else {
        scene = position + vec3(0.0, CTX_CAMERA_HEIGHT, CTX_CAMERA_BACK);
    }
    scene += ctx_surfers_motion(part, gait, vertexId, normal.y, tick, scene);
    if (orbit) {
        scene = ctx_surfers_orbit(scene, mod(tick - float(c.b & 63) * 8.0, CTX_ORBIT_LOOP));
    }
    if (!onScreen) {
        clipInput = vec4(scene - vec3(0.0, CTX_CAMERA_HEIGHT, CTX_CAMERA_BACK), 1.0);
        return;
    }

    float y = scene.y - CTX_CAMERA_HEIGHT;
    float z = scene.z - CTX_CAMERA_BACK;
    float up = y * CTX_CAMERA_COS - z * CTX_CAMERA_SIN;
    float ahead = -y * CTX_CAMERA_SIN - z * CTX_CAMERA_COS;

    float px = CTX_SCREEN_FOCAL * scene.x;
    float py = CTX_SCREEN_FOCAL * up;
    clipInput = vec4(middle * ahead + right * px + vec3(0.0, py, 0.0), ahead);
    ctxScreen = vec4(px, py, ahead, 1.0);
    ctxDepth = ctx_screen_depth(view, middle, outward);
    normal = vec3(dot(normal, right), normal.y, dot(normal, outward));
    fogAt = middle;
}

// Whether a fragment of a screen's picture falls outside its window, or too close to the camera
bool ctx_screen_clipped(vec4 ctxScreen) {
    if (ctxScreen.w < 0.5) {
        return false;
    }
    if (ctxScreen.z < CTX_SCREEN_NEAR) {
        return true;
    }
    vec2 at = ctxScreen.xy / ctxScreen.z;
    return abs(at.x) > CTX_SCREEN_HALF_WIDTH || abs(at.y) > CTX_SCREEN_HALF_HEIGHT;
}

#endif

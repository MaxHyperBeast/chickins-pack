#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chickins_flash.glsl>
#moj_import <minecraft:chickins_lucky.glsl>
#moj_import <minecraft:chickins_surfers.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;
flat out vec4 ctxLucky;
out vec2 ctxLuckyUv;
out vec4 ctxScreen;

void main() {
    vec4 ctxAt = vec4(Position, 1.0);
    vec3 ctxNormal = Normal;
    vec3 ctxFogAt = Position;
    ctxScreen = vec4(0.0);
    float ctxDepth = 0.0;
    bool ctxSurfers = ctx_surfers_piece(Color);
    if (ctxSurfers) {
        ctx_surfers_vertex(Color, Position, CTX_VERTEX_ID, GameTime, vec3(CameraBlockPos) - CameraOffset, ProjMat * ModelViewMat, ctxAt, ctxNormal, ctxFogAt, ctxScreen, ctxDepth);   // chickins_surfers.glsl
    }
    gl_Position = ProjMat * (ctx_surfers_own(Color) ? ctx_surfers_own_view(ctxAt) : ModelViewMat * ctxAt);
    gl_Position.z += ctxDepth;

    sphericalVertexDistance = fog_spherical_distance(ctxFogAt);
    cylindricalVertexDistance = fog_cylindrical_distance(ctxFogAt);

    ctxLucky = ctx_lucky_info(ctxSurfers ? vec4(1.0) : Color, GameTime);
    ctxLuckyUv = ctx_lucky_corner(CTX_VERTEX_ID);
    vec4 tint = ctxLucky.x >= 0.0 || ctxSurfers ? vec4(1.0) : Color;   // a Lucky Block's tint only says which one it is
    vertexColor = (ctx_surfers_unlit(Color) ? tint : minecraft_mix_light(Light0_Direction, Light1_Direction, ctxNormal, tint));
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
}
